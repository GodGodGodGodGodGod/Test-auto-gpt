# OfficialSMS API

Backend API for OfficialSMS.

## Current implementation slice

- Uses the existing NeXoDe API Gateway and runtime.
- Keeps OfficialSMS-specific catalog logic inside the OfficialSMS application.
- Integrates the documented 5SIM guest price catalog endpoint.
- Normalizes provider catalog data into an OfficialSMS domain model.
- Treats the provider currency as configuration rather than hard-coding it into the domain.
- Includes unit coverage for successful normalization and provider failures.

## Local development

Copy `.env.example` to your local environment and run the workspace with pnpm.

The first endpoint is:

`GET /api/v1/catalog`

Optional query parameters:

- `country`
- `service`

5SIM credentials are intentionally not required for the guest catalog endpoint. Authenticated purchasing will be implemented only against the documented 5SIM user API operations.

## Order domain

The order domain now owns OfficialSMS order state transitions and immutable pricing snapshots at the application boundary. Persistence is accessed through an `OrderRepository` port; the current implementation uses an in-memory repository only for domain/application tests. No purchase route is exposed until identity, wallet reservation, idempotency, and persistent storage are wired together.

## Payments

The payment domain is provider-neutral. A `PaymentProvider` creates and verifies checkout references; `DepositIntent` owns the OfficialSMS lifecycle and idempotency boundary. No live payment provider is selected or configured yet. A provider callback must be mapped to a provider reference and applied through `DepositService`; successful deposits should credit the wallet through the ledger in the same financial transaction once PostgreSQL persistence is wired.

## Background jobs

OfficialSMS uses the shared `@nexode/jobs` queue abstraction with a PostgreSQL-backed implementation. Job rows use `FOR UPDATE SKIP LOCKED` for multi-worker-safe claiming, leases for crash recovery, bounded retries with exponential backoff, and active-job deduplication. SMS polling and ambiguous purchase reconciliation are represented as jobs; neither job type performs a second purchase.

Apply migration `migrations/0005_jobs.sql` before enabling workers.
