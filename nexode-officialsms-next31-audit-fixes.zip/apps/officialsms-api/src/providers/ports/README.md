# OfficialSMS Provider Port

The `SmsProvider` interface is the boundary between OfficialSMS application logic and
external SMS-number providers.

A provider adapter must translate its own API into the provider-neutral activation
model. OfficialSMS business logic must not depend on 5SIM endpoint paths, response
shapes, or provider-specific status parsing.

Current provider: 5SIM.

Supported operations:

- purchase
- check
- finish
- cancel
- ban

Purchase is intentionally not exposed as a public HTTP route yet. Identity,
authorization, wallet reservation, idempotency, pricing snapshots and audit logging
must be in place before a customer can trigger a paid provider operation.
