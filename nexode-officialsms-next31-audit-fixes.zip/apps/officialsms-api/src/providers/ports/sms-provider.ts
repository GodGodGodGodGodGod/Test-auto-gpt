
export class SmsProviderAmbiguousError extends Error {
  constructor(message: string, options?: { readonly cause?: unknown }) {
    super(message);
    if (options?.cause !== undefined) (this as Error & { cause?: unknown }).cause = options.cause;
    this.name = 'SmsProviderAmbiguousError';
  }
}

export type SmsProviderStatus =
  | 'PENDING'
  | 'RECEIVED'
  | 'FINISHED'
  | 'CANCELED'
  | 'TIMEOUT'
  | 'BANNED'
  | string;

export interface SmsMessage {
  readonly id?: number;
  readonly createdAt?: string;
  readonly date?: string;
  readonly sender?: string;
  readonly text?: string;
  readonly code?: string;
}

export interface SmsActivation {
  readonly id: string;
  readonly phone: string;
  readonly country?: string;
  readonly operator?: string;
  readonly product: string;
  readonly price: number;
  readonly currency: string;
  readonly status: SmsProviderStatus;
  readonly createdAt?: string;
  readonly expiresAt?: string;
  readonly sms: readonly SmsMessage[];
}

export interface SmsProvider {
  readonly name: string;

  purchase(input: {
    readonly country: string;
    readonly operator: string;
    readonly service: string;
    readonly maxPrice?: number;
  }): Promise<SmsActivation>;

  check(orderId: string): Promise<SmsActivation>;
  finish(orderId: string): Promise<SmsActivation>;
  cancel(orderId: string): Promise<SmsActivation>;
  ban(orderId: string): Promise<SmsActivation>;
}
