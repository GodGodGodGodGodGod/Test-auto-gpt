import { ApiGateway, NodeHttpAdapter } from '@nexode/api-gateway';
import { bootstrap } from '@nexode/runtime';
import { loadOfficialSmsConfig } from './config/config.js';
import { registerRoutes } from './routes/registerRoutes.js';

async function main(): Promise<void> {
  const config = loadOfficialSmsConfig();

  await bootstrap();

  const gateway = new ApiGateway(
    new NodeHttpAdapter(),
    {
      serviceName: 'officialsms-api',
      version: '0.1.0',
      port: config.port,
      environment: config.environment,
    },
  );

  await gateway.initialize();
  registerRoutes(gateway, config);

  gateway.group('/api/v1', (api) => {
    api.get('/health', async (_request, response) => {
      response.send({
        status: 'ok',
        service: 'officialsms-api',
      });
    });
  });

  await gateway.start();

  console.log(`OfficialSMS API is running on port ${config.port}`);
}

main().catch((error: unknown) => {
  console.error('Failed to start OfficialSMS API:', error);
  process.exitCode = 1;
});
