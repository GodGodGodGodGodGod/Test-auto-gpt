import { loadOfficialSmsConfig } from './config/config.js';
import { createOfficialSmsWorker } from './modules/jobs/workerFactory.js';

async function main(): Promise<void> {
  const config = loadOfficialSmsConfig();
  const runtime = createOfficialSmsWorker(config);
  let stopping = false;
  const shutdown = async (signal: string) => {
    if (stopping) return;
    stopping = true;
    console.log(`OfficialSMS worker received ${signal}; stopping gracefully...`);
    runtime.worker.stop();
    await runtime.close();
  };
  process.once('SIGINT', () => { void shutdown('SIGINT'); });
  process.once('SIGTERM', () => { void shutdown('SIGTERM'); });
  await runtime.worker.start();
}

main().catch((error: unknown) => {
  console.error('Failed to start OfficialSMS worker:', error);
  process.exitCode = 1;
});
