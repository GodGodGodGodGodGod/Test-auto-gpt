import { z } from 'zod';

const schema = z.object({
  NODE_ENV: z.enum(['development', 'test', 'staging', 'production']).default('development'),
  SERVER_HOST: z.string().default('0.0.0.0'),
  SERVER_PORT: z.coerce.number().int().min(1).max(65535).default(3100),
  OFFICIALSMS_5SIM_API_BASE_URL: z.string().url().default('https://5sim.net/v1'),
  OFFICIALSMS_5SIM_TIMEOUT_MS: z.coerce.number().int().positive().max(30000).default(8000),
  OFFICIALSMS_5SIM_CURRENCY: z.string().regex(/^[A-Z]{3}$/).default('USD'),
  OFFICIALSMS_5SIM_API_KEY: z.string().min(1),
  OFFICIALSMS_EXCHANGE_RATE_BASE_URL: z.string().url().default('https://api.frankfurter.dev'),
  OFFICIALSMS_EXCHANGE_RATE_PROVIDER: z.string().min(1).default(''),
  OFFICIALSMS_EXCHANGE_RATE_TTL_MS: z.coerce.number().int().positive().max(86400000).default(3600000),
  OFFICIALSMS_CATALOG_TTL_MS: z.coerce.number().int().positive().max(86400000).default(60000),
  DATABASE_URL: z.string().min(1),
  OFFICIALSMS_JWT_SECRET: z.string().min(32),
  OFFICIALSMS_JWT_ISSUER: z.string().min(1).default('officialsms'),
  OFFICIALSMS_JWT_AUDIENCE: z.string().min(1).default('officialsms-api'),
  OFFICIALSMS_AUTH_REQUIRE_VERIFIED_EMAIL: z.coerce.boolean().default(true),
  OFFICIALSMS_AUTH_SESSION_IDLE_TIMEOUT_MS: z.coerce.number().int().positive().max(86400000).default(1800000),
  OFFICIALSMS_PASSWORD_MIN_LENGTH: z.coerce.number().int().min(12).max(128).default(12),
  OFFICIALSMS_LOGIN_LOCK_THRESHOLD: z.coerce.number().int().min(3).max(20).default(5),
  OFFICIALSMS_LOGIN_LOCK_DURATION_MS: z.coerce.number().int().positive().max(3600000).default(900000),
  OFFICIALSMS_EMAIL_VERIFICATION_BASE_URL: z.string().url().default('http://localhost:3000/verify-email'),
  OFFICIALSMS_PASSWORD_RESET_BASE_URL: z.string().url().default('http://localhost:3000/reset-password'),
  OFFICIALSMS_WORKER_POLL_INTERVAL_MS: z.coerce.number().int().positive().max(10000).default(250),
  OFFICIALSMS_WORKER_DISCOVERY_INTERVAL_MS: z.coerce.number().int().positive().max(60000).default(5000),
  OFFICIALSMS_WORKER_DISCOVERY_BATCH_SIZE: z.coerce.number().int().min(1).max(1000).default(100),
  OFFICIALSMS_WORKER_LEASE_MS: z.coerce.number().int().positive().max(300000).default(30000),
  OFFICIALSMS_CATALOG_SYNC_INTERVAL_MS: z.coerce.number().int().positive().max(86400000).default(60000),
  OFFICIALSMS_PROVIDER_HEALTH_INTERVAL_MS: z.coerce.number().int().positive().max(86400000).default(30000),
  OFFICIALSMS_PROVIDER_HEALTH_MAX_AGE_MS: z.coerce.number().int().positive().max(86400000).default(120000),
});

export interface OfficialSmsConfig {
  readonly environment: 'development' | 'test' | 'staging' | 'production';
  readonly host: string;
  readonly port: number;
  readonly databaseUrl: string;
  readonly auth: { readonly jwtSecret: Uint8Array; readonly issuer: string; readonly audience: string; readonly requireVerifiedEmail: boolean; readonly sessionIdleTimeoutMs: number; readonly emailVerificationBaseUrl: string; readonly passwordResetBaseUrl: string; readonly passwordMinLength: number; readonly loginLockThreshold: number; readonly loginLockDurationMs: number; };
  readonly worker: { readonly pollIntervalMs: number; readonly discoveryIntervalMs: number; readonly discoveryBatchSize: number; readonly leaseMs: number; readonly catalogSyncIntervalMs: number; readonly providerHealthIntervalMs: number; readonly providerHealthMaxAgeMs: number; };
  readonly pricing: { readonly exchangeRateBaseUrl: string; readonly exchangeRateProvider?: string; readonly exchangeRateTtlMs: number; readonly catalogTtlMs: number; };
  readonly fiveSim: {
    readonly apiKey: string;
    readonly baseUrl: string;
    readonly timeoutMs: number;
    readonly currency: string;
  };
}

export function loadOfficialSmsConfig(env: NodeJS.ProcessEnv = process.env): OfficialSmsConfig {
  const parsed = schema.parse(env);
  return Object.freeze({
    environment: parsed.NODE_ENV,
    databaseUrl: parsed.DATABASE_URL,
    auth: Object.freeze({ jwtSecret: new TextEncoder().encode(parsed.OFFICIALSMS_JWT_SECRET), issuer: parsed.OFFICIALSMS_JWT_ISSUER, audience: parsed.OFFICIALSMS_JWT_AUDIENCE, requireVerifiedEmail: parsed.OFFICIALSMS_AUTH_REQUIRE_VERIFIED_EMAIL, sessionIdleTimeoutMs: parsed.OFFICIALSMS_AUTH_SESSION_IDLE_TIMEOUT_MS, emailVerificationBaseUrl: parsed.OFFICIALSMS_EMAIL_VERIFICATION_BASE_URL, passwordResetBaseUrl: parsed.OFFICIALSMS_PASSWORD_RESET_BASE_URL, passwordMinLength: parsed.OFFICIALSMS_PASSWORD_MIN_LENGTH, loginLockThreshold: parsed.OFFICIALSMS_LOGIN_LOCK_THRESHOLD, loginLockDurationMs: parsed.OFFICIALSMS_LOGIN_LOCK_DURATION_MS }),
    worker: Object.freeze({ pollIntervalMs: parsed.OFFICIALSMS_WORKER_POLL_INTERVAL_MS, discoveryIntervalMs: parsed.OFFICIALSMS_WORKER_DISCOVERY_INTERVAL_MS, discoveryBatchSize: parsed.OFFICIALSMS_WORKER_DISCOVERY_BATCH_SIZE, leaseMs: parsed.OFFICIALSMS_WORKER_LEASE_MS, catalogSyncIntervalMs: parsed.OFFICIALSMS_CATALOG_SYNC_INTERVAL_MS, providerHealthIntervalMs: parsed.OFFICIALSMS_PROVIDER_HEALTH_INTERVAL_MS, providerHealthMaxAgeMs: parsed.OFFICIALSMS_PROVIDER_HEALTH_MAX_AGE_MS }),
    host: parsed.SERVER_HOST,
    port: parsed.SERVER_PORT,
    pricing: Object.freeze({
      exchangeRateBaseUrl: parsed.OFFICIALSMS_EXCHANGE_RATE_BASE_URL.replace(/\/$/, ''),
      exchangeRateProvider: parsed.OFFICIALSMS_EXCHANGE_RATE_PROVIDER || undefined,
      exchangeRateTtlMs: parsed.OFFICIALSMS_EXCHANGE_RATE_TTL_MS,
      catalogTtlMs: parsed.OFFICIALSMS_CATALOG_TTL_MS,
    }),
    fiveSim: Object.freeze({
      apiKey: parsed.OFFICIALSMS_5SIM_API_KEY,
      baseUrl: parsed.OFFICIALSMS_5SIM_API_BASE_URL.replace(/\/$/, ''),
      timeoutMs: parsed.OFFICIALSMS_5SIM_TIMEOUT_MS,
      currency: parsed.OFFICIALSMS_5SIM_CURRENCY,
    }),
  });
}
