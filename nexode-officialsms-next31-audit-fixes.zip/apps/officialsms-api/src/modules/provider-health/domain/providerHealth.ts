export type ProviderHealthStatus = 'HEALTHY' | 'DEGRADED' | 'UNAVAILABLE';

export interface ProviderHealthSnapshot {
  readonly provider: '5sim';
  readonly status: ProviderHealthStatus;
  readonly latencyMs?: number;
  readonly checkedAt: string;
  readonly error?: string;
}
