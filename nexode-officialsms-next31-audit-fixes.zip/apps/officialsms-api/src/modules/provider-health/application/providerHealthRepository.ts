import type { ProviderHealthSnapshot } from '../domain/providerHealth.js';

export interface ProviderHealthRepository {
  save(snapshot: ProviderHealthSnapshot): Promise<void>;
  latest(provider: '5sim'): Promise<ProviderHealthSnapshot | null>;
}
