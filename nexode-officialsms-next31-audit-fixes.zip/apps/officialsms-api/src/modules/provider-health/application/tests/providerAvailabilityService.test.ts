import { describe, expect, it } from 'vitest';
import { ProviderAvailabilityService, ProviderHealthStaleError, ProviderUnavailableError } from '../providerAvailabilityService.js';
import type { ProviderHealthRepository } from '../providerHealthRepository.js';
import type { ProviderHealthSnapshot } from '../../domain/providerHealth.js';

const repo = (snapshot: ProviderHealthSnapshot | null): ProviderHealthRepository => ({
  save: async () => undefined,
  latest: async () => snapshot,
});

describe('ProviderAvailabilityService', () => {
  it('allows healthy and degraded providers', async () => {
    for (const status of ['HEALTHY', 'DEGRADED'] as const) {
      const service = new ProviderAvailabilityService(repo({ provider: '5sim', status, checkedAt: new Date().toISOString() }));
      await expect(service.assertPurchaseAllowed()).resolves.toMatchObject({ status });
    }
  });

  it('blocks unavailable providers', async () => {
    const service = new ProviderAvailabilityService(repo({ provider: '5sim', status: 'UNAVAILABLE', checkedAt: new Date().toISOString() }));
    await expect(service.assertPurchaseAllowed()).rejects.toBeInstanceOf(ProviderUnavailableError);
  });

  it('fails closed when health is stale or missing', async () => {
    const stale = new ProviderAvailabilityService(repo({ provider: '5sim', status: 'HEALTHY', checkedAt: new Date(Date.now() - 121_000).toISOString() }), 120_000);
    await expect(stale.assertPurchaseAllowed()).rejects.toBeInstanceOf(ProviderHealthStaleError);
    const missing = new ProviderAvailabilityService(repo(null));
    await expect(missing.assertPurchaseAllowed()).rejects.toBeInstanceOf(ProviderHealthStaleError);
  });
});
