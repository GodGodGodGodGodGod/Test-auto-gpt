import type { ProviderHealthRepository } from './providerHealthRepository.js';
import type { ProviderHealthStatus } from '../domain/providerHealth.js';

export class ProviderUnavailableError extends Error {
  readonly provider = '5sim';
  constructor(message = 'SMS provider is temporarily unavailable') {
    super(message);
    this.name = 'ProviderUnavailableError';
  }
}

export class ProviderHealthStaleError extends Error {
  readonly provider = '5sim';
  constructor(message = 'SMS provider health information is stale') {
    super(message);
    this.name = 'ProviderHealthStaleError';
  }
}

export interface ProviderAvailability {
  readonly provider: '5sim';
  readonly status: ProviderHealthStatus;
  readonly checkedAt: string;
  readonly ageMs: number;
}

export class ProviderAvailabilityService {
  constructor(
    private readonly repository: ProviderHealthRepository,
    private readonly maxAgeMs = 120_000,
  ) {}

  async get(): Promise<ProviderAvailability | null> {
    const snapshot = await this.repository.latest('5sim');
    if (!snapshot) return null;
    const ageMs = Math.max(0, Date.now() - Date.parse(snapshot.checkedAt));
    return { provider: snapshot.provider, status: snapshot.status, checkedAt: snapshot.checkedAt, ageMs };
  }

  async assertPurchaseAllowed(): Promise<ProviderAvailability> {
    const health = await this.get();
    if (!health) throw new ProviderHealthStaleError('5SIM has no health check yet');
    if (health.ageMs > this.maxAgeMs) throw new ProviderHealthStaleError();
    if (health.status === 'UNAVAILABLE') throw new ProviderUnavailableError();
    // DEGRADED remains purchasable: the provider is reachable, but callers and
    // operations should be able to observe that service quality is reduced.
    return health;
  }
}
