import type { ProviderHealthRepository } from './providerHealthRepository.js';

export interface ProviderHealthProbe {
  checkHealth(): Promise<void>;
}

export class CheckProviderHealthService {
  constructor(private readonly probe: ProviderHealthProbe, private readonly repository: ProviderHealthRepository) {}

  async execute(): Promise<void> {
    const started = Date.now();
    try {
      await this.probe.checkHealth();
      const latencyMs = Date.now() - started;
      await this.repository.save({ provider: '5sim', status: latencyMs > 2000 ? 'DEGRADED' : 'HEALTHY', latencyMs, checkedAt: new Date().toISOString() });
    } catch (error) {
      await this.repository.save({
        provider: '5sim', status: 'UNAVAILABLE', checkedAt: new Date().toISOString(),
        error: (error instanceof Error ? error.message : String(error)).slice(0, 1000),
      });
    }
  }
}
