import type { Pool } from 'pg';
import type { ProviderHealthRepository } from '../../application/providerHealthRepository.js';
import type { ProviderHealthSnapshot } from '../../domain/providerHealth.js';

export class PostgresProviderHealthRepository implements ProviderHealthRepository {
  constructor(private readonly pool: Pool) {}

  async save(snapshot: ProviderHealthSnapshot): Promise<void> {
    await this.pool.query(
      `INSERT INTO officialsms_provider_health (provider,status,latency_ms,checked_at,error)
       VALUES ($1,$2,$3,$4,$5)`,
      [snapshot.provider, snapshot.status, snapshot.latencyMs ?? null, snapshot.checkedAt, snapshot.error ?? null],
    );
  }

  async latest(provider: '5sim'): Promise<ProviderHealthSnapshot | null> {
    const result = await this.pool.query<{ provider: '5sim'; status: ProviderHealthSnapshot['status']; latency_ms: number | null; checked_at: Date; error: string | null }>(
      `SELECT provider,status,latency_ms,checked_at,error FROM officialsms_provider_health WHERE provider=$1 ORDER BY checked_at DESC LIMIT 1`, [provider],
    );
    const row = result.rows[0];
    if (!row) return null;
    return { provider: row.provider, status: row.status, ...(row.latency_ms === null ? {} : { latencyMs: row.latency_ms }), checkedAt: row.checked_at.toISOString(), ...(row.error ? { error: row.error } : {}) };
  }
}
