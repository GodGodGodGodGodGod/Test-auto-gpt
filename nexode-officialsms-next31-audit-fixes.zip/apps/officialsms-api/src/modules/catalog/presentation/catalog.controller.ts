import type { GatewayRequest, GatewayResponse } from '@nexode/api-gateway';
import { GetCatalog } from '../application/getCatalog.js';

export class CatalogController {
  constructor(private readonly getCatalog: GetCatalog) {}

  async list(request: GatewayRequest, response: GatewayResponse): Promise<void> {
    const currency = request.query.currency?.toUpperCase() ?? 'USD';
    if (!/^[A-Z]{3}$/.test(currency)) throw new Error('Invalid customer currency');
    const catalog = await this.getCatalog.execute({ country: request.query.country, service: request.query.service, customerCurrency: currency });
    response.send({ provider: catalog.provider, fetchedAt: catalog.fetchedAt.toISOString(), expiresAt: catalog.expiresAt, stale: catalog.stale, products: catalog.products });
  }
}
