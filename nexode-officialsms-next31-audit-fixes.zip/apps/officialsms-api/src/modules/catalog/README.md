# OfficialSMS catalog

The provider catalog is treated as volatile operational data. Provider responses are persisted as immutable snapshots and served from PostgreSQL while fresh. When a snapshot expires, the API attempts a provider refresh. If the provider is unavailable, an existing expired snapshot may be returned with `stale: true`; no availability is fabricated.

Customer prices are calculated from the persisted provider cost using the pricing engine at read time. Historical order prices remain independent of catalog snapshots.

Filtered requests (`country` / `service`) have their own snapshots so a narrow provider refresh cannot accidentally replace the global catalog. A future scheduled sync can pre-warm selected scopes through the same snapshot service.
