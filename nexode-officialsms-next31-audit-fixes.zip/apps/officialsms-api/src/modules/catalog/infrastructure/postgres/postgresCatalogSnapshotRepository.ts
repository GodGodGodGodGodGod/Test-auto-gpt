import type { Pool } from 'pg';
import type { ProviderSmsProduct } from '../../domain/catalog.js';

export interface CatalogSnapshot {
  readonly id: string;
  readonly provider: '5sim';
  readonly country?: string;
  readonly service?: string;
  readonly products: readonly ProviderSmsProduct[];
  readonly fetchedAt: string;
  readonly expiresAt: string;
}

export interface CatalogSnapshotRepository {
  findLatest(input: { readonly provider: '5sim'; readonly country?: string; readonly service?: string }): Promise<CatalogSnapshot | null>;
  save(snapshot: Omit<CatalogSnapshot, 'id'>): Promise<CatalogSnapshot>;
}

export class PostgresCatalogSnapshotRepository implements CatalogSnapshotRepository {
  constructor(private readonly pool: Pool) {}

  async findLatest(input: { readonly provider: '5sim'; readonly country?: string; readonly service?: string }): Promise<CatalogSnapshot | null> {
    const result = await this.pool.query<{
      id: string;
      provider: '5sim';
      country: string | null;
      service: string | null;
      products: unknown;
      fetched_at: Date;
      expires_at: Date;
    }>(
      `SELECT id::text, provider, country, service, products, fetched_at, expires_at
       FROM officialsms_catalog_snapshots
       WHERE provider = $1
         AND country IS NOT DISTINCT FROM $2
         AND service IS NOT DISTINCT FROM $3
       ORDER BY fetched_at DESC, id DESC
       LIMIT 1`,
      [input.provider, input.country ?? null, input.service ?? null],
    );
    const row = result.rows[0];
    if (!row) return null;
    return {
      id: row.id,
      provider: row.provider,
      ...(row.country ? { country: row.country } : {}),
      ...(row.service ? { service: row.service } : {}),
      products: parseProducts(row.products),
      fetchedAt: row.fetched_at.toISOString(),
      expiresAt: row.expires_at.toISOString(),
    };
  }

  async save(snapshot: Omit<CatalogSnapshot, 'id'>): Promise<CatalogSnapshot> {
    const result = await this.pool.query<{
      id: string;
      provider: '5sim';
      country: string | null;
      service: string | null;
      products: unknown;
      fetched_at: Date;
      expires_at: Date;
    }>(
      `INSERT INTO officialsms_catalog_snapshots
       (provider, country, service, products, fetched_at, expires_at)
       VALUES ($1, $2, $3, $4::jsonb, $5, $6)
       RETURNING id::text, provider, country, service, products, fetched_at, expires_at`,
      [snapshot.provider, snapshot.country ?? null, snapshot.service ?? null, JSON.stringify(snapshot.products), snapshot.fetchedAt, snapshot.expiresAt],
    );
    const row = result.rows[0];
    return {
      id: row.id,
      provider: row.provider,
      ...(row.country ? { country: row.country } : {}),
      ...(row.service ? { service: row.service } : {}),
      products: parseProducts(row.products),
      fetchedAt: row.fetched_at.toISOString(),
      expiresAt: row.expires_at.toISOString(),
    };
  }
}

function parseProducts(value: unknown): readonly ProviderSmsProduct[] {
  if (!Array.isArray(value)) throw new Error('Invalid persisted catalog snapshot');
  return value.map((item) => {
    if (typeof item !== 'object' || item === null) throw new Error('Invalid persisted catalog product');
    const product = item as Record<string, unknown>;
    if (typeof product.country !== 'string' || typeof product.operator !== 'string' || typeof product.service !== 'string' ||
        typeof product.providerPrice !== 'string' || typeof product.providerCurrency !== 'string' ||
        typeof product.available !== 'number' || !Number.isSafeInteger(product.available) || product.available < 0) {
      throw new Error('Invalid persisted catalog product');
    }
    return {
      country: product.country,
      operator: product.operator,
      service: product.service,
      providerPrice: product.providerPrice,
      providerCurrency: product.providerCurrency,
      available: product.available,
    };
  });
}
