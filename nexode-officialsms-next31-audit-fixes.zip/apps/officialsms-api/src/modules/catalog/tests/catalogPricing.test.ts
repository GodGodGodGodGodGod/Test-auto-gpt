import { describe, expect, it } from 'vitest';
import { GetCatalog } from '../application/getCatalog.js';
import { CatalogSnapshotService } from '../application/catalogSnapshotService.js';
import type { SmsCatalogProvider } from '../application/getCatalog.js';
import type { SmsCatalog } from '../domain/catalog.js';
import type { CatalogSnapshot, CatalogSnapshotRepository } from '../infrastructure/postgres/postgresCatalogSnapshotRepository.js';
import { PriceService } from '../../pricing/application/priceService.js';
import { StaticExchangeRateProvider, StaticMarkupRuleProvider } from '../../pricing/infrastructure/inMemoryPricingProviders.js';

class InMemoryCatalogSnapshotRepository implements CatalogSnapshotRepository {
  private snapshot: CatalogSnapshot | null = null;

  async findLatest(_input: { readonly provider: '5sim'; readonly country?: string; readonly service?: string }): Promise<CatalogSnapshot | null> {
    return this.snapshot;
  }

  async save(snapshot: Omit<CatalogSnapshot, 'id'>): Promise<CatalogSnapshot> {
    this.snapshot = { id: 'snapshot-1', ...snapshot };
    return this.snapshot;
  }
}

describe('catalog pricing integration', () => {
  it('keeps provider cost separate and exposes the customer price', async () => {
    const provider: SmsCatalogProvider = {
      async getCatalog(): Promise<SmsCatalog> {
        return {
          provider: '5sim',
          fetchedAt: new Date('2026-01-01T00:00:00.000Z'),
          products: [{
            country: 'england',
            operator: 'vodafone',
            service: 'facebook',
            providerPrice: '4',
            providerCurrency: 'USD',
            available: 10,
          }],
        };
      },
    };
    const pricing = new PriceService(
      new StaticExchangeRateProvider(new Map()),
      new StaticMarkupRuleProvider(new Map(), { version: 'v1', percentageBps: 1500n, minimumAmount: '0' }),
    );
    const snapshots = new CatalogSnapshotService(new InMemoryCatalogSnapshotRepository(), provider, 60_000);

    const catalog = await new GetCatalog(snapshots, pricing).execute({ customerCurrency: 'USD' });
    expect(catalog.products[0]).toMatchObject({ country: 'england', operator: 'vodafone', service: 'facebook', price: '4.6', currency: 'USD', available: 10 });
  });
});
