import type { SmsCatalogProvider } from './getCatalog.js';
import type { CatalogSnapshotRepository } from '../infrastructure/postgres/postgresCatalogSnapshotRepository.js';

export class SyncCatalogService {
  constructor(
    private readonly repository: CatalogSnapshotRepository,
    private readonly upstream: SmsCatalogProvider,
    private readonly ttlMs: number,
  ) {}

  async syncGlobal(): Promise<void> {
    const fresh = await this.upstream.getCatalog({});
    const fetchedAt = fresh.fetchedAt.toISOString();
    await this.repository.save({
      provider: '5sim',
      products: fresh.products.map((product) => ({
        country: product.country,
        operator: product.operator,
        service: product.service,
        providerPrice: product.providerPrice ?? product.price,
        providerCurrency: product.providerCurrency ?? product.currency,
        available: product.available,
      })),
      fetchedAt,
      expiresAt: new Date(new Date(fetchedAt).getTime() + this.ttlMs).toISOString(),
    });
  }
}
