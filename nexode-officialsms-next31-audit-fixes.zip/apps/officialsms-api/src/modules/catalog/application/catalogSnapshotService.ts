import type { ProviderSmsProduct } from '../domain/catalog.js';
import type { SmsCatalogProvider } from './getCatalog.js';
import type { CatalogSnapshot, CatalogSnapshotRepository } from '../infrastructure/postgres/postgresCatalogSnapshotRepository.js';

export interface CachedProviderCatalog {
  readonly provider: '5sim';
  readonly products: readonly ProviderSmsProduct[];
  readonly fetchedAt: Date;
  readonly stale: boolean;
  readonly expiresAt: Date;
}

export class CatalogSnapshotService {
  constructor(
    private readonly repository: CatalogSnapshotRepository,
    private readonly upstream: SmsCatalogProvider,
    private readonly ttlMs: number,
  ) {}

  async get(input: { readonly country?: string; readonly service?: string }): Promise<CachedProviderCatalog> {
    const existing = await this.repository.findLatest({ provider: '5sim', country: input.country, service: input.service });
    const now = Date.now();
    if (existing && new Date(existing.expiresAt).getTime() > now) return toCached(existing, false);

    try {
      const fresh = await this.upstream.getCatalog(input);
      const fetchedAt = fresh.fetchedAt.toISOString();
      const saved = await this.repository.save({
        provider: '5sim',
        ...(input.country ? { country: input.country } : {}),
        ...(input.service ? { service: input.service } : {}),
        products: fresh.products.map((product) => ({
          country: product.country,
          operator: product.operator,
          service: product.service,
          providerPrice: product.providerPrice ?? product.price,
          providerCurrency: product.providerCurrency ?? product.currency,
          available: product.available,
        })),
        fetchedAt,
        expiresAt: new Date(new Date(fetchedAt).getTime() + this.ttlMs).toISOString(),
      });
      return toCached(saved, false);
    } catch (error) {
      if (existing) return toCached(existing, true);
      throw error;
    }
  }
}

function toCached(snapshot: CatalogSnapshot, stale: boolean): CachedProviderCatalog {
  return {
    provider: snapshot.provider,
    products: snapshot.products,
    fetchedAt: new Date(snapshot.fetchedAt),
    stale,
    expiresAt: new Date(snapshot.expiresAt),
  };
}
