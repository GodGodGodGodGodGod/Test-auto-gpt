import type { SmsCatalog, SmsProduct } from '../domain/catalog.js';
import type { PriceService } from '../../pricing/application/priceService.js';
import type { CatalogSnapshotService } from './catalogSnapshotService.js';

export interface SmsCatalogProvider {
  getCatalog(input: { readonly country?: string; readonly service?: string }): Promise<import('../domain/catalog.js').SmsCatalog>;
}

export class GetCatalog {
  constructor(private readonly snapshots: CatalogSnapshotService, private readonly pricing: PriceService) {}

  async execute(input: { readonly country?: string; readonly service?: string; readonly customerCurrency: string }): Promise<SmsCatalog & { readonly stale: boolean; readonly expiresAt: string }> {
    const cached = await this.snapshots.get(input);
    const products: SmsProduct[] = [];
    for (const product of cached.products) {
      const quote = await this.pricing.quote({
        providerAmount: product.providerPrice,
        providerCurrency: product.providerCurrency,
        customerCurrency: input.customerCurrency,
      });
      products.push({
        country: product.country,
        operator: product.operator,
        service: product.service,
        price: quote.customerAmount,
        available: product.available,
        currency: quote.customerCurrency,
      });
    }
    return { provider: cached.provider, fetchedAt: cached.fetchedAt, products, stale: cached.stale, expiresAt: cached.expiresAt.toISOString() };
  }
}
