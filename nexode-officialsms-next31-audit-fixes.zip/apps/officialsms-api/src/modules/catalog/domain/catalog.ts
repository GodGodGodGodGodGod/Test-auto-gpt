export interface SmsProduct {
  readonly country: string;
  readonly operator: string;
  readonly service: string;
  readonly price: string;
  readonly available: number;
  readonly currency: string;
}

export interface SmsCatalog {
  readonly products: readonly ProviderSmsProduct[];
  readonly provider: '5sim';
  readonly fetchedAt: Date;
}

/** Provider-neutral raw catalog item used before OfficialSMS pricing is applied. */
export interface ProviderSmsProduct {
  readonly country: string;
  readonly operator: string;
  readonly service: string;
  readonly providerPrice: string;
  readonly available: number;
  readonly providerCurrency: string;
}
