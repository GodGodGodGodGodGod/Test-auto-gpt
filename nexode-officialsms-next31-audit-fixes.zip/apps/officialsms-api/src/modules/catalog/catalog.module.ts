import type { RouteDefinition } from '@nexode/api-gateway';
import { GetCatalog } from './application/getCatalog.js';
import { CatalogSnapshotService } from './application/catalogSnapshotService.js';
import { FiveSimCatalogProvider } from './infrastructure/fiveSimCatalogProvider.js';
import { PostgresCatalogSnapshotRepository } from './infrastructure/postgres/postgresCatalogSnapshotRepository.js';
import { CatalogController } from './presentation/catalog.controller.js';
import type { OfficialSmsConfig } from '../../config/config.js';
import { createPostgresPool } from '../money/infrastructure/postgres/createPostgresPool.js';
import { PriceService } from '../pricing/application/priceService.js';
import { FrankfurterExchangeRateProvider } from '../pricing/infrastructure/frankfurterExchangeRateProvider.js';
import { PostgresExchangeRateProvider, PostgresMarkupRuleProvider } from '../pricing/infrastructure/postgresPricingProviders.js';

export function createCatalogRoutes(config: OfficialSmsConfig): readonly RouteDefinition[] {
  const pool = createPostgresPool(config.databaseUrl);
  const upstreamRates = new FrankfurterExchangeRateProvider({ baseUrl: config.pricing.exchangeRateBaseUrl, timeoutMs: config.fiveSim.timeoutMs, provider: config.pricing.exchangeRateProvider });
  const rates = new PostgresExchangeRateProvider(pool, upstreamRates, config.pricing.exchangeRateTtlMs);
  const markupRules = new PostgresMarkupRuleProvider(pool);
  const pricing = new PriceService(rates, markupRules);
  const provider = new FiveSimCatalogProvider(config.fiveSim.baseUrl, config.fiveSim.timeoutMs, config.fiveSim.currency);
  const snapshots = new CatalogSnapshotService(new PostgresCatalogSnapshotRepository(pool), provider, config.pricing.catalogTtlMs);
  const controller = new CatalogController(new GetCatalog(snapshots, pricing));
  return [{ method: 'GET', path: '/catalog', handler: controller.list.bind(controller) }];
}
