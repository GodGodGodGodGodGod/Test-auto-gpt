export type OfficialSmsOrderStatus =
  | 'CREATED'
  | 'PAYMENT_RESERVED'
  | 'PURCHASING'
  | 'ACTIVE'
  | 'SMS_RECEIVED'
  | 'COMPLETED'
  | 'FAILED'
  | 'EXPIRED'
  | 'CANCELLED';

export interface OrderPriceSnapshot {
  readonly providerAmount: string;
  readonly providerCurrency: string;
  readonly customerAmount: string;
  readonly customerCurrency: string;
  readonly exchangeRate: string;
  readonly markupAmount: string;
  readonly pricingRuleVersion: string;
  readonly rateSource: string;
  readonly rateCapturedAt: string;
}

export interface SmsOrder {
  readonly id: string;
  readonly customerId: string;
  readonly purchaseIdempotencyKey: string;
  readonly provider: string;
  readonly providerOrderId?: string;
  readonly country: string;
  readonly operator: string;
  readonly service: string;
  readonly phone?: string;
  readonly sms: readonly { readonly id?: number; readonly createdAt?: string; readonly sender?: string; readonly text?: string; readonly code?: string }[];
  readonly status: OfficialSmsOrderStatus;
  readonly price: OrderPriceSnapshot;
  readonly createdAt: string;
  readonly updatedAt: string;
  readonly expiresAt?: string;
  readonly smsReceivedAt?: string;
  readonly completedAt?: string;
  readonly failureCode?: string;
}

const transitions: Readonly<Record<OfficialSmsOrderStatus, readonly OfficialSmsOrderStatus[]>> = {
  CREATED: ['PAYMENT_RESERVED', 'FAILED', 'CANCELLED'],
  PAYMENT_RESERVED: ['PURCHASING', 'FAILED', 'CANCELLED'],
  PURCHASING: ['ACTIVE', 'FAILED'],
  ACTIVE: ['SMS_RECEIVED', 'EXPIRED', 'CANCELLED', 'FAILED'],
  SMS_RECEIVED: ['COMPLETED', 'EXPIRED', 'FAILED'],
  COMPLETED: [],
  FAILED: [],
  EXPIRED: [],
  CANCELLED: [],
};

export function canTransition(
  from: OfficialSmsOrderStatus,
  to: OfficialSmsOrderStatus,
): boolean {
  return transitions[from].includes(to);
}

export function attachProviderActivation(
  order: SmsOrder,
  input: { readonly providerOrderId: string; readonly phone: string; readonly expiresAt?: string; readonly sms?: SmsOrder['sms'] },
  now = new Date(),
): SmsOrder {
  if (order.status !== 'PURCHASING') throw new Error(`Cannot attach provider activation while order is ${order.status}`);
  return { ...order, providerOrderId: input.providerOrderId, phone: input.phone, expiresAt: input.expiresAt, ...(input.sms ? { sms: input.sms } : {}), updatedAt: now.toISOString() };
}

export function recordSms(order: SmsOrder, sms: SmsOrder['sms'], now = new Date()): SmsOrder {
  if (!['ACTIVE', 'SMS_RECEIVED'].includes(order.status)) throw new Error(`Cannot record SMS while order is ${order.status}`);
  const next = { ...order, sms, updatedAt: now.toISOString() };
  return sms.length > 0 && order.status === 'ACTIVE' ? transitionOrder(next, 'SMS_RECEIVED', now) : next;
}

export function transitionOrder(
  order: SmsOrder,
  to: OfficialSmsOrderStatus,
  now = new Date(),
): SmsOrder {
  if (!canTransition(order.status, to)) {
    throw new Error(`Invalid order transition: ${order.status} -> ${to}`);
  }

  const timestamp = now.toISOString();
  return {
    ...order,
    status: to,
    updatedAt: timestamp,
    ...(to === 'SMS_RECEIVED' ? { smsReceivedAt: timestamp } : {}),
    ...(to === 'COMPLETED' ? { completedAt: timestamp } : {}),
  };
}

export function createSmsOrder(input: {
  readonly id: string;
  readonly customerId: string;
  readonly purchaseIdempotencyKey: string;
  readonly provider: string;
  readonly country: string;
  readonly operator: string;
  readonly service: string;
  readonly price: OrderPriceSnapshot;
  readonly now?: Date;
}): SmsOrder {
  const now = (input.now ?? new Date()).toISOString();

  return {
    id: input.id,
    customerId: input.customerId,
    purchaseIdempotencyKey: input.purchaseIdempotencyKey,
    provider: input.provider,
    country: input.country,
    operator: input.operator,
    service: input.service,
    status: 'CREATED',
    sms: [],
    price: input.price,
    createdAt: now,
    updatedAt: now,
  };
}
