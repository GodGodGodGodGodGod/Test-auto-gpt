import type { OrderRepository } from '../application/orderRepository.js';
import type { SmsOrder } from '../domain/order.js';

export class InMemoryOrderRepository implements OrderRepository {
  private readonly orders = new Map<string, SmsOrder>();

  async create(order: SmsOrder): Promise<SmsOrder> {
    if (this.orders.has(order.id)) {
      throw new Error(`Order already exists: ${order.id}`);
    }
    this.orders.set(order.id, order);
    return order;
  }

  async findByPurchaseIdempotencyKey(customerId: string, key: string): Promise<SmsOrder | null> {
    for (const order of this.orders.values()) {
      if (order.customerId === customerId && order.purchaseIdempotencyKey === key) return order;
    }
    return null;
  }

  async findById(id: string): Promise<SmsOrder | null> {
    return this.orders.get(id) ?? null;
  }

  async listPollableIds(limit: number): Promise<readonly string[]> {
    return [...this.orders.values()]
      .filter((order) => ['ACTIVE', 'SMS_RECEIVED'].includes(order.status) && order.providerOrderId)
      .sort((a, b) => a.updatedAt.localeCompare(b.updatedAt))
      .slice(0, limit)
      .map((order) => order.id);
  }

  async update(order: SmsOrder): Promise<SmsOrder> {
    if (!this.orders.has(order.id)) {
      throw new Error(`Order not found: ${order.id}`);
    }
    this.orders.set(order.id, order);
    return order;
  }
}
