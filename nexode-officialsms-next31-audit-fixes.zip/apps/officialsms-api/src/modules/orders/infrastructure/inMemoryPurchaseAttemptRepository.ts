import type { PurchaseAttempt, PurchaseAttemptRepository } from '../application/purchaseAttemptRepository.js';

export class InMemoryPurchaseAttemptRepository implements PurchaseAttemptRepository {
  private readonly attempts = new Map<string, PurchaseAttempt>();

  async create(attempt: PurchaseAttempt): Promise<PurchaseAttempt> {
    if (this.attempts.has(attempt.id)) throw new Error(`Purchase attempt already exists: ${attempt.id}`);
    this.attempts.set(attempt.id, attempt);
    return attempt;
  }

  async findById(id: string): Promise<PurchaseAttempt | null> {
    return this.attempts.get(id) ?? null;
  }

  async findByOrderId(orderId: string): Promise<PurchaseAttempt | null> {
    for (const attempt of this.attempts.values()) {
      if (attempt.orderId === orderId) return attempt;
    }
    return null;
  }

  async update(attempt: PurchaseAttempt): Promise<PurchaseAttempt> {
    if (!this.attempts.has(attempt.id)) throw new Error(`Purchase attempt not found: ${attempt.id}`);
    this.attempts.set(attempt.id, attempt);
    return attempt;
  }
}
