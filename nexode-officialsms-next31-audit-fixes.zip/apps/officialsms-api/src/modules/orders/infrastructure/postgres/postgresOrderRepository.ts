import type { Pool } from 'pg';
import type { OrderRepository } from '../../application/orderRepository.js';
import type { SmsOrder } from '../../domain/order.js';

function mapOrder(row: Record<string, unknown>): SmsOrder {
  return {
    id: String(row.id),
    customerId: String(row.customer_id),
    purchaseIdempotencyKey: String(row.purchase_idempotency_key),
    provider: String(row.provider),
    ...(row.provider_order_id ? { providerOrderId: String(row.provider_order_id) } : {}),
    country: String(row.country),
    operator: String(row.operator),
    service: String(row.service),
    ...(row.phone ? { phone: String(row.phone) } : {}),
    sms: Array.isArray(row.sms) ? row.sms as SmsOrder['sms'] : (typeof row.sms === 'string' ? JSON.parse(row.sms) as SmsOrder['sms'] : []),
    status: row.status as SmsOrder['status'],
    price: {
      providerAmount: String(row.provider_amount),
      providerCurrency: String(row.provider_currency),
      customerAmount: String(row.customer_amount),
      customerCurrency: String(row.customer_currency),
      exchangeRate: String(row.exchange_rate),
      markupAmount: String(row.markup_amount),
      pricingRuleVersion: String(row.pricing_rule_version),
      rateSource: String(row.rate_source),
      rateCapturedAt: new Date(String(row.rate_captured_at)).toISOString(),
    },
    createdAt: new Date(String(row.created_at)).toISOString(),
    updatedAt: new Date(String(row.updated_at)).toISOString(),
    ...(row.expires_at ? { expiresAt: new Date(String(row.expires_at)).toISOString() } : {}),
    ...(row.sms_received_at ? { smsReceivedAt: new Date(String(row.sms_received_at)).toISOString() } : {}),
    ...(row.completed_at ? { completedAt: new Date(String(row.completed_at)).toISOString() } : {}),
    ...(row.failure_code ? { failureCode: String(row.failure_code) } : {}),
  };
}

export class PostgresOrderRepository implements OrderRepository {
  constructor(private readonly pool: Pool) {}

  async create(order: SmsOrder): Promise<SmsOrder> {
    const result = await this.pool.query(
      `INSERT INTO officialsms_orders
       (id, customer_id, purchase_idempotency_key, provider, provider_order_id, country, operator, service, phone,
        status, sms, provider_amount, provider_currency, customer_amount, customer_currency, exchange_rate, markup_amount,
        pricing_rule_version, rate_source, rate_captured_at, created_at, updated_at, expires_at, sms_received_at, completed_at, failure_code)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21,$22,$23,$24,$25,$26,$27)
       RETURNING *`,
      [order.id, order.customerId, order.purchaseIdempotencyKey, order.provider, order.providerOrderId ?? null,
        order.country, order.operator, order.service, order.phone ?? null, order.status, JSON.stringify(order.sms),
        order.price.providerAmount, order.price.providerCurrency, order.price.customerAmount, order.price.customerCurrency,
        order.price.exchangeRate, order.price.markupAmount, order.price.pricingRuleVersion, order.price.rateSource,
        order.price.rateCapturedAt, order.createdAt, order.expiresAt ?? null, order.smsReceivedAt ?? null,
        order.completedAt ?? null, order.failureCode ?? null],
    );
    return mapOrder(result.rows[0]);
  }

  async findById(id: string): Promise<SmsOrder | null> {
    const result = await this.pool.query('SELECT * FROM officialsms_orders WHERE id = $1', [id]);
    return result.rows[0] ? mapOrder(result.rows[0]) : null;
  }

  async findByPurchaseIdempotencyKey(customerId: string, key: string): Promise<SmsOrder | null> {
    const result = await this.pool.query(
      'SELECT * FROM officialsms_orders WHERE customer_id = $1 AND purchase_idempotency_key = $2',
      [customerId, key],
    );
    return result.rows[0] ? mapOrder(result.rows[0]) : null;
  }

  async listPollableIds(limit: number): Promise<readonly string[]> {
    if (!Number.isInteger(limit) || limit < 1 || limit > 1000) throw new Error('Invalid pollable order limit');
    const result = await this.pool.query(
      `SELECT id FROM officialsms_orders
       WHERE status IN ('ACTIVE','SMS_RECEIVED') AND provider_order_id IS NOT NULL
       ORDER BY updated_at ASC LIMIT $1`, [limit],
    );
    return result.rows.map((row) => String(row.id));
  }

  async update(order: SmsOrder): Promise<SmsOrder> {
    const result = await this.pool.query(
      `UPDATE officialsms_orders SET
        provider_order_id = $1, phone = $2, sms = $3, status = $4, updated_at = $5, expires_at = $6,
        sms_received_at = $7, completed_at = $8, failure_code = $9
       WHERE id = $10 RETURNING *`,
      [order.providerOrderId ?? null, order.phone ?? null, JSON.stringify(order.sms), order.status, order.updatedAt,
        order.expiresAt ?? null, order.smsReceivedAt ?? null, order.completedAt ?? null, order.failureCode ?? null, order.id],
    );
    if (!result.rows[0]) throw new Error(`Order not found: ${order.id}`);
    return mapOrder(result.rows[0]);
  }
}
