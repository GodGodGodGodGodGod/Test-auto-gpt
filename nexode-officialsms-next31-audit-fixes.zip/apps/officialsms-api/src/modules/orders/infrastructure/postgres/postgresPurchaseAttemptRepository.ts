import type { Pool } from 'pg';
import type { PurchaseAttempt, PurchaseAttemptRepository } from '../../application/purchaseAttemptRepository.js';

function mapAttempt(row: Record<string, unknown>): PurchaseAttempt {
  return {
    id: String(row.id),
    orderId: String(row.order_id),
    provider: String(row.provider),
    status: row.status as PurchaseAttempt['status'],
    country: String(row.country),
    operator: String(row.operator),
    service: String(row.service),
    walletId: String(row.wallet_id),
    reservationId: String(row.reservation_id),
    maxProviderPrice: Number(row.max_provider_price),
    ...(row.provider_order_id ? { providerOrderId: String(row.provider_order_id) } : {}),
    ...(row.error_code ? { errorCode: String(row.error_code) } : {}),
    ...(row.error_message ? { errorMessage: String(row.error_message) } : {}),
    createdAt: new Date(String(row.created_at)).toISOString(),
    updatedAt: new Date(String(row.updated_at)).toISOString(),
    ...(row.submitted_at ? { submittedAt: new Date(String(row.submitted_at)).toISOString() } : {}),
    ...(row.resolved_at ? { resolvedAt: new Date(String(row.resolved_at)).toISOString() } : {}),
  };
}

export class PostgresPurchaseAttemptRepository implements PurchaseAttemptRepository {
  constructor(private readonly pool: Pool) {}

  async create(attempt: PurchaseAttempt): Promise<PurchaseAttempt> {
    const result = await this.pool.query(
      `INSERT INTO officialsms_purchase_attempts
       (id, order_id, provider, status, country, operator, service, wallet_id, reservation_id, max_provider_price,
        provider_order_id, error_code, error_message, created_at, updated_at, submitted_at, resolved_at)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17) RETURNING *`,
      [attempt.id, attempt.orderId, attempt.provider, attempt.status, attempt.country, attempt.operator,
        attempt.service, attempt.walletId, attempt.reservationId, attempt.maxProviderPrice, attempt.providerOrderId ?? null, attempt.errorCode ?? null,
        attempt.errorMessage ?? null, attempt.createdAt, attempt.updatedAt, attempt.submittedAt ?? null, attempt.resolvedAt ?? null],
    );
    return mapAttempt(result.rows[0]);
  }

  async findById(id: string): Promise<PurchaseAttempt | null> {
    const result = await this.pool.query('SELECT * FROM officialsms_purchase_attempts WHERE id = $1', [id]);
    return result.rows[0] ? mapAttempt(result.rows[0]) : null;
  }

  async findByOrderId(orderId: string): Promise<PurchaseAttempt | null> {
    const result = await this.pool.query(
      'SELECT * FROM officialsms_purchase_attempts WHERE order_id = $1 ORDER BY created_at DESC LIMIT 1',
      [orderId],
    );
    return result.rows[0] ? mapAttempt(result.rows[0]) : null;
  }

  async update(attempt: PurchaseAttempt): Promise<PurchaseAttempt> {
    const result = await this.pool.query(
      `UPDATE officialsms_purchase_attempts SET
        status = $1, provider_order_id = $2, error_code = $3, error_message = $4,
        updated_at = $5, submitted_at = $6, resolved_at = $7
       WHERE id = $8 RETURNING *`,
      [attempt.status, attempt.providerOrderId ?? null, attempt.errorCode ?? null, attempt.errorMessage ?? null,
        attempt.updatedAt, attempt.submittedAt ?? null, attempt.resolvedAt ?? null, attempt.id],
    );
    if (!result.rows[0]) throw new Error(`Purchase attempt not found: ${attempt.id}`);
    return mapAttempt(result.rows[0]);
  }
}
