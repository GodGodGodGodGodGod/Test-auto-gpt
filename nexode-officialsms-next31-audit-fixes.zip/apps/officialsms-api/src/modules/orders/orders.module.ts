import { InMemoryOrderRepository } from './infrastructure/inMemoryOrderRepository.js';
import { PostgresOrderRepository } from './infrastructure/postgres/postgresOrderRepository.js';
import { PostgresPurchaseAttemptRepository } from './infrastructure/postgres/postgresPurchaseAttemptRepository.js';
import { InMemoryPurchaseAttemptRepository } from './infrastructure/inMemoryPurchaseAttemptRepository.js';
import { OrderService } from './application/orderService.js';

export function createOrderModule() {
  const orderRepository = new InMemoryOrderRepository();
  const purchaseAttemptRepository = new InMemoryPurchaseAttemptRepository();
  return {
    orderRepository,
    purchaseAttemptRepository,
    orderService: new OrderService(orderRepository),
  };
}

export function createOrderService(): OrderService {
  return createOrderModule().orderService;
}

export function createPostgresOrderModule(pool: import('pg').Pool) {
  const orderRepository = new PostgresOrderRepository(pool);
  const purchaseAttemptRepository = new PostgresPurchaseAttemptRepository(pool);
  return {
    orderRepository,
    purchaseAttemptRepository,
    orderService: new OrderService(orderRepository),
  };
}
