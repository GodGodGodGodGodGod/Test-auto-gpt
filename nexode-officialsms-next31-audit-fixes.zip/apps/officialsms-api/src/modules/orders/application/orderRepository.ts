import type { SmsOrder } from '../domain/order.js';

export interface OrderRepository {
  create(order: SmsOrder): Promise<SmsOrder>;
  findById(id: string): Promise<SmsOrder | null>;
  findByPurchaseIdempotencyKey(customerId: string, key: string): Promise<SmsOrder | null>;
  update(order: SmsOrder): Promise<SmsOrder>;
  listPollableIds(limit: number): Promise<readonly string[]>;
}
