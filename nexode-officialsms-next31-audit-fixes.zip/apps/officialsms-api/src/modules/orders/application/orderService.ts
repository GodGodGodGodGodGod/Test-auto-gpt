import type { OrderRepository } from './orderRepository.js';
import {
  createSmsOrder,
  attachProviderActivation,
  transitionOrder,
  type OfficialSmsOrderStatus,
  type OrderPriceSnapshot,
  type SmsOrder,
  recordSms,
} from '../domain/order.js';

export class OrderService {
  constructor(private readonly repository: OrderRepository) {}

  async findById(id: string): Promise<SmsOrder | null> {
    return this.repository.findById(id);
  }

  async findByPurchaseIdempotencyKey(customerId: string, key: string): Promise<SmsOrder | null> {
    return this.repository.findByPurchaseIdempotencyKey(customerId, key);
  }

  async create(input: {
    readonly id: string;
    readonly customerId: string;
    readonly provider: string;
    readonly country: string;
    readonly operator: string;
    readonly service: string;
    readonly price: OrderPriceSnapshot;
    readonly purchaseIdempotencyKey: string;
    readonly now?: Date;
  }): Promise<SmsOrder> {
    const order = createSmsOrder(input);
    return this.repository.create(order);
  }

  async attachProviderActivation(
    id: string,
    input: { readonly providerOrderId: string; readonly phone: string; readonly expiresAt?: string; readonly sms?: SmsOrder['sms'] },
    now?: Date,
  ): Promise<SmsOrder> {
    const current = await this.repository.findById(id);
    if (!current) throw new Error(`Order not found: ${id}`);
    return this.repository.update(attachProviderActivation(current, input, now));
  }


  async recordSms(id: string, sms: SmsOrder['sms'], now?: Date): Promise<SmsOrder> {
    const current = await this.repository.findById(id);
    if (!current) throw new Error(`Order not found: ${id}`);
    return this.repository.update(recordSms(current, sms, now));
  }

  async transition(
    id: string,
    status: OfficialSmsOrderStatus,
    now?: Date,
  ): Promise<SmsOrder> {
    const current = await this.repository.findById(id);
    if (!current) throw new Error(`Order not found: ${id}`);

    return this.repository.update(transitionOrder(current, status, now));
  }
}
