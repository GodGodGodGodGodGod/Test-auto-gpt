export type PurchaseAttemptStatus =
  | 'CREATED'
  | 'SUBMITTED'
  | 'SUCCEEDED'
  | 'FAILED'
  | 'UNKNOWN'
  | 'RECONCILING';

export interface PurchaseAttempt {
  readonly id: string;
  readonly orderId: string;
  readonly provider: string;
  readonly status: PurchaseAttemptStatus;
  readonly country: string;
  readonly operator: string;
  readonly service: string;
  readonly walletId: string;
  readonly reservationId: string;
  readonly maxProviderPrice: number;
  readonly providerOrderId?: string;
  readonly errorCode?: string;
  readonly errorMessage?: string;
  readonly createdAt: string;
  readonly updatedAt: string;
  readonly submittedAt?: string;
  readonly resolvedAt?: string;
}

export interface PurchaseAttemptRepository {
  create(attempt: PurchaseAttempt): Promise<PurchaseAttempt>;
  findById(id: string): Promise<PurchaseAttempt | null>;
  findByOrderId(orderId: string): Promise<PurchaseAttempt | null>;
  update(attempt: PurchaseAttempt): Promise<PurchaseAttempt>;
}
