import type { Money } from './money.js';

export type LedgerAccountType = 'ASSET' | 'LIABILITY' | 'REVENUE' | 'EXPENSE';
export type LedgerEntrySide = 'DEBIT' | 'CREDIT';

export interface LedgerAccount {
  readonly id: string;
  readonly type: LedgerAccountType;
  readonly currency: string;
}

export interface LedgerEntry {
  readonly id: string;
  readonly accountId: string;
  readonly side: LedgerEntrySide;
  readonly money: Money;
}

export interface LedgerTransaction {
  readonly id: string;
  readonly idempotencyKey: string;
  readonly description: string;
  readonly createdAt: string;
  readonly entries: readonly LedgerEntry[];
}

export function assertBalanced(entries: readonly LedgerEntry[]): void {
  if (entries.length < 2) throw new Error('A ledger transaction requires at least two entries');
  const totals = new Map<string, bigint>();
  for (const entry of entries) {
    const current = totals.get(entry.money.currency) ?? 0n;
    const signed = entry.side === 'DEBIT' ? entry.money.amountMinor : -entry.money.amountMinor;
    totals.set(entry.money.currency, current + signed);
  }
  for (const [currency, total] of totals) {
    if (total !== 0n) throw new Error(`Unbalanced ledger transaction for ${currency}`);
  }
}

export function createLedgerTransaction(input: {
  id: string;
  idempotencyKey: string;
  description: string;
  entries: readonly LedgerEntry[];
  now?: Date;
}): LedgerTransaction {
  assertBalanced(input.entries);
  return {
    id: input.id,
    idempotencyKey: input.idempotencyKey,
    description: input.description,
    createdAt: (input.now ?? new Date()).toISOString(),
    entries: input.entries.map((entry) => ({ ...entry, money: { ...entry.money } })),
  };
}
