export type CurrencyCode = string;

export interface Money {
  readonly amountMinor: bigint;
  readonly currency: CurrencyCode;
}

export function money(amountMinor: bigint | number | string, currency: CurrencyCode): Money {
  if (!/^[A-Z]{3}$/.test(currency)) throw new Error(`Invalid currency: ${currency}`);
  const value = typeof amountMinor === 'bigint' ? amountMinor : BigInt(amountMinor);
  if (value < 0n) throw new Error('Money amount cannot be negative');
  return { amountMinor: value, currency };
}

export function assertSameCurrency(a: Money, b: Money): void {
  if (a.currency !== b.currency) throw new Error(`Currency mismatch: ${a.currency} vs ${b.currency}`);
}
