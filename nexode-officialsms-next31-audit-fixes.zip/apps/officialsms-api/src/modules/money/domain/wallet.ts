import type { LedgerTransaction } from './ledger.js';
import type { Money } from './money.js';

export interface Wallet {
  readonly id: string;
  readonly customerId: string;
  readonly currency: string;
  readonly createdAt: string;
}

export interface WalletReservation {
  readonly id: string;
  readonly walletId: string;
  readonly amount: Money;
  readonly idempotencyKey: string;
  readonly status: 'ACTIVE' | 'RELEASED' | 'CAPTURED';
  readonly createdAt: string;
  readonly updatedAt: string;
}

export function createWallet(input: { id: string; customerId: string; currency: string; now?: Date }): Wallet {
  return { id: input.id, customerId: input.customerId, currency: input.currency, createdAt: (input.now ?? new Date()).toISOString() };
}

export function createReservation(input: {
  id: string;
  wallet: Wallet;
  amount: Money;
  idempotencyKey: string;
  now?: Date;
}): WalletReservation {
  if (input.amount.currency !== input.wallet.currency) throw new Error('Wallet and reservation currencies must match');
  if (input.amount.amountMinor <= 0n) throw new Error('Reservation amount must be positive');
  const now = (input.now ?? new Date()).toISOString();
  return { id: input.id, walletId: input.wallet.id, amount: input.amount, idempotencyKey: input.idempotencyKey, status: 'ACTIVE', createdAt: now, updatedAt: now };
}

export function releaseReservation(reservation: WalletReservation, now = new Date()): WalletReservation {
  if (reservation.status !== 'ACTIVE') throw new Error(`Cannot release ${reservation.status} reservation`);
  return { ...reservation, status: 'RELEASED', updatedAt: now.toISOString() };
}

export function captureReservation(reservation: WalletReservation, now = new Date()): WalletReservation {
  if (reservation.status !== 'ACTIVE') throw new Error(`Cannot capture ${reservation.status} reservation`);
  return { ...reservation, status: 'CAPTURED', updatedAt: now.toISOString() };
}

export function assertReservationTransaction(transaction: LedgerTransaction, reservation: WalletReservation): void {
  const amount = reservation.amount.amountMinor;
  const matching = transaction.entries.some((entry) => entry.money.currency === reservation.amount.currency && entry.money.amountMinor === amount);
  if (!matching) throw new Error('Ledger transaction does not contain the reservation amount');
}
