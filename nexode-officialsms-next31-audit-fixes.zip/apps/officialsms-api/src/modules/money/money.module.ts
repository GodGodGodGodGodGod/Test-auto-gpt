import { InMemoryMoneyRepository } from './infrastructure/inMemoryMoneyRepository.js';
import { PostgresMoneyRepository } from './infrastructure/postgres/postgresMoneyRepository.js';
import { createPostgresPool } from './infrastructure/postgres/createPostgresPool.js';
import { WalletService } from './application/walletService.js';
import type { MoneyRepository } from './application/moneyRepository.js';

export function createMoneyModule(repository?: MoneyRepository) {
  const resolvedRepository = repository ?? new InMemoryMoneyRepository();
  return { repository: resolvedRepository, walletService: new WalletService(resolvedRepository) };
}

export function createPostgresMoneyModule(databaseUrl: string) {
  const pool = createPostgresPool(databaseUrl);
  const repository = new PostgresMoneyRepository(pool);
  return {
    pool,
    repository,
    walletService: new WalletService(repository),
  };
}
