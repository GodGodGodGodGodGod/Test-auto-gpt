import { createReservation, captureReservation, releaseReservation, type WalletReservation } from '../domain/wallet.js';
import { money } from '../domain/money.js';
import { decimalToMinorUnits } from '../domain/currency.js';
import type { MoneyRepository } from './moneyRepository.js';

export class WalletService {
  constructor(private readonly repository: MoneyRepository) {}

  async reserve(input: {
    walletId: string;
    amountMinor: bigint | string | number;
    currency: string;
    idempotencyKey: string;
    reservationId: string;
  }): Promise<WalletReservation> {
    const existing = await this.repository.getReservationByIdempotency(input.walletId, input.idempotencyKey);
    if (existing) return existing;
    const wallet = await this.repository.getWallet(input.walletId);
    if (!wallet) throw new Error('Wallet not found');
    const reservation = createReservation({
      id: input.reservationId,
      wallet,
      amount: money(input.amountMinor, input.currency),
      idempotencyKey: input.idempotencyKey,
    });
    await this.repository.saveReservation(reservation);
    return reservation;
  }

  async release(walletId: string, reservationId: string): Promise<WalletReservation> {
    const reservation = await this.repository.getReservationById(walletId, reservationId);
    if (!reservation) throw new Error('Reservation not found');
    const updated = releaseReservation(reservation);
    await this.repository.updateReservation(updated);
    return updated;
  }

  async capture(walletId: string, reservationId: string, revenueAccountId = 'platform:revenue:sms'): Promise<WalletReservation> {
    const reservation = await this.repository.getReservationById(walletId, reservationId);
    if (!reservation) throw new Error('Reservation not found');
    const updated = captureReservation(reservation);
    await this.repository.captureReservationAtomically({ reservation: updated, revenueAccountId, now: new Date(updated.updatedAt) });
    return updated;
  }

  static toMinorUnits(amount: string | number, currency: string): bigint {
    return decimalToMinorUnits(amount, currency);
  }
}
