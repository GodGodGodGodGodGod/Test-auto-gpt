import type { LedgerTransaction } from '../domain/ledger.js';
import type { Wallet, WalletReservation } from '../domain/wallet.js';

export interface MoneyRepository {
  getWallet(walletId: string): Promise<Wallet | undefined>;
  getWalletByCustomerAndCurrency(customerId: string, currency: string): Promise<Wallet | undefined>;
  saveWallet(wallet: Wallet): Promise<void>;
  getReservationById(walletId: string, reservationId: string): Promise<WalletReservation | undefined>;
  getReservationByIdempotency(walletId: string, idempotencyKey: string): Promise<WalletReservation | undefined>;
  saveReservation(reservation: WalletReservation): Promise<void>;
  updateReservation(reservation: WalletReservation): Promise<void>;
  captureReservationAtomically(input: { reservation: WalletReservation; revenueAccountId: string; now: Date }): Promise<void>;
  appendLedgerTransaction(transaction: LedgerTransaction): Promise<void>;
  hasLedgerTransaction(idempotencyKey: string): Promise<boolean>;
}
