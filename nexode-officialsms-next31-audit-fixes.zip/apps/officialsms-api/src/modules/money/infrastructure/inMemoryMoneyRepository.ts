import type { LedgerTransaction } from '../domain/ledger.js';
import { createLedgerTransaction } from '../domain/ledger.js';
import { money } from '../domain/money.js';
import type { Wallet, WalletReservation } from '../domain/wallet.js';
import type { MoneyRepository } from '../application/moneyRepository.js';

export class InMemoryMoneyRepository implements MoneyRepository {
  private readonly wallets = new Map<string, Wallet>();
  private readonly reservations = new Map<string, WalletReservation>();
  private readonly ledger = new Map<string, LedgerTransaction>();

  async getWallet(walletId: string) { return this.wallets.get(walletId); }

  async getWalletByCustomerAndCurrency(customerId: string, currency: string) {
    for (const wallet of this.wallets.values()) {
      if (wallet.customerId === customerId && wallet.currency === currency) return wallet;
    }
    return undefined;
  }
  async saveWallet(wallet: Wallet) { this.wallets.set(wallet.id, wallet); }
  async getReservationById(walletId: string, reservationId: string) { return this.reservations.get(reservationId)?.walletId === walletId ? this.reservations.get(reservationId) : undefined; }
  async getReservationByIdempotency(walletId: string, idempotencyKey: string) {
    return [...this.reservations.values()].find((r) => r.walletId === walletId && r.idempotencyKey === idempotencyKey);
  }
  async saveReservation(reservation: WalletReservation) { this.reservations.set(reservation.id, reservation); }
  async updateReservation(reservation: WalletReservation) { this.reservations.set(reservation.id, reservation); }
  async captureReservationAtomically(input: { reservation: WalletReservation; revenueAccountId: string; now: Date }) {
    const current = this.reservations.get(input.reservation.id);
    if (!current) throw new Error('Reservation not found');
    if (current.status === 'CAPTURED') return;
    if (current.status !== 'ACTIVE') throw new Error(`Cannot capture ${current.status} reservation`);
    this.reservations.set(input.reservation.id, input.reservation);
    const transaction = createLedgerTransaction({
      id: `ltx_sms_${input.reservation.id}`,
      idempotencyKey: `sms-purchase:${input.reservation.id}`,
      description: `SMS purchase ${input.reservation.id}`,
      entries: [
        { id: `le_sms_${input.reservation.id}_wallet`, accountId: `wallet:${input.reservation.walletId}`, side: 'DEBIT', money: input.reservation.amount },
        { id: `le_sms_${input.reservation.id}_revenue`, accountId: input.revenueAccountId, side: 'CREDIT', money: money(input.reservation.amount.amountMinor, input.reservation.amount.currency) },
      ],
      now: input.now,
    });
    if (![...this.ledger.values()].some((item) => item.idempotencyKey === transaction.idempotencyKey)) this.ledger.set(transaction.id, transaction);
  }
  async appendLedgerTransaction(transaction: LedgerTransaction) {
    if (this.ledger.has(transaction.id)) throw new Error('Ledger transaction already exists');
    if ([...this.ledger.values()].some((item) => item.idempotencyKey === transaction.idempotencyKey)) throw new Error('Ledger idempotency key already exists');
    this.ledger.set(transaction.id, transaction);
  }
  async hasLedgerTransaction(idempotencyKey: string) { return [...this.ledger.values()].some((item) => item.idempotencyKey === idempotencyKey); }
}
