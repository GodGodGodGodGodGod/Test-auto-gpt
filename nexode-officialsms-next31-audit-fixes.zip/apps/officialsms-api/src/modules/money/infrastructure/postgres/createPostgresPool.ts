import { Pool } from 'pg';

export function createPostgresPool(databaseUrl: string): Pool {
  if (!databaseUrl) throw new Error('DATABASE_URL is required for PostgreSQL money infrastructure');
  return new Pool({ connectionString: databaseUrl, max: 10, idleTimeoutMillis: 30_000, connectionTimeoutMillis: 5_000 });
}
