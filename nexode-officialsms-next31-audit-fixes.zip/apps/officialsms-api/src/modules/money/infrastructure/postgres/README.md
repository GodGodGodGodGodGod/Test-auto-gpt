# OfficialSMS PostgreSQL money infrastructure

This adapter persists wallets, reservations, and immutable ledger transactions in PostgreSQL.

The migration in `apps/officialsms-api/migrations/0001_money/migration.sql` creates the OfficialSMS-specific tables. It intentionally does not create or own NeXoDe identity tables.

## Safety properties

- Monetary amounts use PostgreSQL `NUMERIC(39,0)` and are exchanged with TypeScript as `bigint`.
- Wallet reservation locks the wallet row with `FOR UPDATE` before checking available funds.
- Reservation idempotency is enforced by a unique database constraint.
- Reservation release/capture updates wallet totals and reservation state in one database transaction.
- Ledger transaction idempotency is enforced by a unique database constraint.
- Ledger entries are inserted in the same transaction as their parent ledger transaction.
