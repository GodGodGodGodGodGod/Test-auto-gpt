import type { SmsProvider } from '../../../providers/ports/sms-provider.js';
import type { OrderService } from '../../orders/application/orderService.js';

export type SmsPollOutcome = 'IGNORED' | 'UPDATED' | 'RECEIVED' | 'FAILED';

export interface SmsPollResult {
  readonly outcome: SmsPollOutcome;
  readonly orderId: string;
  readonly providerOrderId?: string;
  readonly smsCount: number;
}

/** Polls an already-purchased activation. It never purchases or refunds anything. */
export class SmsPollingService {
  constructor(
    private readonly provider: SmsProvider,
    private readonly orders: OrderService,
  ) {}

  async poll(orderId: string): Promise<SmsPollResult> {
    const order = await this.orders.findById(orderId);
    if (!order) throw new Error(`Order not found: ${orderId}`);
    if (!order.providerOrderId) return { outcome: 'IGNORED', orderId, smsCount: order.sms.length };
    if (!['ACTIVE', 'SMS_RECEIVED'].includes(order.status)) {
      return { outcome: 'IGNORED', orderId, providerOrderId: order.providerOrderId, smsCount: order.sms.length };
    }

    const activation = await this.provider.check(order.providerOrderId);
    const sms = activation.sms;
    const currentIds = new Set(order.sms.map((message) => message.id).filter((id): id is number => id !== undefined));
    const hasNewSms = sms.some((message) => message.id !== undefined && !currentIds.has(message.id));

    await this.orders.recordSms(orderId, sms);

    if (['CANCELED', 'TIMEOUT', 'BANNED'].includes(activation.status)) {
      if ((await this.orders.findById(orderId))?.status === 'ACTIVE') await this.orders.transition(orderId, 'FAILED');
      return { outcome: 'FAILED', orderId, providerOrderId: activation.id, smsCount: sms.length };
    }

    return {
      outcome: hasNewSms || sms.length > 0 ? 'RECEIVED' : 'UPDATED',
      orderId,
      providerOrderId: activation.id,
      smsCount: sms.length,
    };
  }
}

export interface SmsPollingScheduler {
  start(): void;
  stop(): void;
}

export class IntervalSmsPollingScheduler implements SmsPollingScheduler {
  private timer?: ReturnType<typeof setInterval>;

  constructor(
    private readonly poll: () => Promise<void>,
    private readonly intervalMs: number,
  ) {}

  start(): void {
    if (this.timer) return;
    this.timer = setInterval(() => {
      void this.poll().catch(() => undefined);
    }, this.intervalMs);
  }

  stop(): void {
    if (!this.timer) return;
    clearInterval(this.timer);
    this.timer = undefined;
  }
}
