import type { Pool } from 'pg';
import type { RefreshTokenRecord, RefreshTokenStore } from '@nexode/auth';

export class PostgresRefreshTokenStore implements RefreshTokenStore {
  constructor(private readonly db: Pool) {}

  async findByHash(tokenHash: string): Promise<RefreshTokenRecord | undefined> {
    const result = await this.db.query(
      `SELECT token_hash, user_id, session_id, family_id, issued_at, expires_at, revoked_at, replaced_by_hash
         FROM nexode_identity_refresh_tokens WHERE token_hash = $1 LIMIT 1`, [tokenHash]);
    const row = result.rows[0] as Record<string, unknown> | undefined;
    return row ? map(row) : undefined;
  }

  async save(record: RefreshTokenRecord): Promise<void> {
    await this.db.query(
      `INSERT INTO nexode_identity_refresh_tokens
       (token_hash,user_id,session_id,family_id,issued_at,expires_at,revoked_at,replaced_by_hash)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8)
       ON CONFLICT (token_hash) DO NOTHING`,
      [record.tokenHash, record.userId, record.sessionId, record.familyId, record.issuedAt, record.expiresAt, record.revokedAt ?? null, record.replacedByHash ?? null]);
  }

  async rotate(currentHash: string, next: RefreshTokenRecord): Promise<boolean> {
    const client = await this.db.connect();
    try {
      await client.query('BEGIN');
      const updated = await client.query(`UPDATE nexode_identity_refresh_tokens SET revoked_at = now(), replaced_by_hash = $2 WHERE token_hash = $1 AND revoked_at IS NULL AND expires_at > now() RETURNING token_hash`, [currentHash, next.tokenHash]);
      if (updated.rowCount !== 1) { await client.query('ROLLBACK'); return false; }
      await client.query(`INSERT INTO nexode_identity_refresh_tokens (token_hash,user_id,session_id,family_id,issued_at,expires_at) VALUES ($1,$2,$3,$4,$5,$6)`, [next.tokenHash,next.userId,next.sessionId,next.familyId,next.issuedAt,next.expiresAt]);
      await client.query('COMMIT');
      return true;
    } catch (error) { await client.query('ROLLBACK'); throw error; } finally { client.release(); }
  }

  async revoke(tokenHash: string, replacedByHash?: string): Promise<void> {
    await this.db.query(`UPDATE nexode_identity_refresh_tokens SET revoked_at = COALESCE(revoked_at, now()), replaced_by_hash = COALESCE($2, replaced_by_hash) WHERE token_hash = $1`, [tokenHash, replacedByHash ?? null]);
  }

  async revokeFamily(familyId: string): Promise<void> {
    await this.db.query(`UPDATE nexode_identity_refresh_tokens SET revoked_at = COALESCE(revoked_at, now()) WHERE family_id = $1 AND revoked_at IS NULL`, [familyId]);
  }
}

function map(row: Record<string, unknown>): RefreshTokenRecord {
  return {
    tokenHash: String(row.token_hash), userId: String(row.user_id), sessionId: String(row.session_id), familyId: String(row.family_id),
    issuedAt: new Date(String(row.issued_at)), expiresAt: new Date(String(row.expires_at)),
    revokedAt: row.revoked_at ? new Date(String(row.revoked_at)) : undefined,
    replacedByHash: row.replaced_by_hash ? String(row.replaced_by_hash) : undefined,
  };
}
