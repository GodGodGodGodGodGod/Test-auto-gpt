# OfficialSMS authentication security

Login failures are tracked by a hashed account key and a hashed account+IP key. Raw email/IP identifiers are not stored in the login-security table. After the configured threshold, the key is temporarily locked. Successful authentication resets the corresponding counters.

Security audit events are persisted separately and contain only operational metadata. Secrets and passwords are never recorded.


## Session management

Authenticated customers can list their active sessions, revoke a specific session, or revoke all other sessions. Session IDs are scoped to the authenticated user at the repository query level. Expired sessions are removed by the session cleanup command.

Endpoints:
- `GET /api/v1/auth/sessions`
- `DELETE /api/v1/auth/sessions/:sessionId`
- `POST /api/v1/auth/sessions/revoke-others`

The current session is identified from the verified access token's `sid` claim propagated by the API gateway; the client cannot choose another user's current session.
