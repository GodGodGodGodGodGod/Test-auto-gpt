import type { Pool, PoolClient } from 'pg';
import type { AuditEvent, AuditStore } from '@nexode/identity';

type QueryExecutor = Pick<Pool, 'query'> | Pick<PoolClient, 'query'>;

export class PostgresSecurityAuditStore implements AuditStore {
  constructor(private readonly db: QueryExecutor) {}

  async save(event: AuditEvent): Promise<void> {
    await this.db.query(
      `INSERT INTO officialsms_security_audit_events
        (id, user_id, action, resource, occurred_at, metadata)
       VALUES ($1, $2, $3, $4, $5, $6::jsonb)`,
      [event.id, event.userId ?? null, event.action, event.resource, event.timestamp, JSON.stringify(event.metadata ?? {})],
    );
  }

  async findByUserId(userId: string): Promise<readonly AuditEvent[]> {
    const result = await this.db.query<Row>(
      `SELECT id, user_id, action, resource, occurred_at, metadata
         FROM officialsms_security_audit_events
        WHERE user_id = $1
        ORDER BY occurred_at DESC`,
      [userId],
    );
    return result.rows.map(toEvent);
  }

  async getAll(): Promise<readonly AuditEvent[]> {
    const result = await this.db.query<Row>(
      `SELECT id, user_id, action, resource, occurred_at, metadata
         FROM officialsms_security_audit_events
        ORDER BY occurred_at DESC`,
    );
    return result.rows.map(toEvent);
  }
}

interface Row {
  id: string;
  user_id: string | null;
  action: string;
  resource: string;
  occurred_at: Date;
  metadata: Record<string, unknown> | null;
}

function toEvent(row: Row): AuditEvent {
  return {
    id: row.id,
    userId: row.user_id ?? undefined,
    action: row.action,
    resource: row.resource,
    timestamp: new Date(row.occurred_at),
    metadata: row.metadata ?? undefined,
  };
}
