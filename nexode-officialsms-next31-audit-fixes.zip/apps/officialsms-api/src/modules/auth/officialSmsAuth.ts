import { JwtTokenService } from '@nexode/auth';
import type { AccessTokenClaims, AccessTokenVerifier, AuthUser, AuthUserResolver } from '@nexode/api-gateway';
import type { UserRepository, SessionRepository } from '@nexode/identity';

export class OfficialSmsJwtVerifier implements AccessTokenVerifier {
  constructor(
    private readonly tokens: JwtTokenService,
    private readonly sessions: SessionRepository,
    private readonly idleTimeoutMs = 1800000,
  ) {}

  async verify(token: string): Promise<AccessTokenClaims> {
    const result = await this.tokens.verify(token);
    const sessionId = result.claims.sid;
    if (!sessionId) throw new Error('Session-bound access token required.');

    const session = await this.sessions.findById(sessionId);
    const now = Date.now();
    if (!session || session.userId !== result.subject || session.expiresAt.getTime() <= now) {
      throw new Error('Session is invalid or expired.');
    }
    if (now - session.lastActivityAt.getTime() >= this.idleTimeoutMs) {
      await this.sessions.delete(session.id);
      throw new Error('Session is idle-expired.');
    }
    await this.sessions.save({ ...session, lastActivityAt: new Date(now) });

    return {
      subject: result.subject,
      issuedAt: result.claims.iat,
      expiresAt: result.claims.exp,
      sessionId,
    };
  }
}

export class OfficialSmsAuthUserResolver implements AuthUserResolver {
  constructor(
    private readonly users: UserRepository,
    private readonly requireVerifiedEmail = true,
  ) {}

  async resolve(userId: string): Promise<AuthUser | null> {
    const user = await this.users.findById(userId);
    if (!user || !user.enabled) return null;
    if (this.requireVerifiedEmail && !user.emailVerified) return null;

    return {
      id: user.id,
      roles: user.roles,
      permissions: user.permissions,
      metadata: {
        email: user.email,
        username: user.username,
        displayName: user.displayName,
        emailVerified: user.emailVerified,
      },
    };
  }
}
