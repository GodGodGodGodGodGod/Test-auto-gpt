import { randomUUID } from 'node:crypto';
import type { GatewayRequest, GatewayResponse } from '@nexode/api-gateway';
import type { AuditManager, IdentitySession, SessionRepository } from '@nexode/identity';

export class SessionManagementController {
  constructor(
    private readonly sessions: SessionRepository,
    private readonly audit: AuditManager,
  ) {}

  async list(request: GatewayRequest, response: GatewayResponse): Promise<void> {
    const userId = request.user?.id;
    if (!userId) { response.status(401).send({ error: 'Authentication required' }); return; }
    const currentSessionId = request.sessionId ?? sessionIdFromUser(request.user?.metadata);
    const sessions = await this.sessions.findByUserId(userId);
    const now = Date.now();
    const active = sessions
      .filter((session) => session.expiresAt.getTime() > now)
      .map((session) => toPublicSession(session, session.id === currentSessionId));
    response.status(200).send({ sessions: active });
  }

  async revoke(request: GatewayRequest, response: GatewayResponse): Promise<void> {
    const userId = request.user?.id;
    if (!userId) { response.status(401).send({ error: 'Authentication required' }); return; }
    const sessionId = sessionIdFromParam(request.params.sessionId);
    if (!sessionId) { response.status(400).send({ error: 'Session ID is required' }); return; }
    const deleted = await this.sessions.deleteForUser(sessionId, userId);
    if (!deleted) { response.status(404).send({ error: 'Session not found' }); return; }
    await this.audit.record({
      id: `aud_${randomUUID()}`,
      userId,
      action: 'auth.session_revoked',
      resource: 'customer-session',
      timestamp: new Date(),
      metadata: { sessionId },
    });
    response.status(204).send();
  }

  async revokeOthers(request: GatewayRequest, response: GatewayResponse): Promise<void> {
    const userId = request.user?.id;
    const currentSessionId = request.sessionId ?? sessionIdFromUser(request.user?.metadata);
    if (!userId || !currentSessionId) { response.status(401).send({ error: 'Authentication required' }); return; }
    const revoked = await this.sessions.deleteAllForUserExcept(userId, currentSessionId);
    await this.audit.record({
      id: `aud_${randomUUID()}`,
      userId,
      action: 'auth.sessions_revoked_others',
      resource: 'customer-session',
      timestamp: new Date(),
      metadata: { currentSessionId, revokedCount: revoked },
    });
    response.status(200).send({ revokedCount: revoked });
  }
}

function sessionIdFromParam(value: unknown): string | undefined {
  return typeof value === 'string' && /^ses_[A-Za-z0-9_-]{10,128}$/.test(value) ? value : undefined;
}

function sessionIdFromUser(metadata: Record<string, unknown> | undefined): string | undefined {
  return typeof metadata?.sessionId === 'string' ? metadata.sessionId : undefined;
}

function toPublicSession(session: IdentitySession, current: boolean) {
  return {
    id: session.id,
    createdAt: session.createdAt.toISOString(),
    expiresAt: session.expiresAt.toISOString(),
    lastActivityAt: session.lastActivityAt.toISOString(),
    ipAddress: session.ipAddress,
    userAgent: session.userAgent,
    deviceName: session.deviceName,
    current,
  };
}
