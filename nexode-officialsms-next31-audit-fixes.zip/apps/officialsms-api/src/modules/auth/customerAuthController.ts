import { randomUUID } from 'node:crypto';
import { AuditManager } from '@nexode/identity';
import { PostgresLoginSecurityRepository } from './loginSecurity.js';
import { z } from 'zod';
import { JwtTokenService } from '@nexode/auth';
import type { GatewayRequest, GatewayResponse } from '@nexode/api-gateway';
import type { SessionRepository, UserRepository } from '@nexode/identity';
import { SecurePasswordHasher } from '@nexode/identity';

export const loginSchema = z.object({ email: z.string().trim().email().max(320), password: z.string().min(1).max(1024) });
export const refreshSchema = z.object({ refreshToken: z.string().min(1).max(4096) });

export class CustomerAuthController {
  private readonly hasher = new SecurePasswordHasher();
  constructor(
    private readonly users: UserRepository,
    private readonly sessions: SessionRepository,
    private readonly tokens: JwtTokenService,
    private readonly loginSecurity: PostgresLoginSecurityRepository,
    private readonly audit: AuditManager,
    private readonly lockThreshold = 5,
    private readonly lockDurationMs = 900_000,
  ) {}

  async login(request: GatewayRequest, response: GatewayResponse): Promise<void> {
    const parsed = loginSchema.safeParse(request.body);
    if (!parsed.success) { response.status(400).send({ error: 'Invalid login request', details: parsed.error.flatten() }); return; }
    const now = new Date();
    const accountKey = PostgresLoginSecurityRepository.accountKeyFor(parsed.data.email);
    const ipKey = PostgresLoginSecurityRepository.keyFor(parsed.data.email, request.ipAddress);
    const [accountLocked, ipLocked] = await Promise.all([
      this.loginSecurity.isLocked(accountKey, now),
      this.loginSecurity.isLocked(ipKey, now),
    ]);
    if (accountLocked || ipLocked) {
      await this.audit.record({ id: `aud_${randomUUID()}`, action: 'auth.login_blocked', resource: 'customer-auth', timestamp: now, metadata: { reason: 'lockout' } });
      response.status(429).send({ error: 'Too many failed login attempts. Try again later.' });
      return;
    }

    const user = await this.users.findByEmail(parsed.data.email);
    const valid = Boolean(user && user.enabled && user.emailVerified && (await this.hasher.verify(parsed.data.password, user.passwordHash)));
    if (!valid) {
      const [accountState, ipState] = await Promise.all([
        this.loginSecurity.recordFailure(accountKey, now, this.lockThreshold, this.lockDurationMs),
        this.loginSecurity.recordFailure(ipKey, now, this.lockThreshold, this.lockDurationMs),
      ]);
      await this.audit.record({ id: `aud_${randomUUID()}`, action: 'auth.login_failed', resource: 'customer-auth', timestamp: now, metadata: { accountLocked: Boolean(accountState.lockedUntil && accountState.lockedUntil > now), ipLocked: Boolean(ipState.lockedUntil && ipState.lockedUntil > now) } });
      response.status(401).send({ error: 'Invalid email or password' });
      return;
    }

    await Promise.all([this.loginSecurity.recordSuccess(accountKey, now), this.loginSecurity.recordSuccess(ipKey, now)]);
    const sessionId = `ses_${randomUUID()}`;
    await this.sessions.save({ id: sessionId, userId: user.id, createdAt: now, expiresAt: new Date(now.getTime() + 30 * 86400000), lastActivityAt: now, ipAddress: request.ipAddress, userAgent: request.headers['user-agent'] ?? request.headers['User-Agent'] });
    const identity = { id: user.id, email: user.email, username: user.username, displayName: user.displayName, roles: [...user.roles], permissions: [...user.permissions] };
    const pair = await this.tokens.issueForSession(identity, sessionId);
    await this.audit.record({ id: `aud_${randomUUID()}`, userId: user.id, action: 'auth.login_succeeded', resource: 'customer-auth', timestamp: now, metadata: { sessionId } });
    response.status(200).send({ accessToken: pair.accessToken, refreshToken: pair.refreshToken, tokenType: 'Bearer', expiresIn: 900, sessionId, user: { id: user.id, email: user.email, username: user.username, displayName: user.displayName, roles: user.roles, permissions: user.permissions } });
  }

  async refresh(request: GatewayRequest, response: GatewayResponse): Promise<void> {
    const parsed = refreshSchema.safeParse(request.body);
    if (!parsed.success) { response.status(400).send({ error: 'Invalid refresh request' }); return; }
    try {
      const pair = await this.tokens.refresh(parsed.data.refreshToken);
      response.status(200).send({ accessToken: pair.accessToken, refreshToken: pair.refreshToken, tokenType: 'Bearer', expiresIn: 900 });
    } catch { response.status(401).send({ error: 'Invalid or expired refresh token' }); }
  }

  async logout(request: GatewayRequest, response: GatewayResponse): Promise<void> {
    const sessionId = request.sessionId ?? (typeof request.user?.metadata?.sessionId === 'string' ? request.user.metadata.sessionId : undefined);
    if (sessionId) {
      await this.sessions.delete(sessionId);
      await this.audit.record({ id: `aud_${randomUUID()}`, userId: request.user?.id, action: 'auth.logout', resource: 'customer-auth', timestamp: new Date(), metadata: { sessionId } });
    }
    response.status(204).send();
  }
}
