import type { Pool, PoolClient } from 'pg';
import { createHash } from 'node:crypto';

type QueryExecutor = Pick<Pool, 'query'> | Pick<PoolClient, 'query'>;

export interface LoginSecurityState {
  readonly key: string;
  readonly failedAttempts: number;
  readonly lockedUntil?: Date;
  readonly lastFailedAt?: Date;
  readonly lastSucceededAt?: Date;
}

export class PostgresLoginSecurityRepository {
  constructor(private readonly db: QueryExecutor) {}

  async get(key: string): Promise<LoginSecurityState> {
    const result = await this.db.query<Row>(
      `SELECT security_key, failed_attempts, locked_until, last_failed_at, last_succeeded_at
         FROM officialsms_login_security
        WHERE security_key = $1`,
      [key],
    );
    const row = result.rows[0];
    if (!row) return { key, failedAttempts: 0 };
    return toState(row);
  }

  async recordFailure(key: string, now: Date, threshold: number, lockDurationMs: number): Promise<LoginSecurityState> {
    const result = await this.db.query<Row>(
      `INSERT INTO officialsms_login_security
        (security_key, failed_attempts, locked_until, last_failed_at, last_succeeded_at, updated_at)
       VALUES ($1, 1, NULL, $2, NULL, $2)
       ON CONFLICT (security_key) DO UPDATE SET
         failed_attempts = officialsms_login_security.failed_attempts + 1,
         locked_until = CASE
           WHEN officialsms_login_security.failed_attempts + 1 >= $3
           THEN $2 + ($4 * interval '1 millisecond')
           ELSE officialsms_login_security.locked_until
         END,
         last_failed_at = $2,
         updated_at = $2
       RETURNING security_key, failed_attempts, locked_until, last_failed_at, last_succeeded_at`,
      [key, now, threshold, lockDurationMs],
    );
    return toState(result.rows[0]!);
  }

  async recordSuccess(key: string, now: Date): Promise<void> {
    await this.db.query(
      `INSERT INTO officialsms_login_security
        (security_key, failed_attempts, locked_until, last_failed_at, last_succeeded_at, updated_at)
       VALUES ($1, 0, NULL, NULL, $2, $2)
       ON CONFLICT (security_key) DO UPDATE SET
         failed_attempts = 0,
         locked_until = NULL,
         last_succeeded_at = $2,
         updated_at = $2`,
      [key, now],
    );
  }

  async isLocked(key: string, now: Date): Promise<boolean> {
    const state = await this.get(key);
    return Boolean(state.lockedUntil && state.lockedUntil.getTime() > now.getTime());
  }

  static keyFor(email: string, ipAddress?: string): string {
    const normalized = email.trim().toLowerCase();
    const ip = ipAddress?.trim() || 'unknown';
    return createHash('sha256').update(`${normalized}\n${ip}`).digest('hex');
  }

  static accountKeyFor(email: string): string {
    return createHash('sha256').update(email.trim().toLowerCase()).digest('hex');
  }
}

interface Row {
  security_key: string;
  failed_attempts: number;
  locked_until: Date | null;
  last_failed_at: Date | null;
  last_succeeded_at: Date | null;
}

function toState(row: Row): LoginSecurityState {
  return {
    key: row.security_key,
    failedAttempts: row.failed_attempts,
    lockedUntil: row.locked_until ? new Date(row.locked_until) : undefined,
    lastFailedAt: row.last_failed_at ? new Date(row.last_failed_at) : undefined,
    lastSucceededAt: row.last_succeeded_at ? new Date(row.last_succeeded_at) : undefined,
  };
}
