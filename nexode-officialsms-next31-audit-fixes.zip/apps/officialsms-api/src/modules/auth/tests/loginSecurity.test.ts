import { describe, expect, it } from 'vitest';
import { PostgresLoginSecurityRepository } from '../loginSecurity.js';

describe('PostgresLoginSecurityRepository keys', () => {
  it('normalizes email and preserves IP separation', () => {
    expect(PostgresLoginSecurityRepository.accountKeyFor(' USER@Example.COM '))
      .toBe(PostgresLoginSecurityRepository.accountKeyFor('user@example.com'));
    expect(PostgresLoginSecurityRepository.keyFor('user@example.com', '127.0.0.1'))
      .not.toBe(PostgresLoginSecurityRepository.keyFor('user@example.com', '127.0.0.2'));
  });
});
