import { randomUUID } from 'node:crypto';
import { z } from 'zod';
import { EmailVerificationService, PasswordResetService, SecurePasswordHasher } from '@nexode/identity';
import type { UserRepository } from '@nexode/identity';
import type { GatewayRequest, GatewayResponse } from '@nexode/api-gateway';
import type { NotificationProvider } from '@nexode/notifications';

export const registerSchema = z.object({
  email: z.string().trim().email().max(320),
  username: z.string().trim().min(3).max(32).regex(/^[A-Za-z0-9_]+$/),
  displayName: z.string().trim().min(1).max(100).optional(),
  password: z.string().min(12).max(1024).refine((value) => /[A-Z]/.test(value) && /[a-z]/.test(value) && /[0-9]/.test(value) && /[^A-Za-z0-9]/.test(value), { message: 'Password must contain uppercase, lowercase, number, and symbol.' }),
});
export const verifyEmailSchema = z.object({ token: z.string().min(20).max(4096) });
export const forgotPasswordSchema = z.object({ email: z.string().trim().email().max(320) });
export const resetPasswordSchema = z.object({ token: z.string().min(20).max(4096), password: z.string().min(12).max(1024).refine((value) => /[A-Z]/.test(value) && /[a-z]/.test(value) && /[0-9]/.test(value) && /[^A-Za-z0-9]/.test(value), { message: 'Password must contain uppercase, lowercase, number, and symbol.' }) });

export class AccountLifecycleController {
  private readonly hasher = new SecurePasswordHasher();
  constructor(
    private readonly users: UserRepository,
    private readonly emailVerification: EmailVerificationService,
    private readonly passwordReset: PasswordResetService,
    private readonly notifications: NotificationProvider | undefined,
    private readonly verificationBaseUrl: string,
    private readonly resetBaseUrl: string,
    private readonly exposeTokensForDevelopment: boolean,
  ) {}

  async register(request: GatewayRequest, response: GatewayResponse): Promise<void> {
    const parsed = registerSchema.safeParse(request.body);
    if (!parsed.success) { response.status(400).send({ error: 'Invalid registration request', details: parsed.error.flatten() }); return; }
    const email = parsed.data.email.toLowerCase();
    const username = parsed.data.username.toLowerCase();
    if (!this.notifications) { response.status(503).send({ error: 'Account email delivery is temporarily unavailable.' }); return; }
    if (await this.users.findByEmail(email) || await this.users.findByUsername(username)) {
      response.status(409).send({ error: 'An account with those details already exists.' }); return;
    }
    const now = new Date();
    const user = {
      id: `usr_${randomUUID()}`,
      email, username, displayName: parsed.data.displayName,
      roles: ['customer'], permissions: [], createdAt: now, updatedAt: now,
      enabled: true, emailVerified: false,
      passwordHash: await this.hasher.hash(parsed.data.password),
    } as const;
    await this.users.save(user);
    const token = await this.emailVerification.createToken(user.id);
    await this.send('Verify your OfficialSMS email', `Verify your email: ${this.verificationBaseUrl}?token=${encodeURIComponent(token.token)}`, user.email);
    const body: Record<string, unknown> = { message: 'Account created. Check your email to verify your account.' };
    if (this.exposeTokensForDevelopment) body.verificationToken = token.token;
    response.status(201).send(body);
  }

  async verifyEmail(request: GatewayRequest, response: GatewayResponse): Promise<void> {
    const parsed = verifyEmailSchema.safeParse(request.body);
    if (!parsed.success) { response.status(400).send({ error: 'Invalid verification request' }); return; }
    try { await this.emailVerification.verify(parsed.data.token); response.status(204).send(); }
    catch { response.status(400).send({ error: 'Invalid or expired verification token' }); }
  }

  async forgotPassword(request: GatewayRequest, response: GatewayResponse): Promise<void> {
    const parsed = forgotPasswordSchema.safeParse(request.body);
    if (!parsed.success) { response.status(400).send({ error: 'Invalid password reset request' }); return; }
    if (!this.notifications) { response.status(503).send({ error: 'Password reset delivery is temporarily unavailable.' }); return; }
    const token = await this.passwordReset.request(parsed.data.email.toLowerCase());
    if (token && this.notifications) await this.send('Reset your OfficialSMS password', `Reset your password: ${this.resetBaseUrl}?token=${encodeURIComponent(token.token)}`, (await this.users.findById(token.userId))?.email);
    const body: Record<string, unknown> = { message: 'If an eligible account exists, password reset instructions have been sent.' };
    if (this.exposeTokensForDevelopment && token) body.resetToken = token.token;
    response.status(202).send(body);
  }

  async resetPassword(request: GatewayRequest, response: GatewayResponse): Promise<void> {
    const parsed = resetPasswordSchema.safeParse(request.body);
    if (!parsed.success) { response.status(400).send({ error: 'Invalid password reset request' }); return; }
    try { await this.passwordReset.reset(parsed.data.token, parsed.data.password); response.status(204).send(); }
    catch { response.status(400).send({ error: 'Invalid or expired password reset token' }); }
  }

  private async send(title: string, message: string, recipient?: string): Promise<void> {
    if (!this.notifications) throw new Error('Email notification provider is not configured.');
    const result = await this.notifications.send({ channel: 'email', title, message, recipient });
    if (!result.success) throw new Error('Email notification delivery failed.');
  }
}
