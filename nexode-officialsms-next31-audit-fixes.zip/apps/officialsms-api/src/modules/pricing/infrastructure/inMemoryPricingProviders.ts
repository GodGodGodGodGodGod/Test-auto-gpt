import type { ExchangeRate, ExchangeRateProvider, MarkupRule, MarkupRuleProvider } from '../domain/pricing.js';

export class StaticExchangeRateProvider implements ExchangeRateProvider {
  constructor(private readonly rates: ReadonlyMap<string, string>, private readonly source = 'static') {}
  async getRate(input: { readonly fromCurrency: string; readonly toCurrency: string }): Promise<ExchangeRate> {
    const from = input.fromCurrency.toUpperCase();
    const to = input.toCurrency.toUpperCase();
    if (from === to) return { fromCurrency: from, toCurrency: to, rate: '1', source: this.source, capturedAt: new Date().toISOString() };
    const rate = this.rates.get(`${from}/${to}`);
    if (!rate) throw new Error(`No exchange rate configured for ${from}/${to}`);
    return { fromCurrency: from, toCurrency: to, rate, source: this.source, capturedAt: new Date().toISOString() };
  }
}

export class StaticMarkupRuleProvider implements MarkupRuleProvider {
  constructor(private readonly rules: ReadonlyMap<string, MarkupRule>, private readonly fallback?: MarkupRule) {}
  async getRule(input: { readonly customerCurrency: string }): Promise<MarkupRule> {
    const rule = this.rules.get(input.customerCurrency.toUpperCase()) ?? this.fallback;
    if (!rule) throw new Error(`No markup rule configured for ${input.customerCurrency}`);
    return rule;
  }
}
