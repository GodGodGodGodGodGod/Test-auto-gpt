import type { ExchangeRate, ExchangeRateProvider } from '../domain/pricing.js';

interface FrankfurterRateResponse {
  readonly date?: string;
  readonly base?: string;
  readonly quote?: string;
  readonly rate?: number | string;
}

export interface FrankfurterExchangeRateProviderOptions {
  readonly baseUrl: string;
  readonly timeoutMs: number;
  readonly provider?: string;
  readonly fetchImpl?: typeof fetch;
}

/**
 * Production HTTP adapter for Frankfurter's v2 bilateral rate endpoint.
 * The pricing domain never depends on this provider directly.
 */
export class FrankfurterExchangeRateProvider implements ExchangeRateProvider {
  private readonly fetchImpl: typeof fetch;

  constructor(private readonly options: FrankfurterExchangeRateProviderOptions) {
    this.fetchImpl = options.fetchImpl ?? fetch;
  }

  async getRate(input: { readonly fromCurrency: string; readonly toCurrency: string }): Promise<ExchangeRate> {
    const from = input.fromCurrency.toUpperCase();
    const to = input.toCurrency.toUpperCase();
    if (from === to) {
      return { fromCurrency: from, toCurrency: to, rate: '1', source: this.sourceName(), capturedAt: new Date().toISOString() };
    }

    const url = new URL(`${this.options.baseUrl.replace(/\/$/, '')}/v2/rate/${encodeURIComponent(from.toLowerCase())}/${encodeURIComponent(to.toLowerCase())}`);
    if (this.options.provider) url.searchParams.set('providers', this.options.provider);

    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), this.options.timeoutMs);
    try {
      const response = await this.fetchImpl(url, { method: 'GET', headers: { Accept: 'application/json' }, signal: controller.signal });
      if (!response.ok) throw new Error(`Exchange-rate request failed with HTTP ${response.status}`);
      const payload = (await response.json()) as unknown;
      const parsed = parseRate(payload);
      if (parsed.base !== from || parsed.quote !== to || parsed.rate <= 0) throw new Error('Exchange-rate provider returned an invalid currency pair or rate');
      return {
        fromCurrency: from,
        toCurrency: to,
        rate: parsed.rateText,
        source: this.sourceName(),
        capturedAt: parsed.date ? new Date(`${parsed.date}T00:00:00.000Z`).toISOString() : new Date().toISOString(),
      };
    } finally {
      clearTimeout(timeout);
    }
  }

  private sourceName(): string {
    return this.options.provider ? `frankfurter:${this.options.provider}` : 'frankfurter:blended';
  }
}

function parseRate(value: unknown): { readonly base: string; readonly quote: string; readonly rate: number; readonly rateText: string; readonly date?: string } {
  if (typeof value !== 'object' || value === null) throw new Error('Exchange-rate provider returned an invalid payload');
  const row = value as FrankfurterRateResponse;
  if (typeof row.base !== 'string' || typeof row.quote !== 'string' || (typeof row.rate !== 'number' && typeof row.rate !== 'string')) {
    throw new Error('Exchange-rate provider returned an incomplete payload');
  }
  const rateText = String(row.rate);
  const rate = Number(rateText);
  if (!Number.isFinite(rate) || !/^\d+(?:\.\d+)?$/.test(rateText)) throw new Error('Exchange-rate provider returned an invalid rate');
  return { base: row.base.toUpperCase(), quote: row.quote.toUpperCase(), rate, rateText, date: row.date };
}
