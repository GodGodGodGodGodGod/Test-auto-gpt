import type { Pool } from 'pg';
import type { ExchangeRate, ExchangeRateProvider, MarkupRule, MarkupRuleProvider } from '../domain/pricing.js';

export class PostgresExchangeRateProvider implements ExchangeRateProvider {
  constructor(private readonly pool: Pool, private readonly upstream: ExchangeRateProvider, private readonly ttlMs: number) {}

  async getRate(input: { readonly fromCurrency: string; readonly toCurrency: string }): Promise<ExchangeRate> {
    const from = input.fromCurrency.toUpperCase();
    const to = input.toCurrency.toUpperCase();
    if (from === to) return { fromCurrency: from, toCurrency: to, rate: '1', source: 'identity', capturedAt: new Date().toISOString() };

    const cached = await this.pool.query<{ rate: string; source: string; captured_at: Date; expires_at: Date | null }>(
      `SELECT rate::text, source, captured_at, expires_at
       FROM officialsms_exchange_rates
       WHERE from_currency = $1 AND to_currency = $2
       ORDER BY captured_at DESC LIMIT 1`, [from, to],
    );
    const row = cached.rows[0];
    if (row && row.expires_at && row.expires_at.getTime() > Date.now()) {
      return { fromCurrency: from, toCurrency: to, rate: row.rate, source: row.source, capturedAt: row.captured_at.toISOString() };
    }

    const fresh = await this.upstream.getRate({ fromCurrency: from, toCurrency: to });
    const expiresAt = new Date(Date.now() + this.ttlMs);
    await this.pool.query(
      `INSERT INTO officialsms_exchange_rates (from_currency, to_currency, rate, source, captured_at, expires_at)
       VALUES ($1, $2, $3, $4, $5, $6)`,
      [from, to, fresh.rate, fresh.source, fresh.capturedAt, expiresAt],
    );
    return fresh;
  }
}

export class PostgresMarkupRuleProvider implements MarkupRuleProvider {
  constructor(private readonly pool: Pool) {}

  async getRule(input: { readonly customerCurrency: string }): Promise<MarkupRule> {
    const currency = input.customerCurrency.toUpperCase();
    const result = await this.pool.query<{
      percentage_bps: number;
      minimum_amount: string;
      maximum_amount: string | null;
      version: string;
    }>(
      `SELECT percentage_bps, minimum_amount::text, maximum_amount::text, version
       FROM officialsms_markup_rules
       WHERE customer_currency = $1 AND active = TRUE
       ORDER BY created_at DESC, id DESC LIMIT 1`, [currency],
    );
    const row = result.rows[0];
    if (!row) throw new Error(`No active markup rule configured for ${currency}`);
    return {
      version: row.version,
      percentageBps: BigInt(row.percentage_bps),
      minimumAmount: row.minimum_amount,
      maximumAmount: row.maximum_amount ?? undefined,
    };
  }
}
