import { PriceService } from './application/priceService.js';
import { StaticExchangeRateProvider, StaticMarkupRuleProvider } from './infrastructure/inMemoryPricingProviders.js';

export function createPricingService(): PriceService {
  const rates = new StaticExchangeRateProvider(new Map());
  const markupRules = new StaticMarkupRuleProvider(new Map(), {
    version: 'launch-default-v1',
    percentageBps: 1500n,
    minimumAmount: '0',
  });
  return new PriceService(rates, markupRules);
}
