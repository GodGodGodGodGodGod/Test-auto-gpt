import { describe, expect, it } from 'vitest';
import { FrankfurterExchangeRateProvider } from '../infrastructure/frankfurterExchangeRateProvider.js';

describe('FrankfurterExchangeRateProvider', () => {
  it('normalizes a valid bilateral response without using floating point for the stored rate', async () => {
    const provider = new FrankfurterExchangeRateProvider({
      baseUrl: 'https://api.frankfurter.dev', timeoutMs: 1000,
      fetchImpl: async () => new Response(JSON.stringify({ date: '2026-09-15', base: 'USD', quote: 'NGN', rate: 1500.25 }), { status: 200 }),
    });
    const rate = await provider.getRate({ fromCurrency: 'USD', toCurrency: 'NGN' });
    expect(rate.rate).toBe('1500.25');
    expect(rate.source).toBe('frankfurter:blended');
    expect(rate.capturedAt).toBe('2026-09-15T00:00:00.000Z');
  });
});
