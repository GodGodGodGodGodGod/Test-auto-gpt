import { describe, expect, it } from 'vitest';
import { quotePrice } from '../domain/pricing.js';
import { StaticExchangeRateProvider, StaticMarkupRuleProvider } from '../infrastructure/inMemoryPricingProviders.js';

describe('pricing engine', () => {
  it('converts provider cost, applies percentage markup and preserves exact decimals', async () => {
    const quote = await quotePrice({
      providerAmount: '0.10',
      providerCurrency: 'USD',
      customerCurrency: 'NGN',
      rates: new StaticExchangeRateProvider(new Map([['USD/NGN', '1500.25']])),
      markupRules: new StaticMarkupRuleProvider(new Map([['NGN', {
        version: 'ng-v1', percentageBps: 1500n, minimumAmount: '500', maximumAmount: '5000',
      }]])),
    });
    expect(quote.customerAmount).toBe('650.03');
    expect(quote.markupAmount).toBe('500');
    expect(quote.exchangeRate).toBe('1500.25');
    expect(quote.pricingRuleVersion).toBe('ng-v1');
  });

  it('uses the percentage when it exceeds the minimum', async () => {
    const quote = await quotePrice({
      providerAmount: '10', providerCurrency: 'USD', customerCurrency: 'USD',
      rates: new StaticExchangeRateProvider(new Map()),
      markupRules: new StaticMarkupRuleProvider(new Map([['USD', {
        version: 'usd-v1', percentageBps: 1500n, minimumAmount: '1', maximumAmount: '100',
      }]])),
    });
    expect(quote.markupAmount).toBe('1.5');
    expect(quote.customerAmount).toBe('11.5');
  });

  it('rejects missing rates', async () => {
    await expect(quotePrice({
      providerAmount: '1', providerCurrency: 'USD', customerCurrency: 'NGN',
      rates: new StaticExchangeRateProvider(new Map()),
      markupRules: new StaticMarkupRuleProvider(new Map()),
    })).rejects.toThrow('No exchange rate configured');
  });
});
