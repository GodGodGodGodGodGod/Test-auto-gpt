import type { ExchangeRateProvider, MarkupRuleProvider, PriceQuote } from '../domain/pricing.js';
import { quotePrice } from '../domain/pricing.js';

export class PriceService {
  constructor(private readonly rates: ExchangeRateProvider, private readonly markupRules: MarkupRuleProvider) {}
  quote(input: { readonly providerAmount: string; readonly providerCurrency: string; readonly customerCurrency: string }): Promise<PriceQuote> {
    return quotePrice({ ...input, rates: this.rates, markupRules: this.markupRules });
  }
}
