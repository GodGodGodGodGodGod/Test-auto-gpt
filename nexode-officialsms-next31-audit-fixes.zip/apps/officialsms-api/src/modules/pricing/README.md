# OfficialSMS Pricing

Pricing is deliberately separated from provider catalog and wallet accounting.

Pipeline:

`provider amount + provider currency -> exchange rate snapshot -> customer currency -> percentage markup -> exact customer amount`

Rules:
- Monetary calculations use decimal strings and `bigint` internally; floating-point arithmetic is not used for pricing decisions.
- Every quote captures the exchange-rate source/time and markup-rule version.
- Minimum and maximum markup limits are expressed in the customer's currency.
- Exchange rates and markup rules are persisted by migration `0006_pricing.sql`; ingestion/activation of an external rate source is a separate infrastructure concern.
- The initial static providers exist only for deterministic tests/local development and are not a production rate feed.
