const INTERNAL_SCALE = 18n;
const TEN = 10n;

type Parsed = { sign: bigint; digits: bigint; scale: bigint };

function parse(value: string): Parsed {
  const text = value.trim();
  if (!/^-?(?:0|[1-9]\d*)(?:\.\d+)?$/.test(text)) throw new Error(`Invalid decimal: ${value}`);
  const negative = text.startsWith('-');
  const unsigned = negative ? text.slice(1) : text;
  const [whole, fraction = ''] = unsigned.split('.');
  return { sign: negative ? -1n : 1n, digits: BigInt(`${whole}${fraction}`), scale: BigInt(fraction.length) };
}

export function normalizeDecimal(value: string): string {
  const p = parse(value);
  if (p.digits === 0n) return '0';
  let digits = p.digits.toString();
  const scale = Number(p.scale);
  if (scale === 0) return `${p.sign < 0n ? '-' : ''}${digits}`;
  if (digits.length <= scale) digits = digits.padStart(scale + 1, '0');
  const split = digits.length - scale;
  let whole = digits.slice(0, split);
  let fraction = digits.slice(split).replace(/0+$/, '');
  if (whole === '') whole = '0';
  return `${p.sign < 0n ? '-' : ''}${whole}${fraction ? `.${fraction}` : ''}`;
}

export function add(a: string, b: string): string {
  const x = toScaled(a), y = toScaled(b);
  return fromScaled(x + y);
}

export function multiply(a: string, b: string): string {
  const x = toScaled(a), y = toScaled(b);
  return fromScaled((x * y) / (TEN ** INTERNAL_SCALE));
}

export function divide(a: string, b: string): string {
  const denominator = toScaled(b);
  if (denominator === 0n) throw new Error('Division by zero');
  const numerator = toScaled(a) * (TEN ** INTERNAL_SCALE);
  return fromScaled(numerator / denominator);
}

export function min(a: string, b: string): string { return compare(a, b) <= 0 ? a : b; }
export function max(a: string, b: string): string { return compare(a, b) >= 0 ? a : b; }
export function compare(a: string, b: string): number {
  const x = toScaled(a), y = toScaled(b);
  return x < y ? -1 : x > y ? 1 : 0;
}

/** Round half-up to an ISO currency's minor-unit scale. */
export function roundToScale(value: string, scale: number): string {
  if (!Number.isInteger(scale) || scale < 0 || scale > 18) throw new Error(`Invalid decimal scale: ${scale}`);
  const p = parse(value);
  const target = BigInt(scale);
  const shift = p.scale - target;
  let digits: bigint;
  if (shift <= 0n) digits = p.digits * (TEN ** (-shift));
  else {
    const divisor = TEN ** shift;
    const quotient = p.digits / divisor;
    const remainder = p.digits % divisor;
    digits = quotient + (remainder * 2n >= divisor ? 1n : 0n);
  }
  return fromParts(p.sign, digits, target);
}

export function toScaled(value: string): bigint {
  const p = parse(value);
  if (p.scale > INTERNAL_SCALE) throw new Error(`Decimal exceeds ${INTERNAL_SCALE} fractional digits`);
  return p.sign * p.digits * (TEN ** (INTERNAL_SCALE - p.scale));
}

function fromScaled(value: bigint): string { return fromParts(value < 0n ? -1n : 1n, value < 0n ? -value : value, INTERNAL_SCALE); }

function fromParts(sign: bigint, digits: bigint, scale: bigint): string {
  if (digits === 0n) return '0';
  let text = digits.toString();
  const s = Number(scale);
  if (s > 0) {
    if (text.length <= s) text = text.padStart(s + 1, '0');
    const split = text.length - s;
    const fraction = text.slice(split).replace(/0+$/, '');
    text = `${text.slice(0, split)}${fraction ? `.${fraction}` : ''}`;
  }
  return `${sign < 0n ? '-' : ''}${text}`;
}
