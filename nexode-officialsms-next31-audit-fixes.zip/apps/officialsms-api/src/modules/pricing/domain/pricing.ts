import { add, compare, max, min, multiply, normalizeDecimal, roundToScale } from './decimal.js';
import { currencyScale } from '../../money/domain/currency.js';

export interface ExchangeRate {
  readonly fromCurrency: string;
  readonly toCurrency: string;
  /** Number of target-currency units for one source-currency unit. */
  readonly rate: string;
  readonly source: string;
  readonly capturedAt: string;
}

export interface ExchangeRateProvider {
  getRate(input: { readonly fromCurrency: string; readonly toCurrency: string }): Promise<ExchangeRate>;
}

export interface MarkupRule {
  readonly version: string;
  readonly percentageBps: bigint;
  readonly minimumAmount: string;
  readonly maximumAmount?: string;
}

export interface MarkupRuleProvider {
  getRule(input: { readonly customerCurrency: string }): Promise<MarkupRule>;
}

export interface PriceQuote {
  readonly providerAmount: string;
  readonly providerCurrency: string;
  readonly customerAmount: string;
  readonly customerCurrency: string;
  readonly exchangeRate: string;
  readonly markupAmount: string;
  readonly pricingRuleVersion: string;
  readonly rateSource: string;
  readonly rateCapturedAt: string;
}

export async function quotePrice(input: {
  readonly providerAmount: string;
  readonly providerCurrency: string;
  readonly customerCurrency: string;
  readonly rates: ExchangeRateProvider;
  readonly markupRules: MarkupRuleProvider;
}): Promise<PriceQuote> {
  const providerAmount = normalizeDecimal(input.providerAmount);
  if (compare(providerAmount, '0') < 0) throw new Error('Provider amount cannot be negative');
  const providerCurrency = normalizeCurrency(input.providerCurrency);
  const customerCurrency = normalizeCurrency(input.customerCurrency);
  const rate = await input.rates.getRate({ fromCurrency: providerCurrency, toCurrency: customerCurrency });
  if (normalizeCurrency(rate.fromCurrency) !== providerCurrency || normalizeCurrency(rate.toCurrency) !== customerCurrency) {
    throw new Error('Exchange-rate provider returned mismatched currencies');
  }
  if (compare(rate.rate, '0') <= 0) throw new Error('Exchange rate must be positive');

  const converted = roundToScale(multiply(providerAmount, rate.rate), currencyScale(customerCurrency));
  const rule = await input.markupRules.getRule({ customerCurrency });
  if (rule.percentageBps < 0n) throw new Error('Markup percentage cannot be negative');
  const percentageMarkup = roundToScale(multiply(converted, basisPointsToDecimal(rule.percentageBps)), currencyScale(customerCurrency));
  let markup = max(percentageMarkup, normalizeDecimal(rule.minimumAmount));
  if (rule.maximumAmount !== undefined) markup = min(markup, normalizeDecimal(rule.maximumAmount));
  if (compare(markup, '0') < 0 || (rule.maximumAmount !== undefined && compare(markup, rule.maximumAmount) > 0)) {
    throw new Error('Invalid markup rule: minimum/maximum constraints are inconsistent');
  }
  const customerAmount = add(converted, markup);
  return {
    providerAmount,
    providerCurrency,
    customerAmount: roundToScale(customerAmount, currencyScale(customerCurrency)),
    customerCurrency,
    exchangeRate: normalizeDecimal(rate.rate),
    markupAmount: roundToScale(markup, currencyScale(customerCurrency)),
    pricingRuleVersion: rule.version,
    rateSource: rate.source,
    rateCapturedAt: new Date(rate.capturedAt).toISOString(),
  };
}

function basisPointsToDecimal(bps: bigint): string {
  const whole = bps / 10000n;
  const fraction = (bps % 10000n).toString().padStart(4, '0').replace(/0+$/, '');
  return fraction ? `${whole}.${fraction}` : whole.toString();
}

function normalizeCurrency(value: string): string {
  const code = value.toUpperCase();
  if (!/^[A-Z]{3}$/.test(code)) throw new Error(`Invalid currency: ${value}`);
  return code;
}
