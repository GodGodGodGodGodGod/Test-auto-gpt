import type { Logger } from '@nexode/logger';

export type ProviderRequestOutcome = 'success' | 'error' | 'ambiguous';

export interface ProviderTelemetry {
  start(operation: string, provider: string, context?: Record<string, unknown>): (outcome: ProviderRequestOutcome, error?: unknown) => void;
}

export class LoggerProviderTelemetry implements ProviderTelemetry {
  constructor(private readonly logger: Logger) {}

  start(operation: string, provider: string, context: Record<string, unknown> = {}) {
    const started = Date.now();
    this.logger.debug('provider.request.started', { provider, operation, ...context });
    return (outcome: ProviderRequestOutcome, error?: unknown): void => {
      const payload = {
        provider,
        operation,
        outcome,
        durationMs: Date.now() - started,
        ...context,
        ...(error instanceof Error ? { errorName: error.name, errorMessage: error.message } : {}),
      };
      if (outcome === 'success') this.logger.info('provider.request.completed', payload);
      else if (outcome === 'ambiguous') this.logger.warn('provider.request.ambiguous', payload);
      else this.logger.error('provider.request.failed', payload);
    };
  }
}
