import type { OfficialSmsConfig } from '../../config/config.js';
import { logger } from '@nexode/logger';
import { LoggerProviderTelemetry } from '../observability/providerTelemetry.js';
import { createPostgresMoneyModule } from '../money/money.module.js';
import { createPostgresOrderModule } from '../orders/orders.module.js';
import { FiveSimProvider } from '../../providers/five-sim/fiveSimClient.js';
import { ReconcilePurchaseService } from '../activation/application/reconcilePurchaseService.js';
import { SmsPollingService } from '../sms/application/smsPollingService.js';
import { PostgresJobQueue } from './infrastructure/postgres/postgresJobQueue.js';
import { OfficialSmsWorker } from './application/officialSmsWorker.js';
import { SyncCatalogService } from '../catalog/application/syncCatalogService.js';
import { PostgresCatalogSnapshotRepository } from '../catalog/infrastructure/postgres/postgresCatalogSnapshotRepository.js';
import { FiveSimCatalogProvider } from '../catalog/infrastructure/fiveSimCatalogProvider.js';
import { CheckProviderHealthService } from '../provider-health/application/checkProviderHealthService.js';
import { PostgresProviderHealthRepository } from '../provider-health/infrastructure/postgres/postgresProviderHealthRepository.js';

export function createOfficialSmsWorker(config: OfficialSmsConfig): { worker: OfficialSmsWorker; close: () => Promise<void> } {
  const { pool: moneyPool, walletService } = createPostgresMoneyModule(config.databaseUrl);
  const orderModule = createPostgresOrderModule(moneyPool);
  const provider = new FiveSimProvider({
    baseUrl: config.fiveSim.baseUrl,
    apiKey: config.fiveSim.apiKey,
    timeoutMs: config.fiveSim.timeoutMs,
    currency: config.fiveSim.currency,
    telemetry: new LoggerProviderTelemetry(logger),
  });
  const queue = new PostgresJobQueue(moneyPool);
  const catalogProvider = new FiveSimCatalogProvider(config.fiveSim.baseUrl, config.fiveSim.timeoutMs, config.fiveSim.currency);
  const catalogRepository = new PostgresCatalogSnapshotRepository(moneyPool);
  const catalogSync = new SyncCatalogService(catalogRepository, catalogProvider, config.pricing.catalogTtlMs);
  const providerHealthRepository = new PostgresProviderHealthRepository(moneyPool);
  const providerHealth = new CheckProviderHealthService(provider, providerHealthRepository);
  const polling = new SmsPollingService(provider, orderModule.orderService);
  const reconciliation = new ReconcilePurchaseService(provider, orderModule.orderService, orderModule.purchaseAttemptRepository, walletService);
  const worker = new OfficialSmsWorker(queue, orderModule.orderRepository, polling, reconciliation, catalogSync, providerHealth, {
    workerId: `officialsms-worker:${process.pid}`,
    leaseMs: config.worker.leaseMs,
    pollIntervalMs: config.worker.pollIntervalMs,
    discoveryIntervalMs: config.worker.discoveryIntervalMs,
    discoveryBatchSize: config.worker.discoveryBatchSize,
    catalogSyncIntervalMs: config.worker.catalogSyncIntervalMs,
    providerHealthIntervalMs: config.worker.providerHealthIntervalMs,
  });
  return { worker, close: async () => { await moneyPool.end(); } };
}
