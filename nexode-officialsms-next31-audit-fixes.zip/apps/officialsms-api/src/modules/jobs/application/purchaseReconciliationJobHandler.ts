import type { Job, JobHandler } from '@nexode/jobs';
import type { ReconcilePurchaseService } from '../../activation/application/reconcilePurchaseService.js';

export interface PurchaseReconciliationJobPayload { readonly orderId: string; }

export class PurchaseReconciliationJobHandler implements JobHandler<PurchaseReconciliationJobPayload> {
  constructor(private readonly reconciliation: ReconcilePurchaseService) {}
  handle(payload: PurchaseReconciliationJobPayload, _job: Job<PurchaseReconciliationJobPayload>): Promise<void> {
    return this.reconciliation.reconcile(payload.orderId).then(() => undefined);
  }
}
