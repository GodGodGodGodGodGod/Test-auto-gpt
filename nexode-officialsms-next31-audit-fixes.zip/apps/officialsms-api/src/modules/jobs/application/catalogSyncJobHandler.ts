import type { Job, JobHandler } from '@nexode/jobs';
import type { SyncCatalogService } from '../../catalog/application/syncCatalogService.js';

export interface CatalogSyncJobPayload { readonly scope: 'global'; }
export class CatalogSyncJobHandler implements JobHandler<CatalogSyncJobPayload> {
  constructor(private readonly service: SyncCatalogService) {}
  handle(_payload: CatalogSyncJobPayload, _job: Job<CatalogSyncJobPayload>): Promise<void> { return this.service.syncGlobal(); }
}
