import type { Job, JobHandler } from '@nexode/jobs';
import type { CheckProviderHealthService } from '../../provider-health/application/checkProviderHealthService.js';

export interface ProviderHealthJobPayload { readonly provider: '5sim'; }
export class ProviderHealthJobHandler implements JobHandler<ProviderHealthJobPayload> {
  constructor(private readonly service: CheckProviderHealthService) {}
  handle(_payload: ProviderHealthJobPayload, _job: Job<ProviderHealthJobPayload>): Promise<void> { return this.service.execute(); }
}
