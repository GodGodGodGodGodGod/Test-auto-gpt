import type { JobQueue } from '@nexode/jobs';

export const JOB_TYPES = Object.freeze({
  SMS_POLL: 'officialsms.sms.poll',
  PURCHASE_RECONCILE: 'officialsms.purchase.reconcile',
  CATALOG_SYNC: 'officialsms.catalog.sync',
  PROVIDER_HEALTH: 'officialsms.provider.health',
});

export class OfficialSmsJobDispatcher {
  constructor(private readonly queue: JobQueue) {}

  enqueueSmsPoll(orderId: string): Promise<unknown> {
    return this.queue.enqueue({ id: `sms-poll:${orderId}:${crypto.randomUUID()}`, type: JOB_TYPES.SMS_POLL, payload: { orderId }, dedupeKey: `sms-poll:${orderId}`, maxAttempts: 8 });
  }

  enqueueCatalogSync(): Promise<unknown> {
    return this.queue.enqueue({ id: `catalog-sync:${crypto.randomUUID()}`, type: JOB_TYPES.CATALOG_SYNC, payload: { scope: 'global' }, dedupeKey: 'catalog-sync:global', maxAttempts: 6 });
  }

  enqueueProviderHealth(): Promise<unknown> {
    return this.queue.enqueue({ id: `provider-health:5sim:${crypto.randomUUID()}`, type: JOB_TYPES.PROVIDER_HEALTH, payload: { provider: '5sim' }, dedupeKey: 'provider-health:5sim', maxAttempts: 5 });
  }

  enqueuePurchaseReconciliation(orderId: string): Promise<unknown> {
    return this.queue.enqueue({ id: `purchase-reconcile:${orderId}:${crypto.randomUUID()}`, type: JOB_TYPES.PURCHASE_RECONCILE, payload: { orderId }, dedupeKey: `purchase-reconcile:${orderId}`, maxAttempts: 12 });
  }
}
