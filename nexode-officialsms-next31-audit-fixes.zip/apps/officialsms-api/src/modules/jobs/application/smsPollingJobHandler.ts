import type { Job, JobHandler } from '@nexode/jobs';
import type { SmsPollingService } from '../../sms/application/smsPollingService.js';

export interface SmsPollingJobPayload { readonly orderId: string; }

export class SmsPollingJobHandler implements JobHandler<SmsPollingJobPayload> {
  constructor(private readonly polling: SmsPollingService) {}
  handle(payload: SmsPollingJobPayload, _job: Job<SmsPollingJobPayload>): Promise<void> {
    return this.polling.poll(payload.orderId).then(() => undefined);
  }
}
