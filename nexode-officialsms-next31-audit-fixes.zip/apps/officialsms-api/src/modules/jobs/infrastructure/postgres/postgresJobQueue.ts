import type { Pool } from 'pg';
import type { EnqueueJobInput, Job } from '@nexode/jobs';
import type { JobQueue } from '@nexode/jobs';

function mapJob(row: Record<string, unknown>): Job {
  return {
    id: String(row.id), type: String(row.type), payload: row.payload,
    ...(row.dedupe_key ? { dedupeKey: String(row.dedupe_key) } : {}),
    status: row.status as Job['status'], attempts: Number(row.attempts), maxAttempts: Number(row.max_attempts),
    availableAt: new Date(String(row.available_at)).toISOString(),
    ...(row.locked_until ? { lockedUntil: new Date(String(row.locked_until)).toISOString() } : {}),
    ...(row.locked_by ? { lockedBy: String(row.locked_by) } : {}),
    ...(row.last_error ? { lastError: String(row.last_error) } : {}),
    createdAt: new Date(String(row.created_at)).toISOString(), updatedAt: new Date(String(row.updated_at)).toISOString(),
  };
}

export class PostgresJobQueue implements JobQueue {
  constructor(private readonly pool: Pool) {}

  async enqueue<TPayload>(input: EnqueueJobInput<TPayload>): Promise<Job<TPayload>> {
    const result = await this.pool.query(
      `INSERT INTO officialsms_jobs (id,type,payload,dedupe_key,status,attempts,max_attempts,available_at,created_at,updated_at)
       VALUES ($1,$2,$3,$4,'QUEUED',0,$5,$6,NOW(),NOW())
       ON CONFLICT (dedupe_key) WHERE status IN ('QUEUED','RUNNING')
       DO UPDATE SET updated_at = officialsms_jobs.updated_at
       RETURNING *`,
      [input.id, input.type, JSON.stringify(input.payload), input.dedupeKey ?? null, input.maxAttempts ?? 5, input.availableAt ?? new Date().toISOString()],
    );
    return mapJob(result.rows[0]) as Job<TPayload>;
  }

  async claim(workerId: string, leaseMs: number): Promise<Job | null> {
    const result = await this.pool.query(
      `WITH candidate AS (
         SELECT id FROM officialsms_jobs
         WHERE (status = 'QUEUED' AND available_at <= NOW())
            OR (status = 'RUNNING' AND locked_until < NOW())
         ORDER BY available_at ASC, created_at ASC
         FOR UPDATE SKIP LOCKED LIMIT 1
       )
       UPDATE officialsms_jobs j
       SET status='RUNNING', attempts=j.attempts+1,
           locked_by=$1, locked_until=NOW() + ($2::bigint * INTERVAL '1 millisecond'), updated_at=NOW()
       FROM candidate c WHERE j.id=c.id RETURNING j.*`,
      [workerId, leaseMs],
    );
    return result.rows[0] ? mapJob(result.rows[0]) : null;
  }

  async complete(jobId: string, workerId: string): Promise<void> {
    const result = await this.pool.query(
      `UPDATE officialsms_jobs SET status='SUCCEEDED', locked_by=NULL, locked_until=NULL, updated_at=NOW()
       WHERE id=$1 AND status='RUNNING' AND locked_by=$2`, [jobId, workerId],
    );
    if (result.rowCount !== 1) throw new Error(`Job is not owned by worker: ${jobId}`);
  }

  async fail(jobId: string, workerId: string, error: string, retryAt?: string): Promise<void> {
    const result = await this.pool.query(
      `UPDATE officialsms_jobs SET
         status = CASE WHEN $3::timestamptz IS NOT NULL AND attempts < max_attempts THEN 'QUEUED' ELSE 'FAILED' END,
         available_at = COALESCE($3::timestamptz, available_at), last_error=$4,
         locked_by=NULL, locked_until=NULL, updated_at=NOW()
       WHERE id=$1 AND status='RUNNING' AND locked_by=$2`, [jobId, workerId, retryAt ?? null, error.slice(0, 2000)],
    );
    if (result.rowCount !== 1) throw new Error(`Job is not owned by worker: ${jobId}`);
  }
}
