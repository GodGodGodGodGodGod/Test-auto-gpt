import type { DepositRepository } from './depositRepository.js';
import { createDepositIntent, transitionDeposit, type DepositIntent } from '../domain/deposit.js';
import type { PaymentProvider } from '../ports/payment-provider.js';
import type { Money } from '../../money/domain/money.js';

export class DepositService {
  constructor(
    private readonly repository: DepositRepository,
    private readonly provider: PaymentProvider,
  ) {}

  async create(input: {
    id: string;
    customerId: string;
    amount: Money;
    idempotencyKey: string;
    now?: Date;
  }): Promise<{ intent: DepositIntent; checkout: Awaited<ReturnType<PaymentProvider['createCheckout']>> }> {
    const existing = await this.repository.getByIdempotencyKey(input.customerId, input.idempotencyKey);
    if (existing) {
      const checkout = existing.providerReference
        ? { providerReference: existing.providerReference }
        : await this.provider.createCheckout({ depositId: existing.id, customerId: existing.customerId, amount: existing.amount });
      return { intent: existing, checkout };
    }

    const intent = createDepositIntent({ ...input, provider: this.provider.name });
    const checkout = await this.provider.createCheckout({
      depositId: intent.id,
      customerId: intent.customerId,
      amount: intent.amount,
    });
    const persisted: DepositIntent = { ...intent, providerReference: checkout.providerReference };
    await this.repository.save(persisted);
    return { intent: persisted, checkout };
  }

  async applyProviderStatus(input: {
    providerReference: string;
    status: 'PENDING' | 'SUCCEEDED' | 'FAILED';
    now?: Date;
  }): Promise<DepositIntent> {
    const intent = await this.repository.getByProviderReference(this.provider.name, input.providerReference);
    if (!intent) throw new Error('Deposit intent not found');
    if (input.status === 'PENDING') return intent;
    const next = transitionDeposit(intent, input.status, input.now);
    await this.repository.update(next);
    return next;
  }
}
