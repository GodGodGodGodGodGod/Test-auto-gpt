import type { DepositIntent } from '../domain/deposit.js';

export interface DepositRepository {
  getById(id: string): Promise<DepositIntent | undefined>;
  getByIdempotencyKey(customerId: string, idempotencyKey: string): Promise<DepositIntent | undefined>;
  getByProviderReference(provider: string, reference: string): Promise<DepositIntent | undefined>;
  save(intent: DepositIntent): Promise<void>;
  update(intent: DepositIntent): Promise<void>;
}
