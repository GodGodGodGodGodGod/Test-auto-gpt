import type { DepositIntent } from '../domain/deposit.js';

export interface DepositSettlementRepository {
  settleSucceeded(input: {
    depositId: string;
    providerReference: string;
    now: Date;
  }): Promise<DepositIntent>;
}
