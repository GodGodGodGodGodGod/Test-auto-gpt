import type { DepositIntent } from '../domain/deposit.js';
import type { DepositRepository } from './depositRepository.js';
import type { DepositSettlementRepository } from './depositSettlementRepository.js';
import type { PaymentProvider } from '../ports/payment-provider.js';

export class SettleDepositService {
  constructor(
    private readonly deposits: DepositRepository,
    private readonly settlement: DepositSettlementRepository,
    private readonly provider: PaymentProvider,
  ) {}

  async settleSucceeded(providerReference: string, now = new Date()): Promise<DepositIntent> {
    const intent = await this.deposits.getByProviderReference(this.provider.name, providerReference);
    if (!intent) throw new Error('Deposit intent not found');
    if (intent.status === 'SUCCEEDED') return intent;
    if (intent.status !== 'PENDING') throw new Error(`Cannot settle ${intent.status} deposit`);

    const verification = await this.provider.verify(providerReference);
    if (verification.status !== 'SUCCEEDED') throw new Error('Payment provider has not confirmed the deposit');
    if (!verification.amount) throw new Error('Payment provider did not return the settled amount');
    if (verification.amount.currency !== intent.amount.currency || verification.amount.amountMinor !== intent.amount.amountMinor) {
      throw new Error('Payment amount does not match the deposit intent');
    }

    return this.settlement.settleSucceeded({
      depositId: intent.id,
      providerReference,
      now,
    });
  }
}
