import type { Money } from '../../money/domain/money.js';

export type DepositStatus = 'PENDING' | 'SUCCEEDED' | 'FAILED' | 'CANCELLED';

export interface DepositIntent {
  readonly id: string;
  readonly customerId: string;
  readonly amount: Money;
  readonly provider: string;
  readonly providerReference?: string;
  readonly idempotencyKey: string;
  readonly status: DepositStatus;
  readonly createdAt: string;
  readonly updatedAt: string;
  readonly completedAt?: string;
}

const transitions: Record<DepositStatus, readonly DepositStatus[]> = {
  PENDING: ['SUCCEEDED', 'FAILED', 'CANCELLED'],
  SUCCEEDED: [],
  FAILED: [],
  CANCELLED: [],
};

export function createDepositIntent(input: {
  id: string;
  customerId: string;
  amount: Money;
  provider: string;
  idempotencyKey: string;
  now?: Date;
}): DepositIntent {
  if (!input.customerId) throw new Error('Customer ID is required');
  if (!input.provider) throw new Error('Payment provider is required');
  if (!input.idempotencyKey) throw new Error('Idempotency key is required');
  if (input.amount.amountMinor <= 0n) throw new Error('Deposit amount must be positive');
  const now = (input.now ?? new Date()).toISOString();
  return {
    id: input.id,
    customerId: input.customerId,
    amount: input.amount,
    provider: input.provider,
    idempotencyKey: input.idempotencyKey,
    status: 'PENDING',
    createdAt: now,
    updatedAt: now,
  };
}

export function transitionDeposit(intent: DepositIntent, status: DepositStatus, now = new Date()): DepositIntent {
  if (!transitions[intent.status].includes(status)) {
    throw new Error(`Invalid deposit transition: ${intent.status} -> ${status}`);
  }
  const timestamp = now.toISOString();
  return {
    ...intent,
    status,
    updatedAt: timestamp,
    ...(status === 'SUCCEEDED' ? { completedAt: timestamp } : {}),
  };
}
