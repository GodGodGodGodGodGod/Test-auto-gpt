import type { Money } from '../../money/domain/money.js';

export interface PaymentCheckout {
  readonly providerReference: string;
  readonly checkoutUrl?: string;
}

export interface PaymentProvider {
  readonly name: string;
  createCheckout(input: { depositId: string; customerId: string; amount: Money }): Promise<PaymentCheckout>;
  verify(reference: string): Promise<{ status: 'PENDING' | 'SUCCEEDED' | 'FAILED'; amount?: Money }>; 
}
