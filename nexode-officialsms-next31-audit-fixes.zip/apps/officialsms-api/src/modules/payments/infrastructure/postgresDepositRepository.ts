import type { Pool } from 'pg';
import { money } from '../../money/domain/money.js';
import type { DepositRepository } from '../application/depositRepository.js';
import type { DepositIntent } from '../domain/deposit.js';

function mapDeposit(row: Record<string, unknown>): DepositIntent {
  return {
    id: String(row.id),
    customerId: String(row.customer_id),
    amount: money(String(row.amount_minor), String(row.currency)),
    provider: String(row.provider),
    ...(row.provider_reference ? { providerReference: String(row.provider_reference) } : {}),
    idempotencyKey: String(row.idempotency_key),
    status: row.status as DepositIntent['status'],
    createdAt: new Date(String(row.created_at)).toISOString(),
    updatedAt: new Date(String(row.updated_at)).toISOString(),
    ...(row.completed_at ? { completedAt: new Date(String(row.completed_at)).toISOString() } : {}),
  };
}

export class PostgresDepositRepository implements DepositRepository {
  constructor(private readonly pool: Pool) {}

  async getById(id: string): Promise<DepositIntent | undefined> {
    const result = await this.pool.query('SELECT * FROM officialsms_deposit_intents WHERE id = $1', [id]);
    const row = result.rows[0] as Record<string, unknown> | undefined;
    return row ? mapDeposit(row) : undefined;
  }

  async getByIdempotencyKey(customerId: string, idempotencyKey: string): Promise<DepositIntent | undefined> {
    const result = await this.pool.query('SELECT * FROM officialsms_deposit_intents WHERE customer_id = $1 AND idempotency_key = $2', [customerId, idempotencyKey]);
    const row = result.rows[0] as Record<string, unknown> | undefined;
    return row ? mapDeposit(row) : undefined;
  }

  async getByProviderReference(provider: string, reference: string): Promise<DepositIntent | undefined> {
    const result = await this.pool.query('SELECT * FROM officialsms_deposit_intents WHERE provider = $1 AND provider_reference = $2', [provider, reference]);
    const row = result.rows[0] as Record<string, unknown> | undefined;
    return row ? mapDeposit(row) : undefined;
  }

  async save(intent: DepositIntent): Promise<void> {
    await this.pool.query(
      `INSERT INTO officialsms_deposit_intents
       (id, customer_id, amount_minor, currency, provider, provider_reference, idempotency_key, status, created_at, updated_at, completed_at)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$9,$10)`,
      [intent.id, intent.customerId, intent.amount.amountMinor.toString(), intent.amount.currency, intent.provider, intent.providerReference ?? null, intent.idempotencyKey, intent.status, intent.createdAt, intent.completedAt ?? null],
    );
  }

  async update(intent: DepositIntent): Promise<void> {
    await this.pool.query(
      `UPDATE officialsms_deposit_intents
       SET provider_reference = $1, status = $2, updated_at = $3, completed_at = $4
       WHERE id = $5`,
      [intent.providerReference ?? null, intent.status, intent.updatedAt, intent.completedAt ?? null, intent.id],
    );
  }
}
