import type { Pool } from 'pg';
import { money } from '../../money/domain/money.js';
import type { DepositSettlementRepository } from '../application/depositSettlementRepository.js';
import type { DepositIntent } from '../domain/deposit.js';

function mapDeposit(row: Record<string, unknown>): DepositIntent {
  return {
    id: String(row.id),
    customerId: String(row.customer_id),
    amount: money(String(row.amount_minor), String(row.currency)),
    provider: String(row.provider),
    ...(row.provider_reference ? { providerReference: String(row.provider_reference) } : {}),
    idempotencyKey: String(row.idempotency_key),
    status: row.status as DepositIntent['status'],
    createdAt: new Date(String(row.created_at)).toISOString(),
    updatedAt: new Date(String(row.updated_at)).toISOString(),
    ...(row.completed_at ? { completedAt: new Date(String(row.completed_at)).toISOString() } : {}),
  };
}

export class PostgresDepositSettlementRepository implements DepositSettlementRepository {
  constructor(private readonly pool: Pool) {}

  async settleSucceeded(input: { depositId: string; providerReference: string; now: Date }): Promise<DepositIntent> {
    const client = await this.pool.connect();
    try {
      await client.query('BEGIN');

      const depositResult = await client.query(
        'SELECT * FROM officialsms_deposit_intents WHERE id = $1 FOR UPDATE',
        [input.depositId],
      );
      const depositRow = depositResult.rows[0] as Record<string, unknown> | undefined;
      if (!depositRow) throw new Error('Deposit intent not found');
      const deposit = mapDeposit(depositRow);

      if (deposit.status === 'SUCCEEDED') {
        await client.query('COMMIT');
        return deposit;
      }
      if (deposit.status !== 'PENDING') throw new Error(`Cannot settle ${deposit.status} deposit`);
      if (deposit.providerReference !== input.providerReference) throw new Error('Provider reference mismatch');

      const walletResult = await client.query(
        `SELECT id, customer_id, currency
         FROM officialsms_wallets
         WHERE customer_id = $1 AND currency = $2
         FOR UPDATE`,
        [deposit.customerId, deposit.amount.currency],
      );
      const wallet = walletResult.rows[0] as Record<string, unknown> | undefined;
      if (!wallet) throw new Error('Customer wallet not found');

      const ledgerKey = `deposit:${deposit.id}`;
      const ledgerExisting = await client.query(
        'SELECT id FROM officialsms_ledger_transactions WHERE idempotency_key = $1 FOR UPDATE',
        [ledgerKey],
      );
      if (ledgerExisting.rows.length === 0) {
        const ledgerId = `ltx_${deposit.id}`;
        const timestamp = input.now.toISOString();
        await client.query(
          `INSERT INTO officialsms_ledger_transactions (id, idempotency_key, description, created_at)
           VALUES ($1,$2,$3,$4)`,
          [ledgerId, ledgerKey, `Deposit ${deposit.id} settled`, timestamp],
        );
        await client.query(
          `INSERT INTO officialsms_ledger_entries
           (id, transaction_id, account_id, side, amount_minor, currency)
           VALUES ($1,$2,$3,'DEBIT',$4,$5),($6,$2,$7,'CREDIT',$4,$5)`,
          [`le_${deposit.id}_cash`, ledgerId, `platform:cash:${deposit.amount.currency}`, deposit.amount.amountMinor.toString(), deposit.amount.currency, `le_${deposit.id}_wallet`, `wallet:${String(wallet.id)}`],
        );
      }

      await client.query(
        `UPDATE officialsms_wallets
         SET available_minor = available_minor + $1,
             updated_at = $2
         WHERE id = $3`,
        [deposit.amount.amountMinor.toString(), input.now.toISOString(), String(wallet.id)],
      );

      const updatedResult = await client.query(
        `UPDATE officialsms_deposit_intents
         SET status = 'SUCCEEDED', updated_at = $1, completed_at = $1
         WHERE id = $2
         RETURNING *`,
        [input.now.toISOString(), deposit.id],
      );
      const updatedRow = updatedResult.rows[0] as Record<string, unknown> | undefined;
      if (!updatedRow) throw new Error('Deposit settlement update failed');

      await client.query('COMMIT');
      return mapDeposit(updatedRow);
    } catch (error) {
      await client.query('ROLLBACK');
      throw error;
    } finally {
      client.release();
    }
  }
}
