import type { DepositRepository } from '../application/depositRepository.js';
import type { DepositIntent } from '../domain/deposit.js';

export class InMemoryDepositRepository implements DepositRepository {
  private readonly items = new Map<string, DepositIntent>();

  async getById(id: string): Promise<DepositIntent | undefined> { return this.items.get(id); }
  async getByIdempotencyKey(customerId: string, idempotencyKey: string): Promise<DepositIntent | undefined> {
    return [...this.items.values()].find((item) => item.customerId === customerId && item.idempotencyKey === idempotencyKey);
  }
  async getByProviderReference(provider: string, reference: string): Promise<DepositIntent | undefined> {
    return [...this.items.values()].find((item) => item.provider === provider && item.providerReference === reference);
  }
  async save(intent: DepositIntent): Promise<void> {
    if (this.items.has(intent.id)) throw new Error('Deposit intent already exists');
    if ([...this.items.values()].some((item) => item.customerId === intent.customerId && item.idempotencyKey === intent.idempotencyKey)) {
      throw new Error('Deposit idempotency key already exists');
    }
    this.items.set(intent.id, intent);
  }
  async update(intent: DepositIntent): Promise<void> {
    if (!this.items.has(intent.id)) throw new Error('Deposit intent not found');
    this.items.set(intent.id, intent);
  }
}
