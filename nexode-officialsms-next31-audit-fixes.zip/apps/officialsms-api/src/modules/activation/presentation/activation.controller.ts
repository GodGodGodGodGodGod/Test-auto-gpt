import type { GatewayRequest, GatewayResponse } from '@nexode/api-gateway';
import { ActivationService } from '../application/activationService.js';

export class ActivationController {
  constructor(private readonly service: ActivationService) {}

  async purchase(request: GatewayRequest, response: GatewayResponse): Promise<void> {
    const query = request.query as Record<string, string | undefined>;
    const country = query.country;
    const operator = query.operator ?? 'any';
    const service = query.service;

    if (!country || !service) {
      response.status(400).send({
        error: 'country and service are required',
      });
      return;
    }

    const maxPrice = query.maxPrice === undefined ? undefined : Number(query.maxPrice);
    if (maxPrice !== undefined && (!Number.isFinite(maxPrice) || maxPrice < 0)) {
      response.status(400).send({ error: 'maxPrice must be a non-negative number' });
      return;
    }

    response.send(await this.service.purchase({ country, operator, service, maxPrice }));
  }

  async check(request: GatewayRequest, response: GatewayResponse): Promise<void> {
    response.send(await this.service.check(this.orderId(request)));
  }

  async finish(request: GatewayRequest, response: GatewayResponse): Promise<void> {
    response.send(await this.service.finish(this.orderId(request)));
  }

  async cancel(request: GatewayRequest, response: GatewayResponse): Promise<void> {
    response.send(await this.service.cancel(this.orderId(request)));
  }

  async ban(request: GatewayRequest, response: GatewayResponse): Promise<void> {
    response.send(await this.service.ban(this.orderId(request)));
  }

  private orderId(request: Request): string {
    const params = request.params as Record<string, string | undefined>;
    const id = params.id;
    if (!id) throw new Error('order id is required');
    return id;
  }
}
