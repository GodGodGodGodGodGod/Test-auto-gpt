import type { GatewayRequest, GatewayResponse } from '@nexode/api-gateway';
import { z } from 'zod';
import { randomUUID } from 'node:crypto';
import type { PriceService } from '../../pricing/application/priceService.js';
import type { CatalogSnapshotService } from '../../catalog/application/catalogSnapshotService.js';
import type { MoneyRepository } from '../../money/application/moneyRepository.js';
import type { OrderService } from '../../orders/application/orderService.js';
import { PurchaseActivationService } from '../application/purchaseActivationService.js';

const purchaseSchema = z.object({
  country: z.string().trim().min(1).max(64),
  operator: z.string().trim().min(1).max(64).default('any'),
  service: z.string().trim().min(1).max(64),
  currency: z.string().regex(/^[A-Z]{3}$/),
});

export class CustomerPurchaseController {
  constructor(
    private readonly catalog: CatalogSnapshotService,
    private readonly pricing: PriceService,
    private readonly wallets: MoneyRepository,
    private readonly orders: OrderService,
    private readonly purchase: PurchaseActivationService,
  ) {}

  async create(request: GatewayRequest, response: GatewayResponse): Promise<void> {
    const parsed = purchaseSchema.safeParse(request.body);
    if (!parsed.success) {
      response.status(400).send({ error: 'Invalid purchase request', details: parsed.error.flatten() });
      return;
    }

    if (!request.user?.id) {
      response.status(401).send({ error: 'Authentication required' });
      return;
    }

    const idempotencyKey = request.headers['idempotency-key'] ?? request.headers['Idempotency-Key'];
    if (!idempotencyKey || idempotencyKey.length < 16 || idempotencyKey.length > 200) {
      response.status(400).send({ error: 'A valid Idempotency-Key header is required' });
      return;
    }

    const existing = await this.orders.findByPurchaseIdempotencyKey(request.user.id, idempotencyKey);
    if (existing) {
      response.status(200).send(existing);
      return;
    }

    const input = parsed.data;
    const catalog = await this.catalog.get({ country: input.country, service: input.service });
    if (catalog.stale) {
      response.status(503).send({ error: 'Catalog data is temporarily stale; please retry shortly' });
      return;
    }

    const product = catalog.products.find((item) => item.country === input.country && item.operator === input.operator && item.service === input.service && item.available > 0);
    if (!product) {
      response.status(409).send({ error: 'Requested number is currently unavailable' });
      return;
    }

    const quote = await this.pricing.quote({
      providerAmount: String(product.providerPrice),
      providerCurrency: product.providerCurrency,
      customerCurrency: input.currency,
    });

    const wallet = await this.wallets.getWalletByCustomerAndCurrency(request.user.id, quote.customerCurrency);
    if (!wallet) {
      response.status(409).send({ error: `No ${quote.customerCurrency} wallet is available for this account` });
      return;
    }

    const orderId = `ord_${randomUUID()}`;
    const reservationId = `res_${randomUUID()}`;
    const result = await this.purchase.purchase({
      orderId,
      purchaseIdempotencyKey: idempotencyKey,
      customerId: request.user.id,
      walletId: wallet.id,
      country: product.country,
      operator: product.operator,
      service: product.service,
      reservationId,
      price: quote,
      now: new Date(),
    });

    response.status(201).send(result);
  }
}

export { purchaseSchema };
