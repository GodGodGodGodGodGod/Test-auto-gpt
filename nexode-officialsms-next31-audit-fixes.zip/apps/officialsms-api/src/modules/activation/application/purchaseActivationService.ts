import { SmsProviderAmbiguousError, type SmsProvider, type SmsActivation } from '../../../providers/ports/sms-provider.js';
import { compare } from '../../pricing/domain/decimal.js';
import type { OrderService } from '../../orders/application/orderService.js';
import type { PurchaseAttempt, PurchaseAttemptRepository } from '../../orders/application/purchaseAttemptRepository.js';
import { WalletService } from '../../money/application/walletService.js';
import type { ProviderAvailabilityService } from '../../provider-health/application/providerAvailabilityService.js';

export class PurchaseActivationService {
  constructor(
    private readonly provider: SmsProvider,
    private readonly orders: OrderService,
    private readonly wallet: WalletService,
    private readonly attempts?: PurchaseAttemptRepository,
    private readonly providerAvailability?: ProviderAvailabilityService,
  ) {}

  async purchase(input: {
    readonly orderId: string;
    readonly purchaseIdempotencyKey?: string;
    readonly customerId: string;
    readonly walletId: string;
    readonly country: string;
    readonly operator: string;
    readonly service: string;
    readonly price: {
      readonly providerAmount: string;
      readonly providerCurrency: string;
      readonly customerAmount: string;
      readonly customerCurrency: string;
      readonly exchangeRate: string;
      readonly markupAmount: string;
      readonly pricingRuleVersion: string;
      readonly rateSource: string;
      readonly rateCapturedAt: string;
    };
    readonly reservationId: string;
    readonly now?: Date;
  }) {
    const purchaseIdempotencyKey = input.purchaseIdempotencyKey ?? input.orderId;
    const existing = await this.orders.findByPurchaseIdempotencyKey(input.customerId, purchaseIdempotencyKey);
    if (existing) return existing;

    // Require a recent provider health signal before reserving customer funds.
    // DEGRADED remains allowed; UNAVAILABLE or stale/no health fails closed.
    await this.providerAvailability?.assertPurchaseAllowed();

    const created = await this.orders.create({
      id: input.orderId,
      customerId: input.customerId,
      provider: this.provider.name,
      country: input.country,
      operator: input.operator,
      service: input.service,
      price: input.price,
      purchaseIdempotencyKey,
      now: input.now,
    });

    let attempt: PurchaseAttempt | undefined;
    if (this.attempts) {
      const timestamp = (input.now ?? new Date()).toISOString();
      attempt = await this.attempts.create({
        id: `pa_${input.orderId}`,
        orderId: input.orderId,
        provider: this.provider.name,
        status: 'CREATED',
        country: input.country,
        operator: input.operator,
        service: input.service,
        walletId: input.walletId,
        reservationId: input.reservationId,
        maxProviderPrice: Number(input.price.providerAmount),
        createdAt: timestamp,
        updatedAt: timestamp,
      });
    }

    let reservation;
    try {
      reservation = await this.wallet.reserve({
        walletId: input.walletId,
        amountMinor: this.toCustomerMinorUnits(input.price.customerAmount, input.price.customerCurrency),
        currency: input.price.customerCurrency,
        idempotencyKey: `sms-order:${input.orderId}`,
        reservationId: input.reservationId,
      });
    } catch (error) {
      await this.failAttempt(attempt, 'RESERVATION_FAILED', error, input.now);
      await this.orders.transition(created.id, 'FAILED', input.now);
      throw error;
    }

    await this.orders.transition(created.id, 'PAYMENT_RESERVED', input.now);
    await this.orders.transition(created.id, 'PURCHASING', input.now);
    attempt = await this.updateAttempt(attempt, { status: 'SUBMITTED', submittedAt: (input.now ?? new Date()).toISOString() });

    let activation: SmsActivation;
    try {
      activation = await this.provider.purchase({
        country: input.country,
        operator: input.operator,
        service: input.service,
        maxPrice: Number(input.price.providerAmount),
      });
    } catch (error) {
      if (error instanceof SmsProviderAmbiguousError) {
        await this.updateAttempt(attempt, { status: 'UNKNOWN' });
        // The provider may have created an activation. Keep the reservation and
        // order in PURCHASING until reconciliation resolves the outcome.
        throw error;
      }

      await this.updateAttempt(attempt, { status: 'FAILED', errorCode: 'PROVIDER_REQUEST_FAILED', errorMessage: error instanceof Error ? error.message : String(error), resolvedAt: (input.now ?? new Date()).toISOString() });
      await this.wallet.release(input.walletId, reservation.id);
      await this.orders.transition(created.id, 'FAILED', input.now);
      throw error;
    }

    if (activation.currency !== input.price.providerCurrency) {
      await this.updateAttempt(attempt, { status: 'FAILED', providerOrderId: activation.id, errorCode: 'PROVIDER_CURRENCY_MISMATCH', resolvedAt: (input.now ?? new Date()).toISOString() });
      await this.provider.cancel(activation.id);
      await this.wallet.release(input.walletId, reservation.id);
      await this.orders.transition(created.id, 'FAILED', input.now);
      throw new Error(`Provider currency mismatch: expected ${input.price.providerCurrency}, received ${activation.currency}`);
    }

    if (compare(String(activation.price), input.price.providerAmount) > 0) {
      await this.updateAttempt(attempt, { status: 'FAILED', providerOrderId: activation.id, errorCode: 'PROVIDER_PRICE_EXCEEDED', resolvedAt: (input.now ?? new Date()).toISOString() });
      await this.provider.cancel(activation.id);
      await this.wallet.release(input.walletId, reservation.id);
      await this.orders.transition(created.id, 'FAILED', input.now);
      throw new Error('Provider price exceeded the quoted provider amount');
    }

    await this.updateAttempt(attempt, { status: 'SUCCEEDED', providerOrderId: activation.id, resolvedAt: (input.now ?? new Date()).toISOString() });
    await this.orders.attachProviderActivation(created.id, {
      providerOrderId: activation.id,
      phone: activation.phone,
      expiresAt: activation.expiresAt,
    }, input.now);

    try {
      await this.wallet.capture(input.walletId, reservation.id);
    } catch (error) {
      try { await this.provider.cancel(activation.id); } catch { /* preserve financial failure */ }
      try { await this.wallet.release(input.walletId, reservation.id); } catch { /* preserve financial failure */ }
      await this.updateAttempt(attempt, { status: 'UNKNOWN', errorCode: 'CAPTURE_FAILED', errorMessage: error instanceof Error ? error.message : String(error) });
      await this.orders.transition(created.id, 'FAILED', input.now);
      throw error;
    }

    await this.orders.transition(created.id, 'ACTIVE', input.now);
    const completed = await this.orders.findById(created.id);
    if (!completed) throw new Error(`Order disappeared after purchase: ${created.id}`);
    return completed;
  }

  private toCustomerMinorUnits(amount: string, currency: string): bigint {
    return WalletService.toMinorUnits(amount, currency);
  }

  private async updateAttempt(attempt: PurchaseAttempt | undefined, patch: Partial<PurchaseAttempt>): Promise<PurchaseAttempt | undefined> {
    if (!attempt || !this.attempts) return attempt;
    return this.attempts.update({ ...attempt, ...patch, updatedAt: new Date().toISOString() });
  }

  private async failAttempt(attempt: PurchaseAttempt | undefined, code: string, error: unknown, now?: Date): Promise<void> {
    await this.updateAttempt(attempt, {
      status: 'FAILED',
      errorCode: code,
      errorMessage: error instanceof Error ? error.message : String(error),
      resolvedAt: (now ?? new Date()).toISOString(),
    });
  }
}
