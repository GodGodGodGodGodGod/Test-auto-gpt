import type { SmsProvider } from '../../../providers/ports/sms-provider.js';
import type { OrderService } from '../../orders/application/orderService.js';
import type { PurchaseAttempt, PurchaseAttemptRepository } from '../../orders/application/purchaseAttemptRepository.js';
import type { WalletService } from '../../money/application/walletService.js';

export interface PurchaseReconciliationResult {
  readonly outcome: 'RESOLVED_ACTIVE' | 'RESOLVED_FAILED' | 'UNRESOLVED';
  readonly orderId: string;
  readonly providerOrderId?: string;
}

/**
 * Resolves an ambiguous purchase only when the provider order reference is
 * known. We intentionally do not guess from a recent-orders list because a
 * false match could charge one customer for another activation.
 */
export class ReconcilePurchaseService {
  constructor(
    private readonly provider: SmsProvider,
    private readonly orders: OrderService,
    private readonly attempts: PurchaseAttemptRepository,
    private readonly wallet: WalletService,
  ) {}

  async reconcile(orderId: string): Promise<PurchaseReconciliationResult> {
    const order = await this.orders.findById(orderId);
    if (!order) throw new Error(`Order not found: ${orderId}`);

    const attempt = await this.attempts.findByOrderId(orderId);
    if (!attempt) throw new Error(`Purchase attempt not found: ${orderId}`);

    if (!attempt.providerOrderId) {
      await this.markReconciling(attempt);
      return { outcome: 'UNRESOLVED', orderId };
    }

    const activation = await this.provider.check(attempt.providerOrderId);
    await this.orders.attachProviderActivation(orderId, {
      providerOrderId: activation.id,
      phone: activation.phone,
      expiresAt: activation.expiresAt,
    });

    const terminalFailure = ['CANCELED', 'TIMEOUT', 'BANNED'].includes(activation.status);
    if (terminalFailure) {
      await this.wallet.release(attempt.walletId, attempt.reservationId);
      await this.orders.transition(orderId, 'FAILED');
      await this.attempts.update({
        ...attempt,
        status: 'FAILED',
        providerOrderId: activation.id,
        errorCode: `PROVIDER_${activation.status}`,
        updatedAt: new Date().toISOString(),
        resolvedAt: new Date().toISOString(),
      });
      return { outcome: 'RESOLVED_FAILED', orderId, providerOrderId: activation.id };
    }

    await this.wallet.capture(attempt.walletId, attempt.reservationId);
    if (order.status === 'PURCHASING') await this.orders.transition(orderId, 'ACTIVE');
    await this.attempts.update({
      ...attempt,
      status: 'SUCCEEDED',
      providerOrderId: activation.id,
      updatedAt: new Date().toISOString(),
      resolvedAt: new Date().toISOString(),
    });
    return { outcome: 'RESOLVED_ACTIVE', orderId, providerOrderId: activation.id };
  }

  private async markReconciling(attempt: PurchaseAttempt): Promise<void> {
    await this.attempts.update({
      ...attempt,
      status: 'RECONCILING',
      updatedAt: new Date().toISOString(),
    });
  }
}
