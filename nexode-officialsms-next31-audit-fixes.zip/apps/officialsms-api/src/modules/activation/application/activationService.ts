import type { SmsProvider } from '../../../providers/ports/sms-provider.js';
import { toActivation, type Activation } from '../domain/activation.js';

export class ActivationService {
  constructor(private readonly provider: SmsProvider) {}

  async purchase(input: {
    readonly country: string;
    readonly operator: string;
    readonly service: string;
    readonly maxPrice?: number;
  }): Promise<Activation> {
    return toActivation(this.provider.name, await this.provider.purchase(input));
  }

  async check(orderId: string): Promise<Activation> {
    return toActivation(this.provider.name, await this.provider.check(orderId));
  }

  async finish(orderId: string): Promise<Activation> {
    return toActivation(this.provider.name, await this.provider.finish(orderId));
  }

  async cancel(orderId: string): Promise<Activation> {
    return toActivation(this.provider.name, await this.provider.cancel(orderId));
  }

  async ban(orderId: string): Promise<Activation> {
    return toActivation(this.provider.name, await this.provider.ban(orderId));
  }
}
