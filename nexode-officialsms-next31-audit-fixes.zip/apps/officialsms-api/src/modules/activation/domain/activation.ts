import type { SmsActivation, SmsMessage, SmsProviderStatus } from '../../../providers/ports/sms-provider.js';

export interface Activation {
  readonly provider: string;
  readonly providerOrderId: string;
  readonly phone: string;
  readonly country?: string;
  readonly operator?: string;
  readonly service: string;
  readonly providerPrice: number;
  readonly providerCurrency: string;
  readonly providerStatus: SmsProviderStatus;
  readonly createdAt?: string;
  readonly expiresAt?: string;
  readonly messages: readonly SmsMessage[];
}

export function toActivation(provider: string, value: SmsActivation): Activation {
  return {
    provider,
    providerOrderId: value.id,
    phone: value.phone,
    country: value.country,
    operator: value.operator,
    service: value.product,
    providerPrice: value.price,
    providerCurrency: value.currency,
    providerStatus: value.status,
    createdAt: value.createdAt,
    expiresAt: value.expiresAt,
    messages: value.sms,
  };
}
