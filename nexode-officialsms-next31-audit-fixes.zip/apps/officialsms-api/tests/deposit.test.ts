import { describe, expect, it } from 'vitest';
import { DepositService } from '../src/modules/payments/application/depositService.js';
import { InMemoryDepositRepository } from '../src/modules/payments/infrastructure/inMemoryDepositRepository.js';
import type { PaymentProvider } from '../src/modules/payments/ports/payment-provider.js';
import { money } from '../src/modules/money/domain/money.js';

function provider(): PaymentProvider {
  return {
    name: 'test-provider',
    async createCheckout(input) { return { providerReference: `ref-${input.depositId}`, checkoutUrl: 'https://checkout.invalid' }; },
    async verify() { return { status: 'PENDING' }; },
  };
}

describe('DepositService', () => {
  it('creates an idempotent deposit intent', async () => {
    const service = new DepositService(new InMemoryDepositRepository(), provider());
    const input = { id: 'dep-1', customerId: 'cus-1', amount: money(10000n, 'NGN'), idempotencyKey: 'key-1' };
    const first = await service.create(input);
    const second = await service.create({ ...input, id: 'dep-2' });
    expect(second.intent.id).toBe(first.intent.id);
    expect(second.checkout.providerReference).toBe(first.checkout.providerReference);
  });

  it('transitions successful payments exactly once', async () => {
    const service = new DepositService(new InMemoryDepositRepository(), provider());
    const { intent } = await service.create({ id: 'dep-2', customerId: 'cus-2', amount: money(5000n, 'USD'), idempotencyKey: 'key-2' });
    const succeeded = await service.applyProviderStatus({ providerReference: intent.providerReference!, status: 'SUCCEEDED' });
    expect(succeeded.status).toBe('SUCCEEDED');
    await expect(service.applyProviderStatus({ providerReference: intent.providerReference!, status: 'SUCCEEDED' })).rejects.toThrow('Invalid deposit transition');
  });
});
