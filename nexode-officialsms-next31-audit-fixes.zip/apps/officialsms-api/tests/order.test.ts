import { describe, expect, it } from 'vitest';
import { InMemoryOrderRepository } from '../src/modules/orders/infrastructure/inMemoryOrderRepository.js';
import { OrderService } from '../src/modules/orders/application/orderService.js';
import { canTransition, transitionOrder, type SmsOrder } from '../src/modules/orders/domain/order.js';

const price = {
  providerAmount: 4, providerCurrency: 'USD', customerAmount: 5.2,
  customerCurrency: 'USD', exchangeRate: 1, markupAmount: 1.2,
  pricingRuleVersion: 'launch-v1', rateSource: 'test',
  rateCapturedAt: '2026-09-16T00:00:00.000Z',
};

function order(): SmsOrder {
  return {
    id: 'ord_1', customerId: 'user_1', purchaseIdempotencyKey: 'ord_1', provider: '5sim',
    country: 'england', operator: 'any', service: 'telegram',
    status: 'CREATED', price,
    createdAt: '2026-09-16T00:00:00.000Z',
    updatedAt: '2026-09-16T00:00:00.000Z',
  };
}

describe('OfficialSMS order state machine', () => {
  it('allows the purchase lifecycle in order', () => {
    expect(canTransition('CREATED', 'PAYMENT_RESERVED')).toBe(true);
    expect(canTransition('PAYMENT_RESERVED', 'PURCHASING')).toBe(true);
    expect(canTransition('PURCHASING', 'ACTIVE')).toBe(true);
    expect(canTransition('ACTIVE', 'SMS_RECEIVED')).toBe(true);
    expect(canTransition('SMS_RECEIVED', 'COMPLETED')).toBe(true);
  });

  it('rejects illegal transitions', () => {
    expect(() => transitionOrder(order(), 'COMPLETED')).toThrow(
      'Invalid order transition: CREATED -> COMPLETED',
    );
  });

  it('records lifecycle timestamps', () => {
    const at = new Date('2026-09-16T10:00:00.000Z');
    const received = transitionOrder({ ...order(), status: 'ACTIVE' }, 'SMS_RECEIVED', at);
    expect(received.smsReceivedAt).toBe(at.toISOString());
    expect(received.updatedAt).toBe(at.toISOString());
  });
});

describe('OrderService', () => {
  it('creates and transitions through the repository port', async () => {
    const service = new OrderService(new InMemoryOrderRepository());
    await service.create({
      id: 'ord_2', customerId: 'user_2', provider: '5sim',
      country: 'england', operator: 'any', service: 'telegram',
      price, now: new Date('2026-09-16T10:00:00.000Z'),
    });
    const updated = await service.transition(
      'ord_2', 'PAYMENT_RESERVED', new Date('2026-09-16T10:01:00.000Z'),
    );
    expect(updated.status).toBe('PAYMENT_RESERVED');
  });
});
