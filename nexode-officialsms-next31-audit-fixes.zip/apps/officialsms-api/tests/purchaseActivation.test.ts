import { describe, expect, it, vi } from 'vitest';
import { PurchaseActivationService } from '../src/modules/activation/application/purchaseActivationService.js';
import { InMemoryOrderRepository } from '../src/modules/orders/infrastructure/inMemoryOrderRepository.js';
import { OrderService } from '../src/modules/orders/application/orderService.js';
import { InMemoryMoneyRepository } from '../src/modules/money/infrastructure/inMemoryMoneyRepository.js';
import { WalletService } from '../src/modules/money/application/walletService.js';
import { createWallet } from '../src/modules/money/domain/wallet.js';
import { SmsProviderAmbiguousError, type SmsProvider } from '../src/providers/ports/sms-provider.js';

const price = { providerAmount: 2, providerCurrency: 'USD', customerAmount: 5, customerCurrency: 'USD', exchangeRate: 1, markupAmount: 3, pricingRuleVersion: 'v1', rateSource: 'test', rateCapturedAt: '2026-09-16T00:00:00.000Z' };

function provider(): SmsProvider {
  return {
    name: '5sim',
    purchase: vi.fn(async () => ({ id: 'p-1', phone: '+123', product: 'telegram', price: 2, currency: 'USD', status: 'PENDING', sms: [] })),
    check: vi.fn(), finish: vi.fn(), cancel: vi.fn(async () => ({ id: 'p-1', phone: '+123', product: 'telegram', price: 2, currency: 'USD', status: 'CANCELED', sms: [] })), ban: vi.fn(),
  };
}

function setup() {
  const money = new InMemoryMoneyRepository();
  const wallet = createWallet({ id: 'w1', customerId: 'c1', currency: 'USD' });
  return { money, walletService: new WalletService(money), orderService: new OrderService(new InMemoryOrderRepository()), wallet };
}

describe('PurchaseActivationService', () => {
  it('reserves, purchases, captures, and activates an order', async () => {
    const { money, walletService, orderService, wallet } = setup();
    await money.saveWallet(wallet);
    const service = new PurchaseActivationService(provider(), orderService, walletService);
    const result = await service.purchase({ orderId: 'o1', customerId: 'c1', walletId: 'w1', country: 'nigeria', operator: 'any', service: 'telegram', price, reservationId: 'r1' });
    expect(result.status).toBe('ACTIVE');
    expect(result.providerOrderId).toBe('p-1');
    expect(result.phone).toBe('+123');
    expect(await money.getReservationById('w1', 'r1')).toMatchObject({ status: 'CAPTURED' });
  });

  it('releases funds and fails the order when provider purchase fails', async () => {
    const { money, walletService, orderService, wallet } = setup();
    await money.saveWallet(wallet);
    const p = provider();
    p.purchase = vi.fn(async () => { throw new Error('provider down'); });
    const service = new PurchaseActivationService(p, orderService, walletService);
    await expect(service.purchase({ orderId: 'o2', customerId: 'c1', walletId: 'w1', country: 'nigeria', operator: 'any', service: 'telegram', price, reservationId: 'r2' })).rejects.toThrow('provider down');
    expect(await money.getReservationById('w1', 'r2')).toMatchObject({ status: 'RELEASED' });
    expect((await orderService.findByPurchaseIdempotencyKey('c1', 'o2'))?.status).toBe('FAILED');
  });

  it('cancels the provider and releases funds on provider currency mismatch', async () => {
    const { money, walletService, orderService, wallet } = setup();
    await money.saveWallet(wallet);
    const p = provider();
    p.purchase = vi.fn(async () => ({ id: 'p-2', phone: '+124', product: 'telegram', price: 2, currency: 'EUR', status: 'PENDING', sms: [] }));
    const service = new PurchaseActivationService(p, orderService, walletService);
    await expect(service.purchase({ orderId: 'o3', customerId: 'c1', walletId: 'w1', country: 'nigeria', operator: 'any', service: 'telegram', price, reservationId: 'r3' })).rejects.toThrow('currency mismatch');
    expect(p.cancel).toHaveBeenCalledWith('p-2');
    expect(await money.getReservationById('w1', 'r3')).toMatchObject({ status: 'RELEASED' });
  });
  it('keeps funds reserved when the provider outcome is ambiguous', async () => {
    const { money, walletService, orderService, wallet } = setup();
    await money.saveWallet(wallet);
    const p = provider();
    p.purchase = vi.fn(async () => { throw new SmsProviderAmbiguousError('unknown'); });
    const service = new PurchaseActivationService(p, orderService, walletService);
    await expect(service.purchase({ orderId: 'o4', customerId: 'c1', walletId: 'w1', country: 'nigeria', operator: 'any', service: 'telegram', price, reservationId: 'r4' })).rejects.toThrow('unknown');
    expect(await money.getReservationById('w1', 'r4')).toMatchObject({ status: 'ACTIVE' });
    expect((await orderService.findByPurchaseIdempotencyKey('c1', 'o4'))?.status).toBe('PURCHASING');
  });

});
