import { describe, expect, it } from 'vitest';
import { assertBalanced, createLedgerTransaction } from '../src/modules/money/domain/ledger.js';
import { money } from '../src/modules/money/domain/money.js';
import { createWallet, createReservation, captureReservation, releaseReservation } from '../src/modules/money/domain/wallet.js';

const wallet = createWallet({ id: 'w1', customerId: 'c1', currency: 'USD' });

describe('money domain', () => {
  it('uses integer minor units', () => expect(money('1250', 'USD').amountMinor).toBe(1250n));
  it('rejects unbalanced ledger transactions', () => {
    expect(() => assertBalanced([{ id: 'e1', accountId: 'a1', side: 'DEBIT', money: money(1000, 'USD') }])).toThrow();
  });
  it('accepts a balanced double-entry transaction', () => {
    expect(() => createLedgerTransaction({ id: 't1', idempotencyKey: 'k1', description: 'deposit', entries: [
      { id: 'e1', accountId: 'cash', side: 'DEBIT', money: money(1000, 'USD') },
      { id: 'e2', accountId: 'wallet', side: 'CREDIT', money: money(1000, 'USD') },
    ] })).not.toThrow();
  });
  it('enforces wallet reservation rules', () => {
    const reservation = createReservation({ id: 'r1', wallet, amount: money(500, 'USD'), idempotencyKey: 'order-1' });
    expect(reservation.status).toBe('ACTIVE');
    expect(captureReservation(reservation).status).toBe('CAPTURED');
    expect(releaseReservation(reservation).status).toBe('RELEASED');
    expect(() => createReservation({ id: 'r2', wallet, amount: money(1500, 'USD'), idempotencyKey: 'order-2' })).not.toThrow();
  });
});

describe('currency-aware minor units', () => {
  it('converts two-decimal currencies without floating-point arithmetic', async () => {
    const { decimalToMinorUnits } = await import('../src/modules/money/domain/currency.js');
    expect(decimalToMinorUnits('10.25', 'USD')).toBe(1025n);
    expect(decimalToMinorUnits('10.25', 'NGN')).toBe(1025n);
  });

  it('supports zero and three-decimal currencies', async () => {
    const { decimalToMinorUnits } = await import('../src/modules/money/domain/currency.js');
    expect(decimalToMinorUnits('1500', 'JPY')).toBe(1500n);
    expect(decimalToMinorUnits('1.250', 'KWD')).toBe(1250n);
  });

  it('rejects silent rounding', async () => {
    const { decimalToMinorUnits } = await import('../src/modules/money/domain/currency.js');
    expect(() => decimalToMinorUnits('10.999', 'USD')).toThrow(/decimal places/);
  });
});
