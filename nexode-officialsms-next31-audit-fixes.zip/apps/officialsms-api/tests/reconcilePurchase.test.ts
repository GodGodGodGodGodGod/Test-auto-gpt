import { describe, expect, it, vi } from 'vitest';
import { ReconcilePurchaseService } from '../src/modules/activation/application/reconcilePurchaseService.js';
import { InMemoryOrderRepository } from '../src/modules/orders/infrastructure/inMemoryOrderRepository.js';
import { InMemoryPurchaseAttemptRepository } from '../src/modules/orders/infrastructure/inMemoryPurchaseAttemptRepository.js';
import { OrderService } from '../src/modules/orders/application/orderService.js';
import { InMemoryMoneyRepository } from '../src/modules/money/infrastructure/inMemoryMoneyRepository.js';
import { WalletService } from '../src/modules/money/application/walletService.js';
import { createWallet } from '../src/modules/money/domain/wallet.js';
import type { PurchaseAttempt } from '../src/modules/orders/application/purchaseAttemptRepository.js';
import type { SmsProvider } from '../src/providers/ports/sms-provider.js';

const price = { providerAmount: 2, providerCurrency: 'USD', customerAmount: 5, customerCurrency: 'USD', exchangeRate: 1, markupAmount: 3, pricingRuleVersion: 'v1', rateSource: 'test', rateCapturedAt: '2026-09-16T00:00:00.000Z' };

function baseAttempt(): PurchaseAttempt {
  return { id: 'pa_o1', orderId: 'o1', provider: '5sim', status: 'UNKNOWN', country: 'nigeria', operator: 'any', service: 'telegram', walletId: 'w1', reservationId: 'r1', maxProviderPrice: 2, createdAt: '2026-09-16T00:00:00.000Z', updatedAt: '2026-09-16T00:00:00.000Z', providerOrderId: 'p1' };
}

describe('ReconcilePurchaseService', () => {
  it('resolves a known provider activation and captures the reservation', async () => {
    const orders = new OrderService(new InMemoryOrderRepository());
    await orders.create({ id: 'o1', customerId: 'c1', provider: '5sim', country: 'nigeria', operator: 'any', service: 'telegram', price, purchaseIdempotencyKey: 'o1' });
    await orders.transition('o1', 'PAYMENT_RESERVED');
    await orders.transition('o1', 'PURCHASING');

    const money = new InMemoryMoneyRepository();
    await money.saveWallet(createWallet({ id: 'w1', customerId: 'c1', currency: 'USD' }));
    const wallet = new WalletService(money);
    await wallet.reserve({ walletId: 'w1', amountMinor: 500n, currency: 'USD', idempotencyKey: 'sms-order:o1', reservationId: 'r1' });

    const attempts = new InMemoryPurchaseAttemptRepository();
    await attempts.create(baseAttempt());
    const provider: SmsProvider = { name: '5sim', purchase: vi.fn(), check: vi.fn(async () => ({ id: 'p1', phone: '+123', product: 'telegram', price: 2, currency: 'USD', status: 'PENDING', sms: [] })), finish: vi.fn(), cancel: vi.fn(), ban: vi.fn() };

    const service = new ReconcilePurchaseService(provider, orders, attempts, wallet);
    const result = await service.reconcile('o1');
    expect(result.outcome).toBe('RESOLVED_ACTIVE');
    expect((await orders.findById('o1'))?.status).toBe('ACTIVE');
    expect(await money.getReservationById('w1', 'r1')).toMatchObject({ status: 'CAPTURED' });
  });

  it('does not guess when the provider order id is unknown', async () => {
    const orders = new OrderService(new InMemoryOrderRepository());
    await orders.create({ id: 'o2', customerId: 'c1', provider: '5sim', country: 'nigeria', operator: 'any', service: 'telegram', price, purchaseIdempotencyKey: 'o2' });
    await orders.transition('o2', 'PAYMENT_RESERVED');
    await orders.transition('o2', 'PURCHASING');
    const attempts = new InMemoryPurchaseAttemptRepository();
    await attempts.create({ ...baseAttempt(), id: 'pa_o2', orderId: 'o2', providerOrderId: undefined });
    const wallet = new WalletService(new InMemoryMoneyRepository());
    const provider: SmsProvider = { name: '5sim', purchase: vi.fn(), check: vi.fn(), finish: vi.fn(), cancel: vi.fn(), ban: vi.fn() };

    const result = await new ReconcilePurchaseService(provider, orders, attempts, wallet).reconcile('o2');
    expect(result.outcome).toBe('UNRESOLVED');
    expect((await attempts.findByOrderId('o2'))?.status).toBe('RECONCILING');
    expect(provider.check).not.toHaveBeenCalled();
  });
});
