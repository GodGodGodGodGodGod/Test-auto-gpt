import { describe, expect, it } from 'vitest';
import { SettleDepositService } from '../src/modules/payments/application/settleDepositService.js';
import type { DepositRepository } from '../src/modules/payments/application/depositRepository.js';
import type { DepositSettlementRepository } from '../src/modules/payments/application/depositSettlementRepository.js';
import type { PaymentProvider } from '../src/modules/payments/ports/payment-provider.js';
import { money } from '../src/modules/money/domain/money.js';
import type { DepositIntent } from '../src/modules/payments/domain/deposit.js';

const deposit: DepositIntent = {
  id: 'dep_1', customerId: 'cust_1', amount: money(1500n, 'USD'), provider: 'test',
  providerReference: 'pay_1', idempotencyKey: 'idem_1', status: 'PENDING',
  createdAt: '2026-09-16T00:00:00.000Z', updatedAt: '2026-09-16T00:00:00.000Z',
};

class Repo implements DepositRepository, DepositSettlementRepository {
  current = deposit;
  async getById() { return this.current; }
  async getByIdempotencyKey() { return this.current; }
  async getByProviderReference() { return this.current; }
  async save(intent: DepositIntent) { this.current = intent; }
  async update(intent: DepositIntent) { this.current = intent; }
  async settleSucceeded(input: { depositId: string; providerReference: string; now: Date }) {
    if (this.current.status === 'SUCCEEDED') return this.current;
    this.current = { ...this.current, status: 'SUCCEEDED', updatedAt: input.now.toISOString(), completedAt: input.now.toISOString() };
    return this.current;
  }
}

function provider(verifyResult: Awaited<ReturnType<PaymentProvider['verify']>>): PaymentProvider {
  return {
    name: 'test',
    async createCheckout() { return { providerReference: 'pay_1' }; },
    async verify() { return verifyResult; },
  };
}

describe('SettleDepositService', () => {
  it('requires provider confirmation and exact amount', async () => {
    const repo = new Repo();
    const service = new SettleDepositService(repo, repo, provider({ status: 'SUCCEEDED', amount: money(1500n, 'USD') }));
    const result = await service.settleSucceeded('pay_1', new Date('2026-09-16T01:00:00.000Z'));
    expect(result.status).toBe('SUCCEEDED');
  });

  it('rejects an amount mismatch', async () => {
    const repo = new Repo();
    const service = new SettleDepositService(repo, repo, provider({ status: 'SUCCEEDED', amount: money(1499n, 'USD') }));
    await expect(service.settleSucceeded('pay_1')).rejects.toThrow('Payment amount does not match the deposit intent');
  });
});
