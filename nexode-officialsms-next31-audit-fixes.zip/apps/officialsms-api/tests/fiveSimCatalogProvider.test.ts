import { describe, expect, it, vi } from 'vitest';
import { FiveSimCatalogProvider } from '../src/modules/catalog/infrastructure/fiveSimCatalogProvider.js';

describe('FiveSimCatalogProvider', () => {
  it('normalizes the documented 5SIM guest price response', async () => {
    const fetchMock = vi.fn<typeof fetch>().mockResolvedValue(
      new Response(
        JSON.stringify({
          england: {
            facebook: {
              vodafone: {
                cost: 4,
                count: 1260,
                rate: 99.99,
              },
            },
          },
        }),
        { status: 200 },
      ),
    );

    const provider = new FiveSimCatalogProvider(
      'https://5sim.net/v1',
      1000,
      'USD',
      fetchMock,
    );

    const catalog = await provider.getCatalog({ country: 'england', service: 'facebook' });

    expect(fetchMock).toHaveBeenCalledOnce();
    expect(catalog.provider).toBe('5sim');
    expect(catalog.products).toEqual([
      {
        country: 'england',
        operator: 'vodafone',
        service: 'facebook',
        price: 4,
        available: 1260,
        currency: 'USD',
      },
    ]);
  });

  it('rejects non-success provider responses', async () => {
    const fetchMock = vi.fn<typeof fetch>().mockResolvedValue(
      new Response('bad gateway', { status: 502 }),
    );

    const provider = new FiveSimCatalogProvider(
      'https://5sim.net/v1',
      1000,
      'USD',
      fetchMock,
    );

    await expect(provider.getCatalog({})).rejects.toThrow(
      '5SIM catalog request failed with HTTP 502',
    );
  });
});
