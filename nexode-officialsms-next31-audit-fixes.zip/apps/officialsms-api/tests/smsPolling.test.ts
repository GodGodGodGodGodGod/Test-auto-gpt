import { describe, expect, it, vi } from 'vitest';
import { SmsPollingService } from '../src/modules/sms/application/smsPollingService.js';
import { OrderService } from '../src/modules/orders/application/orderService.js';
import { InMemoryOrderRepository } from '../src/modules/orders/infrastructure/inMemoryOrderRepository.js';
import type { SmsProvider } from '../src/providers/ports/sms-provider.js';

const price = { providerAmount: 2, providerCurrency: 'USD', customerAmount: 5, customerCurrency: 'USD', exchangeRate: 1, markupAmount: 3, pricingRuleVersion: 'v1', rateSource: 'test', rateCapturedAt: '2026-09-16T00:00:00.000Z' };


describe('SmsPollingService', () => {
  it('records received SMS and moves ACTIVE to SMS_RECEIVED', async () => {
    const orders = new OrderService(new InMemoryOrderRepository());
    await orders.create({ id: 'o1', customerId: 'c1', provider: '5sim', country: 'nigeria', operator: 'any', service: 'telegram', price, purchaseIdempotencyKey: 'o1' });
    await orders.transition('o1', 'PAYMENT_RESERVED');
    await orders.transition('o1', 'PURCHASING');
    await orders.attachProviderActivation('o1', { providerOrderId: 'p1', phone: '+123' });
    await orders.transition('o1', 'ACTIVE');
    const check = vi.fn(async () => ({ id: 'p1', phone: '+123', product: 'telegram', price: 2, currency: 'USD', status: 'RECEIVED', sms: [{ id: 9, text: 'Code 123456', code: '123456' }] }));
    const p = { name: '5sim', purchase: vi.fn(), check, finish: vi.fn(), cancel: vi.fn(), ban: vi.fn() } as SmsProvider;
    const result = await new SmsPollingService(p, orders).poll('o1');
    expect(result.outcome).toBe('RECEIVED');
    expect((await orders.findById('o1'))?.status).toBe('SMS_RECEIVED');
    expect((await orders.findById('o1'))?.sms[0]?.code).toBe('123456');
  });

  it('does not poll orders without a provider activation', async () => {
    const orders = new OrderService(new InMemoryOrderRepository());
    await orders.create({ id: 'o2', customerId: 'c1', provider: '5sim', country: 'nigeria', operator: 'any', service: 'telegram', price, purchaseIdempotencyKey: 'o2' });
    const check = vi.fn();
    const p = { name: '5sim', purchase: vi.fn(), check, finish: vi.fn(), cancel: vi.fn(), ban: vi.fn() } as SmsProvider;
    const result = await new SmsPollingService(p, orders).poll('o2');
    expect(result.outcome).toBe('IGNORED');
    expect(check).not.toHaveBeenCalled();
  });
});
