import { describe, expect, it } from 'vitest';
import { FiveSimApiError, FiveSimClient } from '../src/providers/five-sim/fiveSimClient.js';

describe('FiveSimClient', () => {
  it('sends the bearer token and parses the profile', async () => {
    const client = new FiveSimClient({
      baseUrl: 'https://5sim.test/v1',
      apiKey: 'secret',
      timeoutMs: 1000,
      fetchImpl: async (_input, init) => {
        expect((init?.headers as Record<string, string>).Authorization).toBe('Bearer secret');
        return new Response(JSON.stringify({ id: 1, balance: 12.5, email: 'ops@example.com' }), {
          status: 200,
          headers: { 'content-type': 'application/json' },
        });
      },
    });

    await expect(client.getProfile()).resolves.toMatchObject({
      id: 1,
      balance: 12.5,
      email: 'ops@example.com',
    });
  });

  it('parses orders', async () => {
    const client = new FiveSimClient({
      baseUrl: 'https://5sim.test/v1',
      apiKey: 'secret',
      timeoutMs: 1000,
      fetchImpl: async () => new Response(JSON.stringify([
        { id: 10, phone: '+123', product: 'telegram', price: 1.2, status: 'RECEIVING', sms: [] },
      ])),
    });

    await expect(client.getOrders({ limit: 1 })).resolves.toEqual([
      expect.objectContaining({ id: 10, phone: '+123', product: 'telegram', price: 1.2 }),
    ]);
  });

  it('turns non-2xx responses into a provider error', async () => {
    const client = new FiveSimClient({
      baseUrl: 'https://5sim.test/v1',
      apiKey: 'secret',
      timeoutMs: 1000,
      fetchImpl: async () => new Response('{}', { status: 401 }),
    });

    await expect(client.getProfile()).rejects.toBeInstanceOf(FiveSimApiError);
  });
});
