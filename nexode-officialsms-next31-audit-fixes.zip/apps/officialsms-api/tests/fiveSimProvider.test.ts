import { describe, expect, it } from 'vitest';
import { FiveSimProvider } from '../src/providers/five-sim/fiveSimClient.js';

function makeProvider(handler: (url: string, init?: RequestInit) => Response | Promise<Response>): FiveSimProvider {
  return new FiveSimProvider({
    baseUrl: 'https://5sim.test/v1',
    apiKey: 'secret',
    timeoutMs: 1000,
    fetchImpl: async (input, init) => handler(String(input), init),
  });
}

describe('FiveSimProvider', () => {
  it('purchases an activation through the provider port', async () => {
    const provider = makeProvider((url, init) => {
      expect(url).toBe('https://5sim.test/v1/user/buy/activation/england/any/telegram');
      expect((init?.headers as Record<string, string>).Authorization).toBe('Bearer secret');
      return new Response(JSON.stringify({
        id: 123,
        phone: '+44123',
        operator: 'any',
        product: 'telegram',
        price: 1.25,
        status: 'PENDING',
        sms: null,
      }), { status: 200, headers: { 'content-type': 'application/json' } });
    });

    await expect(provider.purchase({
      country: 'england', operator: 'any', service: 'telegram',
    })).resolves.toMatchObject({ id: '123', phone: '+44123', status: 'PENDING' });
  });

  it('checks an activation and maps SMS messages', async () => {
    const provider = makeProvider((url) => {
      expect(url).toBe('https://5sim.test/v1/user/check/123');
      return new Response(JSON.stringify({
        id: 123,
        phone: '+44123',
        product: 'telegram',
        price: 1.25,
        status: 'RECEIVED',
        sms: [{ id: 9, sender: 'Telegram', text: 'Code 123456', code: '123456' }],
      }));
    });

    await expect(provider.check('123')).resolves.toMatchObject({
      id: '123',
      status: 'RECEIVED',
      sms: [{ code: '123456', sender: 'Telegram' }],
    });
  });

  it('preserves provider text errors', async () => {
    const provider = makeProvider(() => new Response('no free phones', {
      status: 400,
      headers: { 'content-type': 'text/plain' },
    }));

    await expect(provider.purchase({
      country: 'england', operator: 'any', service: 'telegram',
    })).rejects.toMatchObject({ status: 400, providerMessage: 'no free phones' });
  });
});
