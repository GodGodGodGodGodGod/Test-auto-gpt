CREATE TABLE IF NOT EXISTS officialsms_provider_health (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  provider TEXT NOT NULL,
  status TEXT NOT NULL CHECK (status IN ('HEALTHY','DEGRADED','UNAVAILABLE')),
  latency_ms INTEGER,
  checked_at TIMESTAMPTZ NOT NULL,
  error TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS officialsms_provider_health_provider_checked_idx
  ON officialsms_provider_health (provider, checked_at DESC);
