CREATE TABLE IF NOT EXISTS officialsms_orders (
  id TEXT PRIMARY KEY,
  customer_id TEXT NOT NULL,
  purchase_idempotency_key TEXT NOT NULL,
  provider TEXT NOT NULL,
  provider_order_id TEXT,
  country TEXT NOT NULL,
  operator TEXT NOT NULL,
  service TEXT NOT NULL,
  phone TEXT,
  status TEXT NOT NULL CHECK (status IN ('CREATED','PAYMENT_RESERVED','PURCHASING','ACTIVE','SMS_RECEIVED','COMPLETED','FAILED','EXPIRED','CANCELLED')),
  provider_amount NUMERIC(30,12) NOT NULL CHECK (provider_amount >= 0),
  provider_currency CHAR(3) NOT NULL CHECK (provider_currency ~ '^[A-Z]{3}$'),
  customer_amount NUMERIC(30,12) NOT NULL CHECK (customer_amount >= 0),
  customer_currency CHAR(3) NOT NULL CHECK (customer_currency ~ '^[A-Z]{3}$'),
  exchange_rate NUMERIC(30,18) NOT NULL CHECK (exchange_rate > 0),
  markup_amount NUMERIC(30,12) NOT NULL CHECK (markup_amount >= 0),
  pricing_rule_version TEXT NOT NULL,
  rate_source TEXT NOT NULL,
  rate_captured_at TIMESTAMPTZ NOT NULL,
  created_at TIMESTAMPTZ NOT NULL,
  updated_at TIMESTAMPTZ NOT NULL,
  expires_at TIMESTAMPTZ,
  sms_received_at TIMESTAMPTZ,
  completed_at TIMESTAMPTZ,
  failure_code TEXT,
  CONSTRAINT officialsms_order_customer_idempotency UNIQUE (customer_id, purchase_idempotency_key),
  CONSTRAINT officialsms_order_provider_reference UNIQUE (provider, provider_order_id)
);

CREATE INDEX IF NOT EXISTS officialsms_orders_customer_created_idx
  ON officialsms_orders(customer_id, created_at DESC);
CREATE INDEX IF NOT EXISTS officialsms_orders_status_updated_idx
  ON officialsms_orders(status, updated_at);

CREATE TABLE IF NOT EXISTS officialsms_purchase_attempts (
  id TEXT PRIMARY KEY,
  order_id TEXT NOT NULL REFERENCES officialsms_orders(id),
  provider TEXT NOT NULL,
  status TEXT NOT NULL CHECK (status IN ('CREATED','SUBMITTED','SUCCEEDED','FAILED','UNKNOWN','RECONCILING')),
  country TEXT NOT NULL,
  operator TEXT NOT NULL,
  service TEXT NOT NULL,
  wallet_id TEXT NOT NULL,
  reservation_id TEXT NOT NULL,
  max_provider_price NUMERIC(30,12) NOT NULL CHECK (max_provider_price > 0),
  provider_order_id TEXT,
  error_code TEXT,
  error_message TEXT,
  created_at TIMESTAMPTZ NOT NULL,
  updated_at TIMESTAMPTZ NOT NULL,
  submitted_at TIMESTAMPTZ,
  resolved_at TIMESTAMPTZ,
  CONSTRAINT officialsms_purchase_attempt_order_unique UNIQUE(order_id)
);

CREATE UNIQUE INDEX IF NOT EXISTS officialsms_purchase_attempt_provider_reference_idx
  ON officialsms_purchase_attempts(provider, provider_order_id)
  WHERE provider_order_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS officialsms_purchase_attempts_reconciliation_idx
  ON officialsms_purchase_attempts(status, updated_at);
