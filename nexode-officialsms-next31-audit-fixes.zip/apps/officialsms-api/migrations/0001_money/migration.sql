CREATE TABLE IF NOT EXISTS officialsms_wallets (
  id TEXT PRIMARY KEY,
  customer_id TEXT NOT NULL,
  currency CHAR(3) NOT NULL CHECK (currency ~ '^[A-Z]{3}$'),
  available_minor NUMERIC(39,0) NOT NULL CHECK (available_minor >= 0),
  reserved_minor NUMERIC(39,0) NOT NULL DEFAULT 0 CHECK (reserved_minor >= 0),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS officialsms_wallet_reservations (
  id TEXT PRIMARY KEY,
  wallet_id TEXT NOT NULL REFERENCES officialsms_wallets(id),
  amount_minor NUMERIC(39,0) NOT NULL CHECK (amount_minor > 0),
  currency CHAR(3) NOT NULL CHECK (currency ~ '^[A-Z]{3}$'),
  idempotency_key TEXT NOT NULL,
  status TEXT NOT NULL CHECK (status IN ('ACTIVE','RELEASED','CAPTURED')),
  created_at TIMESTAMPTZ NOT NULL,
  updated_at TIMESTAMPTZ NOT NULL,
  CONSTRAINT officialsms_reservation_idempotency UNIQUE (wallet_id, idempotency_key)
);

CREATE INDEX IF NOT EXISTS officialsms_reservations_wallet_status_idx
  ON officialsms_wallet_reservations(wallet_id, status);

CREATE TABLE IF NOT EXISTS officialsms_ledger_transactions (
  id TEXT PRIMARY KEY,
  idempotency_key TEXT NOT NULL UNIQUE,
  description TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL
);

CREATE TABLE IF NOT EXISTS officialsms_ledger_entries (
  id TEXT PRIMARY KEY,
  transaction_id TEXT NOT NULL REFERENCES officialsms_ledger_transactions(id),
  account_id TEXT NOT NULL,
  side TEXT NOT NULL CHECK (side IN ('DEBIT','CREDIT')),
  amount_minor NUMERIC(39,0) NOT NULL CHECK (amount_minor >= 0),
  currency CHAR(3) NOT NULL CHECK (currency ~ '^[A-Z]{3}$')
);

CREATE INDEX IF NOT EXISTS officialsms_ledger_entries_transaction_idx
  ON officialsms_ledger_entries(transaction_id);

CREATE UNIQUE INDEX IF NOT EXISTS officialsms_wallet_customer_currency_uidx
  ON officialsms_wallets(customer_id, currency);
