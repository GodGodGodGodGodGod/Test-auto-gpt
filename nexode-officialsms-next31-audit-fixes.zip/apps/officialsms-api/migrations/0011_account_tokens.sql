CREATE TABLE IF NOT EXISTS nexode_identity_email_verification_tokens (
  id UUID PRIMARY KEY,
  user_id TEXT NOT NULL REFERENCES nexode_identity_users(id) ON DELETE CASCADE,
  token_hash TEXT NOT NULL UNIQUE,
  created_at TIMESTAMPTZ NOT NULL,
  expires_at TIMESTAMPTZ NOT NULL,
  used_at TIMESTAMPTZ NULL
);
CREATE INDEX IF NOT EXISTS idx_identity_email_verification_user ON nexode_identity_email_verification_tokens(user_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_identity_email_verification_expiry ON nexode_identity_email_verification_tokens(expires_at);

CREATE TABLE IF NOT EXISTS nexode_identity_password_reset_tokens (
  id UUID PRIMARY KEY,
  user_id TEXT NOT NULL REFERENCES nexode_identity_users(id) ON DELETE CASCADE,
  token_hash TEXT NOT NULL UNIQUE,
  created_at TIMESTAMPTZ NOT NULL,
  expires_at TIMESTAMPTZ NOT NULL,
  used_at TIMESTAMPTZ NULL
);
CREATE INDEX IF NOT EXISTS idx_identity_password_reset_user ON nexode_identity_password_reset_tokens(user_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_identity_password_reset_expiry ON nexode_identity_password_reset_tokens(expires_at);
