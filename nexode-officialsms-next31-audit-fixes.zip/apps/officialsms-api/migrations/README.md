# OfficialSMS database migrations

Apply migrations in numeric order against the configured PostgreSQL database.

Account-token migration:

```bash
pnpm --filter @nexode/officialsms-api migrate:account-tokens
```

Email verification and password-reset tokens are stored as SHA-256 hashes. The raw token is only held by the application long enough to deliver it to the user.
