CREATE TABLE IF NOT EXISTS officialsms_exchange_rates (
  id BIGSERIAL PRIMARY KEY,
  from_currency CHAR(3) NOT NULL CHECK (from_currency ~ '^[A-Z]{3}$'),
  to_currency CHAR(3) NOT NULL CHECK (to_currency ~ '^[A-Z]{3}$'),
  rate NUMERIC(30,18) NOT NULL CHECK (rate > 0),
  source TEXT NOT NULL,
  captured_at TIMESTAMPTZ NOT NULL,
  expires_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS officialsms_exchange_rates_lookup_idx
  ON officialsms_exchange_rates(from_currency, to_currency, captured_at DESC);

CREATE TABLE IF NOT EXISTS officialsms_markup_rules (
  id BIGSERIAL PRIMARY KEY,
  customer_currency CHAR(3) NOT NULL CHECK (customer_currency ~ '^[A-Z]{3}$'),
  percentage_bps INTEGER NOT NULL CHECK (percentage_bps >= 0),
  minimum_amount NUMERIC(30,12) NOT NULL CHECK (minimum_amount >= 0),
  maximum_amount NUMERIC(30,12),
  version TEXT NOT NULL,
  active BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  CHECK (maximum_amount IS NULL OR maximum_amount >= minimum_amount)
);
CREATE INDEX IF NOT EXISTS officialsms_markup_rules_lookup_idx
  ON officialsms_markup_rules(customer_currency, active, created_at DESC);
