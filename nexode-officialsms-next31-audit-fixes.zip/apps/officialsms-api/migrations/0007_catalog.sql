CREATE TABLE IF NOT EXISTS officialsms_catalog_snapshots (
  id BIGSERIAL PRIMARY KEY,
  provider TEXT NOT NULL,
  country TEXT,
  service TEXT,
  products JSONB NOT NULL,
  fetched_at TIMESTAMPTZ NOT NULL,
  expires_at TIMESTAMPTZ NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  CHECK (jsonb_typeof(products) = 'array')
);
CREATE INDEX IF NOT EXISTS officialsms_catalog_snapshots_lookup_idx
  ON officialsms_catalog_snapshots(provider, country, service, fetched_at DESC, id DESC);
