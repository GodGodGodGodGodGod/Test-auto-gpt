ALTER TABLE officialsms_orders
  ADD COLUMN IF NOT EXISTS sms JSONB NOT NULL DEFAULT '[]'::jsonb;

CREATE INDEX IF NOT EXISTS officialsms_orders_active_status_idx
  ON officialsms_orders (status, updated_at)
  WHERE status IN ('ACTIVE', 'SMS_RECEIVED');
