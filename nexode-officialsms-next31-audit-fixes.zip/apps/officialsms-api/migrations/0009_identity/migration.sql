CREATE EXTENSION IF NOT EXISTS citext;

CREATE TABLE IF NOT EXISTS nexode_identity_users (
  id TEXT PRIMARY KEY,
  email CITEXT NOT NULL UNIQUE,
  username CITEXT UNIQUE,
  display_name TEXT,
  roles JSONB NOT NULL DEFAULT '[]'::jsonb,
  permissions JSONB NOT NULL DEFAULT '[]'::jsonb,
  password_hash TEXT NOT NULL,
  enabled BOOLEAN NOT NULL DEFAULT TRUE,
  email_verified BOOLEAN NOT NULL DEFAULT FALSE,
  created_at TIMESTAMPTZ NOT NULL,
  updated_at TIMESTAMPTZ NOT NULL,
  CONSTRAINT nexode_identity_users_roles_array CHECK (jsonb_typeof(roles) = 'array'),
  CONSTRAINT nexode_identity_users_permissions_array CHECK (jsonb_typeof(permissions) = 'array')
);

CREATE INDEX IF NOT EXISTS nexode_identity_users_enabled_idx
  ON nexode_identity_users(enabled);

CREATE TABLE IF NOT EXISTS nexode_identity_sessions (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL REFERENCES nexode_identity_users(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ NOT NULL,
  expires_at TIMESTAMPTZ NOT NULL,
  last_activity_at TIMESTAMPTZ NOT NULL,
  ip_address INET,
  user_agent TEXT,
  device_name TEXT,
  CONSTRAINT nexode_identity_sessions_dates_valid CHECK (expires_at > created_at)
);

CREATE INDEX IF NOT EXISTS nexode_identity_sessions_user_created_idx
  ON nexode_identity_sessions(user_id, created_at DESC);
CREATE INDEX IF NOT EXISTS nexode_identity_sessions_expiry_idx
  ON nexode_identity_sessions(expires_at);
