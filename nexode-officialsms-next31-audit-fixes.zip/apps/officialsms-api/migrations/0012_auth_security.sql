CREATE TABLE IF NOT EXISTS officialsms_login_security (
  security_key TEXT PRIMARY KEY,
  failed_attempts INTEGER NOT NULL DEFAULT 0 CHECK (failed_attempts >= 0),
  locked_until TIMESTAMPTZ,
  last_failed_at TIMESTAMPTZ,
  last_succeeded_at TIMESTAMPTZ,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS officialsms_login_security_locked_until_idx
  ON officialsms_login_security (locked_until)
  WHERE locked_until IS NOT NULL;

CREATE TABLE IF NOT EXISTS officialsms_security_audit_events (
  id TEXT PRIMARY KEY,
  user_id TEXT,
  action TEXT NOT NULL,
  resource TEXT NOT NULL,
  occurred_at TIMESTAMPTZ NOT NULL,
  metadata JSONB NOT NULL DEFAULT '{}'::jsonb
);

CREATE INDEX IF NOT EXISTS officialsms_security_audit_user_time_idx
  ON officialsms_security_audit_events (user_id, occurred_at DESC);
CREATE INDEX IF NOT EXISTS officialsms_security_audit_action_time_idx
  ON officialsms_security_audit_events (action, occurred_at DESC);

CREATE INDEX IF NOT EXISTS officialsms_login_security_updated_at_idx
  ON officialsms_login_security (updated_at);
