CREATE TABLE IF NOT EXISTS officialsms_jobs (
  id TEXT PRIMARY KEY,
  type TEXT NOT NULL,
  payload JSONB NOT NULL,
  dedupe_key TEXT,
  status TEXT NOT NULL CHECK (status IN ('QUEUED','RUNNING','SUCCEEDED','FAILED')),
  attempts INTEGER NOT NULL DEFAULT 0 CHECK (attempts >= 0),
  max_attempts INTEGER NOT NULL DEFAULT 5 CHECK (max_attempts > 0),
  available_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  locked_until TIMESTAMPTZ,
  locked_by TEXT,
  last_error TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE UNIQUE INDEX IF NOT EXISTS officialsms_jobs_active_dedupe_idx
  ON officialsms_jobs (dedupe_key)
  WHERE dedupe_key IS NOT NULL AND status IN ('QUEUED','RUNNING');

CREATE INDEX IF NOT EXISTS officialsms_jobs_claim_idx
  ON officialsms_jobs (status, available_at, created_at);

CREATE INDEX IF NOT EXISTS officialsms_jobs_type_status_idx
  ON officialsms_jobs (type, status, available_at);
