CREATE TABLE IF NOT EXISTS officialsms_deposit_intents (
  id TEXT PRIMARY KEY,
  customer_id TEXT NOT NULL,
  amount_minor NUMERIC(39,0) NOT NULL CHECK (amount_minor > 0),
  currency CHAR(3) NOT NULL CHECK (currency ~ '^[A-Z]{3}$'),
  provider TEXT NOT NULL,
  provider_reference TEXT,
  idempotency_key TEXT NOT NULL,
  status TEXT NOT NULL CHECK (status IN ('PENDING','SUCCEEDED','FAILED','CANCELLED')),
  created_at TIMESTAMPTZ NOT NULL,
  updated_at TIMESTAMPTZ NOT NULL,
  completed_at TIMESTAMPTZ,
  CONSTRAINT officialsms_deposit_customer_idempotency UNIQUE (customer_id, idempotency_key),
  CONSTRAINT officialsms_deposit_provider_reference UNIQUE (provider, provider_reference)
);

CREATE INDEX IF NOT EXISTS officialsms_deposit_provider_reference_idx
  ON officialsms_deposit_intents(provider, provider_reference);

-- A provider callback may arrive more than once; provider references are unique per provider.
