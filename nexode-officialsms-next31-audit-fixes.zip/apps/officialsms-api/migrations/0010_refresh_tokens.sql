CREATE TABLE IF NOT EXISTS nexode_identity_refresh_tokens (
  token_hash text PRIMARY KEY,
  user_id text NOT NULL REFERENCES nexode_identity_users(id) ON DELETE CASCADE,
  session_id text NOT NULL REFERENCES nexode_identity_sessions(id) ON DELETE CASCADE,
  family_id text NOT NULL,
  issued_at timestamptz NOT NULL,
  expires_at timestamptz NOT NULL,
  revoked_at timestamptz,
  replaced_by_hash text
);

CREATE INDEX IF NOT EXISTS idx_identity_refresh_tokens_session
  ON nexode_identity_refresh_tokens(session_id);
CREATE INDEX IF NOT EXISTS idx_identity_refresh_tokens_family
  ON nexode_identity_refresh_tokens(family_id);
CREATE INDEX IF NOT EXISTS idx_identity_refresh_tokens_expires
  ON nexode_identity_refresh_tokens(expires_at);
