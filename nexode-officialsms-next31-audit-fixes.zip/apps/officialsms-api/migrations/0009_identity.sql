-- Shared NeXoDe identity persistence used by OfficialSMS.
CREATE TABLE IF NOT EXISTS nexode_identity_users (
  id TEXT PRIMARY KEY,
  email TEXT NOT NULL,
  email_normalized TEXT NOT NULL UNIQUE,
  username TEXT,
  username_normalized TEXT UNIQUE,
  display_name TEXT,
  roles TEXT[] NOT NULL DEFAULT ARRAY[]::TEXT[],
  permissions TEXT[] NOT NULL DEFAULT ARRAY[]::TEXT[],
  created_at TIMESTAMPTZ NOT NULL,
  updated_at TIMESTAMPTZ NOT NULL,
  enabled BOOLEAN NOT NULL DEFAULT TRUE,
  email_verified BOOLEAN NOT NULL DEFAULT FALSE,
  password_hash TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS nexode_identity_users_enabled_idx
  ON nexode_identity_users (enabled);

CREATE TABLE IF NOT EXISTS nexode_identity_sessions (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL REFERENCES nexode_identity_users(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ NOT NULL,
  expires_at TIMESTAMPTZ NOT NULL,
  last_activity_at TIMESTAMPTZ NOT NULL,
  ip_address INET,
  user_agent TEXT,
  device_name TEXT
);

CREATE INDEX IF NOT EXISTS nexode_identity_sessions_user_idx
  ON nexode_identity_sessions (user_id, created_at DESC);

CREATE INDEX IF NOT EXISTS nexode_identity_sessions_expiry_idx
  ON nexode_identity_sessions (expires_at);
