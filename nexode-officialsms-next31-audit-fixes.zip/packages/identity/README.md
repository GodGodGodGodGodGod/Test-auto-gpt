# @nexode/identity

Shared identity primitives and persistence contracts for users, sessions, password recovery, email verification, and account security.
