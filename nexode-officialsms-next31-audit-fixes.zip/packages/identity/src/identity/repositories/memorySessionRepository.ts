import type { IdentitySession } from '../models/identitySession.js';
import type { SessionRepository } from './sessionRepository.js';

export class MemorySessionRepository implements SessionRepository {
  private readonly sessions = new Map<string, IdentitySession>();
  async findById(id: string): Promise<IdentitySession | undefined> { return this.sessions.get(id); }
  async findByUserId(userId: string): Promise<readonly IdentitySession[]> { return [...this.sessions.values()].filter((session) => session.userId === userId); }
  async save(session: IdentitySession): Promise<void> { this.sessions.set(session.id, session); }
  async delete(id: string): Promise<void> { this.sessions.delete(id); }
  async deleteForUser(id: string, userId: string): Promise<boolean> {
    const session = this.sessions.get(id);
    if (!session || session.userId !== userId) return false;
    this.sessions.delete(id);
    return true;
  }
  async deleteAllForUser(userId: string): Promise<number> {
    let count = 0;
    for (const [id, session] of this.sessions) {
      if (session.userId === userId) { this.sessions.delete(id); count += 1; }
    }
    return count;
  }
  async deleteAllForUserExcept(userId: string, sessionId: string): Promise<number> {
    let count = 0;
    for (const [id, session] of this.sessions) {
      if (session.userId === userId && id !== sessionId) { this.sessions.delete(id); count += 1; }
    }
    return count;
  }
  async deleteExpired(now: Date): Promise<number> {
    let count = 0;
    for (const [id, session] of this.sessions) {
      if (session.expiresAt <= now) { this.sessions.delete(id); count += 1; }
    }
    return count;
  }
}
