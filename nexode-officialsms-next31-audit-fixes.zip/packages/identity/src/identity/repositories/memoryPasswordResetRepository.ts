import type {
  PasswordResetToken,
} from '../models/passwordResetToken.js';

import type {
  PasswordResetRepository,
} from './passwordResetRepository.js';

export class MemoryPasswordResetRepository
  implements PasswordResetRepository {

  private readonly resets =
    new Map<string, PasswordResetToken>();

  async create(
    reset: PasswordResetToken,
  ): Promise<void> {
    this.resets.set(
      reset.token,
      reset,
    );
  }

  async findByToken(
    token: string,
  ): Promise<
    PasswordResetToken | undefined
  > {
    return this.resets.get(token);
  }

  async consume(token: string): Promise<PasswordResetToken | undefined> {
    const current = this.resets.get(token);
    if (!current || current.usedAt) return undefined;
    const consumed = { ...current, usedAt: new Date() };
    this.resets.set(token, consumed);
    return consumed;
  }

  async deleteByUserId(userId: string): Promise<void> {
    for (const [key, reset] of this.resets) {
      if (reset.userId === userId) this.resets.delete(key);
    }
  }

  async save(
    reset: PasswordResetToken,
  ): Promise<void> {
    this.resets.set(
      reset.token,
      reset,
    );
  }
}