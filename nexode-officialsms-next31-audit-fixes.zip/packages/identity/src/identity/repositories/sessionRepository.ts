import type {
  IdentitySession,
} from '../models/identitySession.js';

export interface SessionRepository {
  findById(
    id: string,
  ): Promise<IdentitySession | undefined>;

  findByUserId(
    userId: string,
  ): Promise<
    readonly IdentitySession[]
  >;

  save(
    session: IdentitySession,
  ): Promise<void>;

  delete(
    id: string,
  ): Promise<void>;

  deleteForUser(
    id: string,
    userId: string,
  ): Promise<boolean>;

  deleteAllForUser(
    userId: string,
  ): Promise<number>;

  deleteAllForUserExcept(
    userId: string,
    sessionId: string,
  ): Promise<number>;

  deleteExpired(
    now: Date,
  ): Promise<number>;
}