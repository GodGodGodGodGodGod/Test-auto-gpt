import type {
  EmailVerificationToken,
} from '../models/emailVerificationToken.js';

export interface EmailVerificationRepository {
  findByToken(
    token: string,
  ): Promise<
    EmailVerificationToken | undefined
  >;

  findByUserId(
    userId: string,
  ): Promise<
    EmailVerificationToken | undefined
  >;

  save(
    token: EmailVerificationToken,
  ): Promise<void>;

  update(
    token: EmailVerificationToken,
  ): Promise<void>;

  consume(token: string): Promise<EmailVerificationToken | undefined>;

  deleteByUserId(
    userId: string,
  ): Promise<void>;
}