import type {
  PasswordResetToken,
} from '../models/passwordResetToken.js';

export interface PasswordResetRepository {
  create(
    reset: PasswordResetToken,
  ): Promise<void>;

  findByToken(
    token: string,
  ): Promise<
    PasswordResetToken | undefined
  >;

  save(
    reset: PasswordResetToken,
  ): Promise<void>;

  consume(token: string): Promise<PasswordResetToken | undefined>;

  deleteByUserId(userId: string): Promise<void>;
}