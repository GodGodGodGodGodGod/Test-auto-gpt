import { randomUUID } from 'node:crypto';
import type { UserRepository } from '../repositories/userRepository.js';
import type { SessionRepository } from '../repositories/sessionRepository.js';
import type { PasswordResetRepository } from '../repositories/passwordResetRepository.js';
import type { PasswordHasher } from '../../security/passwordHasher.js';
import type { PasswordResetToken } from '../models/passwordResetToken.js';

export class PasswordResetService {
  constructor(private readonly users: UserRepository, private readonly resets: PasswordResetRepository, private readonly hasher: PasswordHasher, private readonly sessions: SessionRepository) {}

  async request(email: string): Promise<PasswordResetToken | undefined> {
    const user = await this.users.findByEmail(email);
    if (!user || !user.enabled) return undefined;
    await this.resets.deleteByUserId(user.id);
    const now = new Date();
    const token: PasswordResetToken = { id: randomUUID(), userId: user.id, token: randomUUID() + randomUUID(), createdAt: now, expiresAt: new Date(now.getTime() + 30 * 60_000) };
    await this.resets.create(token);
    return token;
  }

  async reset(tokenValue: string, password: string): Promise<void> {
    const token = await this.resets.findByToken(tokenValue);
    if (!token || token.usedAt || token.expiresAt.getTime() <= Date.now()) throw new Error('Invalid or expired password reset token.');
    const consumed = await this.resets.consume(tokenValue);
    if (!consumed) throw new Error('Invalid or expired password reset token.');
    const user = await this.users.findById(consumed.userId);
    if (!user || !user.enabled) throw new Error('Invalid or expired password reset token.');
    await this.users.save({ ...user, passwordHash: await this.hasher.hash(password), updatedAt: new Date() });
    const sessions = await this.sessions.findByUserId(user.id);
    await Promise.all(sessions.map((session) => this.sessions.delete(session.id)));
  }
}
