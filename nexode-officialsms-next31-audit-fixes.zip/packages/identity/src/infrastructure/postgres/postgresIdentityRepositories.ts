import type { Pool, PoolClient } from 'pg';
import type { IdentityUser } from '../../identity/models/identityUser.js';
import type { IdentitySession } from '../../identity/models/identitySession.js';
import type { UserRepository } from '../../identity/repositories/userRepository.js';
import type { SessionRepository } from '../../identity/repositories/sessionRepository.js';

function mapUser(row: Record<string, unknown>): IdentityUser {
  return {
    id: String(row.id),
    email: String(row.email),
    username: row.username == null ? undefined : String(row.username),
    displayName: row.display_name == null ? undefined : String(row.display_name),
    roles: Array.isArray(row.roles) ? row.roles.map(String) : [],
    permissions: Array.isArray(row.permissions) ? row.permissions.map(String) : [],
    createdAt: new Date(String(row.created_at)),
    updatedAt: new Date(String(row.updated_at)),
    enabled: Boolean(row.enabled),
    emailVerified: Boolean(row.email_verified),
    passwordHash: String(row.password_hash),
  };
}

function mapSession(row: Record<string, unknown>): IdentitySession {
  return {
    id: String(row.id),
    userId: String(row.user_id),
    createdAt: new Date(String(row.created_at)),
    expiresAt: new Date(String(row.expires_at)),
    lastActivityAt: new Date(String(row.last_activity_at)),
    ipAddress: row.ip_address == null ? undefined : String(row.ip_address),
    userAgent: row.user_agent == null ? undefined : String(row.user_agent),
    deviceName: row.device_name == null ? undefined : String(row.device_name),
  };
}

export class PostgresUserRepository implements UserRepository {
  constructor(private readonly pool: Pool) {}

  async findById(id: string): Promise<IdentityUser | undefined> {
    const result = await this.pool.query('SELECT * FROM nexode_identity_users WHERE id = $1 LIMIT 1', [id]);
    const row = result.rows[0] as Record<string, unknown> | undefined;
    return row ? mapUser(row) : undefined;
  }

  async findByEmail(email: string): Promise<IdentityUser | undefined> {
    const result = await this.pool.query('SELECT * FROM nexode_identity_users WHERE email = lower($1) LIMIT 1', [email]);
    const row = result.rows[0] as Record<string, unknown> | undefined;
    return row ? mapUser(row) : undefined;
  }

  async findByUsername(username: string): Promise<IdentityUser | undefined> {
    const result = await this.pool.query('SELECT * FROM nexode_identity_users WHERE username = lower($1) LIMIT 1', [username]);
    const row = result.rows[0] as Record<string, unknown> | undefined;
    return row ? mapUser(row) : undefined;
  }

  async save(user: IdentityUser): Promise<void> {
    await this.pool.query(
      `INSERT INTO nexode_identity_users
        (id, email, username, display_name, roles, permissions, password_hash, enabled, email_verified, created_at, updated_at)
       VALUES ($1, lower($2), lower($3), $4, $5::jsonb, $6::jsonb, $7, $8, $9, $10, $11)
       ON CONFLICT (id) DO UPDATE SET
        email = EXCLUDED.email,
        username = EXCLUDED.username,
        display_name = EXCLUDED.display_name,
        roles = EXCLUDED.roles,
        permissions = EXCLUDED.permissions,
        password_hash = EXCLUDED.password_hash,
        enabled = EXCLUDED.enabled,
        email_verified = EXCLUDED.email_verified,
        updated_at = EXCLUDED.updated_at`,
      [
        user.id,
        user.email,
        user.username ?? null,
        user.displayName ?? null,
        JSON.stringify(user.roles),
        JSON.stringify(user.permissions),
        user.passwordHash,
        user.enabled,
        user.emailVerified,
        user.createdAt,
        user.updatedAt,
      ],
    );
  }

  async delete(id: string): Promise<void> {
    await this.pool.query('UPDATE nexode_identity_users SET enabled = false, updated_at = now() WHERE id = $1', [id]);
  }
}

export class PostgresSessionRepository implements SessionRepository {
  constructor(private readonly pool: Pool) {}

  async findById(id: string): Promise<IdentitySession | undefined> {
    const result = await this.pool.query(
      'SELECT * FROM nexode_identity_sessions WHERE id = $1 LIMIT 1',
      [id],
    );
    const row = result.rows[0] as Record<string, unknown> | undefined;
    return row ? mapSession(row) : undefined;
  }

  async findByUserId(userId: string): Promise<readonly IdentitySession[]> {
    const result = await this.pool.query(
      'SELECT * FROM nexode_identity_sessions WHERE user_id = $1 ORDER BY created_at DESC',
      [userId],
    );
    return result.rows.map((row) => mapSession(row as Record<string, unknown>));
  }

  async save(session: IdentitySession): Promise<void> {
    await this.pool.query(
      `INSERT INTO nexode_identity_sessions
        (id, user_id, created_at, expires_at, last_activity_at, ip_address, user_agent, device_name)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
       ON CONFLICT (id) DO UPDATE SET
        expires_at = EXCLUDED.expires_at,
        last_activity_at = EXCLUDED.last_activity_at,
        ip_address = EXCLUDED.ip_address,
        user_agent = EXCLUDED.user_agent,
        device_name = EXCLUDED.device_name`,
      [
        session.id,
        session.userId,
        session.createdAt,
        session.expiresAt,
        session.lastActivityAt,
        session.ipAddress ?? null,
        session.userAgent ?? null,
        session.deviceName ?? null,
      ],
    );
  }

  async delete(id: string): Promise<void> {
    await this.pool.query('DELETE FROM nexode_identity_sessions WHERE id = $1', [id]);
  }

  async deleteForUser(id: string, userId: string): Promise<boolean> {
    const result = await this.pool.query(
      'DELETE FROM nexode_identity_sessions WHERE id = $1 AND user_id = $2',
      [id, userId],
    );
    return result.rowCount === 1;
  }

  async deleteAllForUser(userId: string): Promise<number> {
    const result = await this.pool.query(
      'DELETE FROM nexode_identity_sessions WHERE user_id = $1',
      [userId],
    );
    return result.rowCount ?? 0;
  }

  async deleteAllForUserExcept(userId: string, sessionId: string): Promise<number> {
    const result = await this.pool.query(
      'DELETE FROM nexode_identity_sessions WHERE user_id = $1 AND id <> $2',
      [userId, sessionId],
    );
    return result.rowCount ?? 0;
  }

  async deleteExpired(now: Date): Promise<number> {
    const result = await this.pool.query(
      'DELETE FROM nexode_identity_sessions WHERE expires_at <= $1',
      [now],
    );
    return result.rowCount ?? 0;
  }

  async withClient<T>(callback: (client: PoolClient) => Promise<T>): Promise<T> {
    const client = await this.pool.connect();
    try {
      return await callback(client);
    } finally {
      client.release();
    }
  }
}
