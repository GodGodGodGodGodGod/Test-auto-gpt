import type { Pool, PoolClient } from 'pg';
import type { IdentityUser } from '../../identity/models/identityUser.js';
import type { UserRepository } from '../../identity/repositories/userRepository.js';

type QueryExecutor = Pick<Pool, 'query'> | Pick<PoolClient, 'query'>;

export class PostgresUserRepository implements UserRepository {
  constructor(private readonly db: QueryExecutor) {}

  async findById(id: string): Promise<IdentityUser | undefined> {
    const result = await this.db.query<UserRow>(
      `SELECT id, email, username, display_name, roles, permissions,
              created_at, updated_at, enabled, email_verified, password_hash
         FROM nexode_identity_users
        WHERE id = $1`,
      [id],
    );
    return result.rows[0] ? toIdentityUser(result.rows[0]) : undefined;
  }

  async findByEmail(email: string): Promise<IdentityUser | undefined> {
    const result = await this.db.query<UserRow>(
      `SELECT id, email, username, display_name, roles, permissions,
              created_at, updated_at, enabled, email_verified, password_hash
         FROM nexode_identity_users
        WHERE email_normalized = $1`,
      [normalize(email)],
    );
    return result.rows[0] ? toIdentityUser(result.rows[0]) : undefined;
  }

  async findByUsername(username: string): Promise<IdentityUser | undefined> {
    const result = await this.db.query<UserRow>(
      `SELECT id, email, username, display_name, roles, permissions,
              created_at, updated_at, enabled, email_verified, password_hash
         FROM nexode_identity_users
        WHERE username_normalized = $1`,
      [normalize(username)],
    );
    return result.rows[0] ? toIdentityUser(result.rows[0]) : undefined;
  }

  async save(user: IdentityUser): Promise<void> {
    await this.db.query(
      `INSERT INTO nexode_identity_users
        (id, email, email_normalized, username, username_normalized, display_name,
         roles, permissions, created_at, updated_at, enabled, email_verified, password_hash)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13)
       ON CONFLICT (id) DO UPDATE SET
         email = EXCLUDED.email,
         email_normalized = EXCLUDED.email_normalized,
         username = EXCLUDED.username,
         username_normalized = EXCLUDED.username_normalized,
         display_name = EXCLUDED.display_name,
         roles = EXCLUDED.roles,
         permissions = EXCLUDED.permissions,
         updated_at = EXCLUDED.updated_at,
         enabled = EXCLUDED.enabled,
         email_verified = EXCLUDED.email_verified,
         password_hash = EXCLUDED.password_hash`,
      [
        user.id,
        user.email,
        normalize(user.email),
        user.username ?? null,
        user.username ? normalize(user.username) : null,
        user.displayName ?? null,
        [...user.roles],
        [...user.permissions],
        user.createdAt,
        user.updatedAt,
        user.enabled,
        user.emailVerified,
        user.passwordHash,
      ],
    );
  }

  async delete(id: string): Promise<void> {
    await this.db.query('DELETE FROM nexode_identity_users WHERE id = $1', [id]);
  }
}

interface UserRow {
  id: string;
  email: string;
  username: string | null;
  display_name: string | null;
  roles: string[];
  permissions: string[];
  created_at: Date;
  updated_at: Date;
  enabled: boolean;
  email_verified: boolean;
  password_hash: string;
}

function normalize(value: string): string {
  return value.trim().toLowerCase();
}

function toIdentityUser(row: UserRow): IdentityUser {
  return {
    id: row.id,
    email: row.email,
    username: row.username ?? undefined,
    displayName: row.display_name ?? undefined,
    roles: row.roles,
    permissions: row.permissions,
    createdAt: new Date(row.created_at),
    updatedAt: new Date(row.updated_at),
    enabled: row.enabled,
    emailVerified: row.email_verified,
    passwordHash: row.password_hash,
  };
}
