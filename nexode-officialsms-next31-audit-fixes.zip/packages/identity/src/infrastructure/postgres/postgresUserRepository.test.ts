import { describe, expect, it, vi } from 'vitest';
import { PostgresUserRepository } from './postgresUserRepository.js';

function row() {
  return {
    id: 'usr_1', email: 'User@Example.com', username: 'UserOne', display_name: 'User One',
    roles: ['customer'], permissions: ['purchases.create'], created_at: new Date('2026-01-01T00:00:00Z'),
    updated_at: new Date('2026-01-02T00:00:00Z'), enabled: true, email_verified: true, password_hash: 'hash',
  };
}

describe('PostgresUserRepository', () => {
  it('normalizes email lookup and maps database rows', async () => {
    const query = vi.fn().mockResolvedValue({ rows: [row()] });
    const repo = new PostgresUserRepository({ query });
    const user = await repo.findByEmail(' USER@EXAMPLE.COM ');
    expect(query).toHaveBeenCalledWith(expect.stringContaining('email_normalized'), ['user@example.com']);
    expect(user).toMatchObject({ id: 'usr_1', email: 'User@Example.com', username: 'UserOne', emailVerified: true });
  });
});
