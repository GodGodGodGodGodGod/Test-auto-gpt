import { createHash } from 'node:crypto';
import type { Pool } from 'pg';
import type { EmailVerificationRepository } from '../../identity/repositories/emailVerificationRepository.js';
import type { EmailVerificationToken } from '../../identity/models/emailVerificationToken.js';
import type { PasswordResetRepository } from '../../identity/repositories/passwordResetRepository.js';
import type { PasswordResetToken } from '../../identity/models/passwordResetToken.js';

const hashToken = (token: string): string => createHash('sha256').update(token, 'utf8').digest('hex');

function mapEmail(row: Record<string, unknown>, token: string): EmailVerificationToken {
  return { id: String(row.id), userId: String(row.user_id), token, createdAt: new Date(String(row.created_at)), expiresAt: new Date(String(row.expires_at)), ...(row.used_at ? { usedAt: new Date(String(row.used_at)) } : {}) };
}

function mapReset(row: Record<string, unknown>, token: string): PasswordResetToken {
  return { id: String(row.id), userId: String(row.user_id), token, createdAt: new Date(String(row.created_at)), expiresAt: new Date(String(row.expires_at)), ...(row.used_at ? { usedAt: new Date(String(row.used_at)) } : {}) };
}

export class PostgresEmailVerificationRepository implements EmailVerificationRepository {
  constructor(private readonly pool: Pool) {}
  async findByToken(token: string): Promise<EmailVerificationToken | undefined> {
    const result = await this.pool.query('SELECT * FROM nexode_identity_email_verification_tokens WHERE token_hash = $1 LIMIT 1', [hashToken(token)]);
    const row = result.rows[0] as Record<string, unknown> | undefined;
    return row ? mapEmail(row, token) : undefined;
  }
  async findByUserId(userId: string): Promise<EmailVerificationToken | undefined> {
    const result = await this.pool.query('SELECT * FROM nexode_identity_email_verification_tokens WHERE user_id = $1 ORDER BY created_at DESC LIMIT 1', [userId]);
    const row = result.rows[0] as Record<string, unknown> | undefined;
    return row ? mapEmail(row, '') : undefined;
  }
  async save(token: EmailVerificationToken): Promise<void> {
    await this.pool.query(`INSERT INTO nexode_identity_email_verification_tokens (id,user_id,token_hash,created_at,expires_at,used_at) VALUES ($1,$2,$3,$4,$5,$6)`, [token.id, token.userId, hashToken(token.token), token.createdAt, token.expiresAt, token.usedAt ?? null]);
  }
  async update(token: EmailVerificationToken): Promise<void> {
    await this.pool.query('UPDATE nexode_identity_email_verification_tokens SET used_at = $2 WHERE token_hash = $1', [hashToken(token.token), token.usedAt ?? null]);
  }
  async consume(token: string): Promise<EmailVerificationToken | undefined> {
    const result = await this.pool.query(`UPDATE nexode_identity_email_verification_tokens SET used_at = now() WHERE token_hash = $1 AND used_at IS NULL AND expires_at > now() RETURNING *`, [hashToken(token)]);
    const row = result.rows[0] as Record<string, unknown> | undefined;
    return row ? mapEmail(row, token) : undefined;
  }
  async deleteByUserId(userId: string): Promise<void> {
    await this.pool.query('DELETE FROM nexode_identity_email_verification_tokens WHERE user_id = $1', [userId]);
  }
}

export class PostgresPasswordResetRepository implements PasswordResetRepository {
  constructor(private readonly pool: Pool) {}
  async create(reset: PasswordResetToken): Promise<void> { await this.save(reset); }
  async findByToken(token: string): Promise<PasswordResetToken | undefined> {
    const result = await this.pool.query('SELECT * FROM nexode_identity_password_reset_tokens WHERE token_hash = $1 LIMIT 1', [hashToken(token)]);
    const row = result.rows[0] as Record<string, unknown> | undefined;
    return row ? mapReset(row, token) : undefined;
  }
  async deleteByUserId(userId: string): Promise<void> { await this.pool.query('DELETE FROM nexode_identity_password_reset_tokens WHERE user_id = $1', [userId]); }
  async save(reset: PasswordResetToken): Promise<void> {
    await this.pool.query(`INSERT INTO nexode_identity_password_reset_tokens (id,user_id,token_hash,created_at,expires_at,used_at) VALUES ($1,$2,$3,$4,$5,$6)`, [reset.id, reset.userId, hashToken(reset.token), reset.createdAt, reset.expiresAt, reset.usedAt ?? null]);
  }
  async consume(token: string): Promise<PasswordResetToken | undefined> {
    const result = await this.pool.query(`UPDATE nexode_identity_password_reset_tokens SET used_at = now() WHERE token_hash = $1 AND used_at IS NULL AND expires_at > now() RETURNING *`, [hashToken(token)]);
    const row = result.rows[0] as Record<string, unknown> | undefined;
    return row ? mapReset(row, token) : undefined;
  }
}
