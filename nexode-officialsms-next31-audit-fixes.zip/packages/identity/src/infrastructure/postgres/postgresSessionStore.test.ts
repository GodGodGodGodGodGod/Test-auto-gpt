import { describe, expect, it, vi } from 'vitest';
import { PostgresSessionStore } from './postgresSessionStore.js';

const session = {
  id: 'ses_1', userId: 'usr_1', createdAt: new Date('2026-01-01T00:00:00Z'),
  expiresAt: new Date('2026-01-08T00:00:00Z'), lastActivityAt: new Date('2026-01-01T00:00:00Z'),
  ipAddress: '127.0.0.1', userAgent: 'test', deviceName: 'iPhone',
};

describe('PostgresSessionStore', () => {
  it('persists and reads sessions', async () => {
    const query = vi.fn()
      .mockResolvedValueOnce({ rows: [] })
      .mockResolvedValueOnce({ rows: [{
        id: session.id, user_id: session.userId, created_at: session.createdAt,
        expires_at: session.expiresAt, last_activity_at: session.lastActivityAt,
        ip_address: session.ipAddress, user_agent: session.userAgent, device_name: session.deviceName,
      }] });
    const store = new PostgresSessionStore({ query });
    await store.create(session);
    const found = await store.find(session.id);
    expect(found).toEqual(session);
  });
});
