import type { Pool, PoolClient } from 'pg';
import type { IdentitySession } from '../../identity/models/identitySession.js';
import type { SessionStore } from '../../session/sessionStore.js';

type QueryExecutor = Pick<Pool, 'query'> | Pick<PoolClient, 'query'>;

export class PostgresSessionStore implements SessionStore {
  constructor(private readonly db: QueryExecutor) {}

  async create(session: IdentitySession): Promise<void> {
    await this.db.query(
      `INSERT INTO nexode_identity_sessions
        (id, user_id, created_at, expires_at, last_activity_at, ip_address, user_agent, device_name)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8)`,
      [session.id, session.userId, session.createdAt, session.expiresAt, session.lastActivityAt,
       session.ipAddress ?? null, session.userAgent ?? null, session.deviceName ?? null],
    );
  }

  async find(id: string): Promise<IdentitySession | undefined> {
    const result = await this.db.query<SessionRow>(
      `SELECT id, user_id, created_at, expires_at, last_activity_at,
              ip_address, user_agent, device_name
         FROM nexode_identity_sessions
        WHERE id = $1`,
      [id],
    );
    return result.rows[0] ? toSession(result.rows[0]) : undefined;
  }

  async findByUser(userId: string): Promise<readonly IdentitySession[]> {
    const result = await this.db.query<SessionRow>(
      `SELECT id, user_id, created_at, expires_at, last_activity_at,
              ip_address, user_agent, device_name
         FROM nexode_identity_sessions
        WHERE user_id = $1
        ORDER BY created_at DESC`,
      [userId],
    );
    return result.rows.map(toSession);
  }

  async update(session: IdentitySession): Promise<void> {
    await this.db.query(
      `UPDATE nexode_identity_sessions
          SET last_activity_at = $2,
              expires_at = $3,
              ip_address = $4,
              user_agent = $5,
              device_name = $6
        WHERE id = $1`,
      [session.id, session.lastActivityAt, session.expiresAt,
       session.ipAddress ?? null, session.userAgent ?? null, session.deviceName ?? null],
    );
  }

  async delete(id: string): Promise<void> {
    await this.db.query('DELETE FROM nexode_identity_sessions WHERE id = $1', [id]);
  }

  async deleteByUser(userId: string): Promise<void> {
    await this.db.query('DELETE FROM nexode_identity_sessions WHERE user_id = $1', [userId]);
  }
}

interface SessionRow {
  id: string;
  user_id: string;
  created_at: Date;
  expires_at: Date;
  last_activity_at: Date;
  ip_address: string | null;
  user_agent: string | null;
  device_name: string | null;
}

function toSession(row: SessionRow): IdentitySession {
  return {
    id: row.id,
    userId: row.user_id,
    createdAt: new Date(row.created_at),
    expiresAt: new Date(row.expires_at),
    lastActivityAt: new Date(row.last_activity_at),
    ipAddress: row.ip_address ?? undefined,
    userAgent: row.user_agent ?? undefined,
    deviceName: row.device_name ?? undefined,
  };
}
