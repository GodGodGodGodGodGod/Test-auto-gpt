import type { Middleware } from '../middleware/index.js';
import type { MiddlewarePipeline } from '../middleware/index.js';
import type { RouteHandler } from '../types/index.js';
import type { RouteOptions } from './routeGroup.js';

import { RouteGroup } from './routeGroup.js';
import type { RouteRegistry } from './routeRegistry.js';

export class GroupContext extends RouteGroup {
  constructor(
    prefix: string,
    routes: RouteRegistry,
    private readonly pipeline: MiddlewarePipeline,
  ) {
    super(prefix, routes);
  }

  use(
    middleware: Middleware,
  ): void {
    this.pipeline.use(middleware);
  }

  override get(path: string, handler: RouteHandler, options: RouteOptions = {}): void {
    super.get(path, handler, options);
  }

  override post(path: string, handler: RouteHandler, options: RouteOptions = {}): void {
    super.post(path, handler, options);
  }

  override put(path: string, handler: RouteHandler, options: RouteOptions = {}): void {
    super.put(path, handler, options);
  }

  override patch(path: string, handler: RouteHandler, options: RouteOptions = {}): void {
    super.patch(path, handler, options);
  }

  override delete(path: string, handler: RouteHandler, options: RouteOptions = {}): void {
    super.delete(path, handler, options);
  }
}