import type { GatewayRequest } from '../../types/index.js';
import type { AuthStrategy } from '../authStrategy.js';
import type { AuthenticationResult, AuthUser } from '../types.js';

export interface AccessTokenClaims {
  readonly subject: string;
  readonly issuedAt: number;
  readonly expiresAt: number;
  readonly sessionId?: string;
}

export interface AccessTokenVerifier {
  verify(token: string): Promise<AccessTokenClaims>;
}

export interface AuthUserResolver {
  resolve(userId: string): Promise<AuthUser | null>;
}

export class BearerJwtStrategy implements AuthStrategy {
  constructor(
    private readonly verifier: AccessTokenVerifier,
    private readonly users: AuthUserResolver,
  ) {}

  async authenticate(request: GatewayRequest): Promise<AuthenticationResult> {
    const header = request.headers.authorization ?? request.headers.Authorization;
    if (!header) return { authenticated: false };

    const match = /^Bearer\\s+([^\\s]+)$/i.exec(header.trim());
    if (!match?.[1]) return { authenticated: false };

    try {
      const claims = await this.verifier.verify(match[1]);
      const user = await this.users.resolve(claims.subject);
      if (!user) return { authenticated: false };
      return { authenticated: true, user, sessionId: claims.sessionId ?? request.sessionId };
    } catch {
      return { authenticated: false };
    }
  }
}
