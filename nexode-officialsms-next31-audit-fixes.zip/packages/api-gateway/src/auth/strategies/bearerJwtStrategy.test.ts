import { describe, expect, it } from 'vitest';
import { BearerJwtStrategy } from './bearerJwtStrategy.js';

describe('BearerJwtStrategy', () => {
  const user = { id: 'u1', roles: ['customer'], permissions: ['sms:purchase'] } as const;

  it('rejects missing or malformed authorization headers', async () => {
    const strategy = new BearerJwtStrategy(
      { verify: async () => ({ subject: 'u1', issuedAt: 1, expiresAt: 2 }) },
      { resolve: async () => user },
    );
    expect((await strategy.authenticate({ headers: {}, method: 'POST', path: '/', params: {}, query: {} })).authenticated).toBe(false);
    expect((await strategy.authenticate({ headers: { authorization: 'Basic abc' }, method: 'POST', path: '/', params: {}, query: {} })).authenticated).toBe(false);
  });

  it('resolves a bearer token to the current user', async () => {
    const strategy = new BearerJwtStrategy(
      { verify: async (token) => { expect(token).toBe('token'); return { subject: 'u1', issuedAt: 1, expiresAt: 2 }; } },
      { resolve: async (id) => id === 'u1' ? user : null },
    );
    const result = await strategy.authenticate({ headers: { authorization: 'Bearer token' }, method: 'POST', path: '/', params: {}, query: {} });
    expect(result).toEqual({ authenticated: true, user, sessionId: undefined });
  });

  it('fails closed when token verification or user resolution fails', async () => {
    const strategy = new BearerJwtStrategy(
      { verify: async () => { throw new Error('bad token'); } },
      { resolve: async () => user },
    );
    expect((await strategy.authenticate({ headers: { authorization: 'Bearer token' }, method: 'GET', path: '/', params: {}, query: {} })).authenticated).toBe(false);
  });
});
