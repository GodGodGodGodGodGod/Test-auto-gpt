import type { IncomingMessage } from 'node:http';

export async function readRequestBody(
  request: IncomingMessage,
  maxBodySize = 1024 * 1024,
): Promise<unknown> {
  return new Promise((resolve, reject) => {
    const chunks: Buffer[] = [];
    let totalBytes = 0;

    request.on('data', (chunk: Buffer) => {
      totalBytes += chunk.length;
      if (totalBytes > maxBodySize) {
        request.destroy();
        reject(new Error('Request body too large'));
        return;
      }
      chunks.push(chunk);
    });

    request.on('end', () => {
      if (chunks.length === 0) {
        resolve(undefined);
        return;
      }

      try {
        const body = JSON.parse(
          Buffer.concat(chunks).toString(),
        );

        resolve(body);
      } catch (error) {
        reject(error);
      }
    });

    request.on('error', reject);
  });
}