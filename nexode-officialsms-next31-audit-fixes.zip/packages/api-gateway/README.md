# @nexode/api-gateway

HTTP routing, middleware, validation, authentication integration, rate limiting, security headers, health, and observability primitives for NeXoDe services.

Product business logic does not belong in this package.
