import { z } from 'zod';
import type { ProviderTelemetry } from '../../modules/observability/providerTelemetry.js';
import { SmsProviderAmbiguousError, type SmsActivation, type SmsMessage, type SmsProvider } from '../ports/sms-provider.js';

const profileSchema = z.object({
  id: z.number().int().optional(),
  email: z.string().optional(),
  balance: z.number().finite().optional(),
  rating: z.number().finite().optional(),
  default_country: z.string().optional(),
  default_operator: z.string().optional(),
});

const smsSchema = z.object({
  id: z.number().int().optional(),
  created_at: z.string().optional(),
  date: z.string().optional(),
  sender: z.string().optional(),
  text: z.string().optional(),
  code: z.string().optional(),
});

const activationSchema = z.object({
  id: z.union([z.number().int(), z.string()]),
  phone: z.string(),
  operator: z.string().optional(),
  product: z.string(),
  price: z.number().finite(),
  status: z.string(),
  sms: z.array(smsSchema).nullable().optional(),
  created_at: z.string().optional(),
  expires: z.string().optional(),
});

const orderSchema = activationSchema;

export interface FiveSimProfile {
  readonly id?: number;
  readonly email?: string;
  readonly balance?: number;
  readonly rating?: number;
  readonly defaultCountry?: string;
  readonly defaultOperator?: string;
}

export interface FiveSimOrder {
  readonly id: number;
  readonly phone: string;
  readonly product: string;
  readonly price: number;
  readonly status: string;
  readonly sms: readonly unknown[];
  readonly createdAt?: string;
  readonly expiresAt?: string;
}

export interface FiveSimClientOptions {
  readonly baseUrl: string;
  readonly apiKey: string;
  readonly timeoutMs: number;
  readonly fetchImpl?: typeof fetch;
  readonly telemetry?: ProviderTelemetry;
}

export class FiveSimApiError extends Error {
  readonly status: number;
  readonly providerMessage?: string;

  constructor(message: string, status: number, providerMessage?: string) {
    super(message);
    this.name = 'FiveSimApiError';
    this.status = status;
    this.providerMessage = providerMessage;
  }
}

export class FiveSimProvider implements SmsProvider {
  readonly name = '5sim';
  private readonly client: FiveSimClient;

  constructor(options: FiveSimClientOptions) {
    this.client = new FiveSimClient(options);
  }

  async checkHealth(): Promise<void> {
    await this.client.getProfile();
  }

  purchase(input: {
    readonly country: string;
    readonly operator: string;
    readonly service: string;
    readonly maxPrice?: number;
  }): Promise<SmsActivation> {
    return this.client.buyActivation(input);
  }

  check(orderId: string): Promise<SmsActivation> {
    return this.client.checkActivation(orderId);
  }

  finish(orderId: string): Promise<SmsActivation> {
    return this.client.finishActivation(orderId);
  }

  cancel(orderId: string): Promise<SmsActivation> {
    return this.client.cancelActivation(orderId);
  }

  ban(orderId: string): Promise<SmsActivation> {
    return this.client.banActivation(orderId);
  }
}

/**
 * Authenticated 5SIM transport. Provider-specific HTTP details stay here;
 * OfficialSMS application/domain code depends on the SmsProvider port.
 */
export class FiveSimClient {
  private readonly fetchImpl: typeof fetch;

  constructor(private readonly options: FiveSimClientOptions) {
    this.fetchImpl = options.fetchImpl ?? fetch;
  }

  async getProfile(): Promise<FiveSimProfile> {
    const payload = await this.request('/user/profile');
    const parsed = profileSchema.parse(payload);

    return {
      id: parsed.id,
      email: parsed.email,
      balance: parsed.balance,
      rating: parsed.rating,
      defaultCountry: parsed.default_country,
      defaultOperator: parsed.default_operator,
    };
  }

  async getOrders(input: {
    readonly category?: string;
    readonly limit?: number;
    readonly offset?: number;
    readonly order?: string;
    readonly reverse?: boolean;
  } = {}): Promise<readonly FiveSimOrder[]> {
    const query = new URLSearchParams();
    if (input.category) query.set('category', input.category);
    if (input.limit !== undefined) query.set('limit', String(input.limit));
    if (input.offset !== undefined) query.set('offset', String(input.offset));
    if (input.order) query.set('order', input.order);
    if (input.reverse !== undefined) query.set('reverse', String(input.reverse));

    const suffix = query.size > 0 ? `?${query.toString()}` : '';
    const payload = await this.request(`/user/orders${suffix}`);

    const data = Array.isArray(payload)
      ? payload
      : (payload && typeof payload === 'object' && Array.isArray((payload as { Data?: unknown }).Data)
        ? (payload as { Data: unknown[] }).Data
        : null);

    if (!data) throw new Error('5SIM returned an invalid orders response');

    return data.map((item) => {
      const parsed = orderSchema.parse(item);
      return {
        id: Number(parsed.id),
        phone: parsed.phone,
        product: parsed.product,
        price: parsed.price,
      currency: 'USD',
        status: parsed.status,
        sms: parsed.sms ?? [],
        createdAt: parsed.created_at,
        expiresAt: parsed.expires,
      };
    });
  }

  async buyActivation(input: {
    readonly country: string;
    readonly operator: string;
    readonly service: string;
    readonly maxPrice?: number;
  }): Promise<SmsActivation> {
    const query = new URLSearchParams();
    if (input.maxPrice !== undefined) query.set('maxPrice', String(input.maxPrice));
    const suffix = query.size > 0 ? `?${query.toString()}` : '';
    const path = `/user/buy/activation/${encodeURIComponent(input.country)}/${encodeURIComponent(input.operator)}/${encodeURIComponent(input.service)}${suffix}`;
    return this.toActivation(await this.request(path));
  }

  async checkActivation(orderId: string): Promise<SmsActivation> {
    return this.toActivation(await this.request(`/user/check/${encodeURIComponent(orderId)}`));
  }

  async finishActivation(orderId: string): Promise<SmsActivation> {
    return this.toActivation(await this.request(`/user/finish/${encodeURIComponent(orderId)}`));
  }

  async cancelActivation(orderId: string): Promise<SmsActivation> {
    return this.toActivation(await this.request(`/user/cancel/${encodeURIComponent(orderId)}`));
  }

  async banActivation(orderId: string): Promise<SmsActivation> {
    return this.toActivation(await this.request(`/user/ban/${encodeURIComponent(orderId)}`));
  }

  private toActivation(payload: unknown): SmsActivation {
    const parsed = activationSchema.parse(payload);
    return {
      id: String(parsed.id),
      phone: parsed.phone,
      operator: parsed.operator,
      product: parsed.product,
      price: parsed.price,
      currency: 'USD',
      status: parsed.status,
      createdAt: parsed.created_at,
      expiresAt: parsed.expires,
      sms: parsed.sms?.map(toSmsMessage) ?? [],
    };
  }

  private async request(path: string): Promise<unknown> {
    const operation = path.split('?')[0] ?? path;
    const finishTelemetry = this.options.telemetry?.start(operation, '5sim', { path });
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), this.options.timeoutMs);

    try {
      let response: Response;
      try {
        response = await this.fetchImpl(`${this.options.baseUrl}${path}`, {
          method: 'GET',
          headers: {
            Accept: 'application/json',
            Authorization: `Bearer ${this.options.apiKey}`,
          },
          signal: controller.signal,
        });
      } catch (error) {
        const ambiguous = new SmsProviderAmbiguousError(
          '5SIM request outcome is unknown; the provider may have processed the request',
          { cause: error },
        );
        finishTelemetry?.('ambiguous', ambiguous);
        throw ambiguous;
      }

      const contentType = response.headers.get('content-type') ?? '';
      const rawBody = await response.text();
      let body: unknown = rawBody;

      if (contentType.includes('application/json') && rawBody.length > 0) {
        try {
          body = JSON.parse(rawBody) as unknown;
        } catch {
          body = rawBody;
        }
      }

      if (!response.ok) {
        const providerMessage = typeof body === 'string' ? body : undefined;
        throw new FiveSimApiError(
          `5SIM request failed with HTTP ${response.status}`,
          response.status,
          providerMessage,
        );
      }

      finishTelemetry?.('success');
      return body;
    } catch (error) {
      if (!(error instanceof SmsProviderAmbiguousError)) finishTelemetry?.('error', error);
      throw error;
    } finally {
      clearTimeout(timeout);
    }
  }

}

function toSmsMessage(message: z.infer<typeof smsSchema>): SmsMessage {
  return {
    id: message.id,
    createdAt: message.created_at,
    date: message.date,
    sender: message.sender,
    text: message.text,
    code: message.code,
  };
}
