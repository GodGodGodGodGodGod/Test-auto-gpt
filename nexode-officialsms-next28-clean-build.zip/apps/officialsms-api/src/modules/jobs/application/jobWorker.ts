import type { Job, JobHandler, JobQueue } from '@nexode/jobs';

export class JobWorker {
  private running = false;

  constructor(
    private readonly queue: JobQueue,
    private readonly handlers: ReadonlyMap<string, JobHandler>,
    private readonly workerId: string,
    private readonly leaseMs = 30_000,
  ) {}

  async runOnce(): Promise<boolean> {
    const job = await this.queue.claim(this.workerId, this.leaseMs);
    if (!job) return false;
    try {
      const handler = this.handlers.get(job.type);
      if (!handler) throw new Error(`No handler registered for job type: ${job.type}`);
      await handler.handle(job.payload, job);
      await this.queue.complete(job.id, this.workerId);
    } catch (error) {
      const message = error instanceof Error ? error.message : String(error);
      const retryDelay = Math.min(60_000, 1_000 * (2 ** Math.max(0, job.attempts - 1)));
      const retryAt = job.attempts < job.maxAttempts ? new Date(Date.now() + retryDelay).toISOString() : undefined;
      await this.queue.fail(job.id, this.workerId, message, retryAt);
    }
    return true;
  }

  async start(pollIntervalMs = 500): Promise<void> {
    if (this.running) return;
    this.running = true;
    while (this.running) {
      const worked = await this.runOnce();
      if (!worked) await new Promise((resolve) => setTimeout(resolve, pollIntervalMs));
    }
  }

  stop(): void { this.running = false; }
}
