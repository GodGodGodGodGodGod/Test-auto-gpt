import type { JobQueue } from '@nexode/jobs';
import { JobWorker } from './jobWorker.js';
import { JOB_TYPES, OfficialSmsJobDispatcher } from './jobDispatcher.js';
import { SmsPollingJobHandler } from './smsPollingJobHandler.js';
import { PurchaseReconciliationJobHandler } from './purchaseReconciliationJobHandler.js';
import { CatalogSyncJobHandler } from './catalogSyncJobHandler.js';
import { ProviderHealthJobHandler } from './providerHealthJobHandler.js';
import type { SmsPollingService } from '../../sms/application/smsPollingService.js';
import type { ReconcilePurchaseService } from '../../activation/application/reconcilePurchaseService.js';
import type { OrderRepository } from '../../orders/application/orderRepository.js';
import type { SyncCatalogService } from '../../catalog/application/syncCatalogService.js';
import type { CheckProviderHealthService } from '../../provider-health/application/checkProviderHealthService.js';

export interface OfficialSmsWorkerOptions {
  readonly workerId: string;
  readonly leaseMs?: number;
  readonly pollIntervalMs?: number;
  readonly discoveryIntervalMs?: number;
  readonly discoveryBatchSize?: number;
  readonly catalogSyncIntervalMs?: number;
  readonly providerHealthIntervalMs?: number;
}

export class OfficialSmsWorker {
  private readonly worker: JobWorker;
  private readonly dispatcher: OfficialSmsJobDispatcher;
  private discoveryTimer?: ReturnType<typeof setInterval>;
  private catalogTimer?: ReturnType<typeof setInterval>;
  private healthTimer?: ReturnType<typeof setInterval>;
  private stopping = false;

  constructor(
    queue: JobQueue,
    orders: OrderRepository,
    polling: SmsPollingService,
    reconciliation: ReconcilePurchaseService,
    catalogSync: SyncCatalogService,
    providerHealth: CheckProviderHealthService,
    private readonly options: OfficialSmsWorkerOptions,
  ) {
    this.dispatcher = new OfficialSmsJobDispatcher(queue);
    this.worker = new JobWorker(
      queue,
      new Map([
        [JOB_TYPES.SMS_POLL, new SmsPollingJobHandler(polling)],
        [JOB_TYPES.PURCHASE_RECONCILE, new PurchaseReconciliationJobHandler(reconciliation)],
        [JOB_TYPES.CATALOG_SYNC, new CatalogSyncJobHandler(catalogSync)],
        [JOB_TYPES.PROVIDER_HEALTH, new ProviderHealthJobHandler(providerHealth)],
      ]),
      options.workerId,
      options.leaseMs ?? 30_000,
    );
    this.orders = orders;
  }

  private readonly orders: OrderRepository;

  async start(): Promise<void> {
    if (this.stopping) throw new Error('Worker has already been stopped');
    const discoveryInterval = this.options.discoveryIntervalMs ?? 5_000;
    const batchSize = this.options.discoveryBatchSize ?? 100;

    await this.enqueuePollableOrders(batchSize);
    await this.dispatcher.enqueueCatalogSync();
    await this.dispatcher.enqueueProviderHealth();
    this.discoveryTimer = setInterval(() => {
      void this.enqueuePollableOrders(batchSize).catch((error: unknown) => {
        console.error('OfficialSMS job discovery failed:', error);
      });
    }, discoveryInterval);

    const catalogInterval = this.options.catalogSyncIntervalMs ?? 60_000;
    this.catalogTimer = setInterval(() => {
      void this.dispatcher.enqueueCatalogSync().catch((error: unknown) => {
        console.error('OfficialSMS catalog sync dispatch failed:', error);
      });
    }, catalogInterval);

    const healthInterval = this.options.providerHealthIntervalMs ?? 30_000;
    this.healthTimer = setInterval(() => {
      void this.dispatcher.enqueueProviderHealth().catch((error: unknown) => {
        console.error('OfficialSMS provider health dispatch failed:', error);
      });
    }, healthInterval);

    await this.worker.start(this.options.pollIntervalMs ?? 250);
  }

  stop(): void {
    this.stopping = true;
    if (this.discoveryTimer) clearInterval(this.discoveryTimer);
    if (this.catalogTimer) clearInterval(this.catalogTimer);
    if (this.healthTimer) clearInterval(this.healthTimer);
    this.discoveryTimer = undefined;
    this.catalogTimer = undefined;
    this.healthTimer = undefined;
    this.worker.stop();
  }

  private async enqueuePollableOrders(limit: number): Promise<void> {
    const orderIds = await this.orders.listPollableIds(limit);
    await Promise.all(orderIds.map((orderId) => this.dispatcher.enqueueSmsPoll(orderId)));
  }
}
