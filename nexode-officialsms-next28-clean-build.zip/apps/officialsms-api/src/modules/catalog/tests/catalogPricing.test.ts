import { describe, expect, it } from 'vitest';
import { GetCatalog } from '../application/getCatalog.js';
import type { SmsCatalogProvider } from '../application/getCatalog.js';
import type { SmsCatalog } from '../domain/catalog.js';
import { PriceService } from '../../pricing/application/priceService.js';
import { StaticExchangeRateProvider, StaticMarkupRuleProvider } from '../../pricing/infrastructure/inMemoryPricingProviders.js';

describe('catalog pricing integration', () => {
  it('keeps provider cost separate and exposes the customer price', async () => {
    const provider: SmsCatalogProvider = {
      async getCatalog(): Promise<SmsCatalog> {
        return {
          provider: '5sim',
          fetchedAt: new Date('2026-01-01T00:00:00.000Z'),
          customerCurrency: 'USD',
          products: [{
            country: 'england', operator: 'vodafone', service: 'facebook',
            providerPrice: '4', providerCurrency: 'USD', price: '4', currency: 'USD', available: 10,
            pricingRuleVersion: 'unpriced', exchangeRate: '1', rateSource: 'provider', rateCapturedAt: '2026-01-01T00:00:00.000Z',
          }],
        };
      },
    };
    const pricing = new PriceService(
      new StaticExchangeRateProvider(new Map()),
      new StaticMarkupRuleProvider(new Map(), { version: 'v1', percentageBps: 1500n, minimumAmount: '0' }),
    );

    const catalog = await new GetCatalog(provider, pricing).execute({ customerCurrency: 'USD' });
    expect(catalog.products[0]).toMatchObject({ providerPrice: '4', price: '4.6', currency: 'USD', pricingRuleVersion: 'v1' });
  });
});
