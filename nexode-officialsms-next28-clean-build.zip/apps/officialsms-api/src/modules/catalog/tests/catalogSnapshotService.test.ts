import { describe, expect, it } from 'vitest';
import { CatalogSnapshotService } from '../application/catalogSnapshotService.js';
import type { SmsCatalogProvider } from '../application/getCatalog.js';
import type { SmsCatalog } from '../domain/catalog.js';
import type { CatalogSnapshot, CatalogSnapshotRepository } from '../infrastructure/postgres/postgresCatalogSnapshotRepository.js';

function product() {
  return { country: 'england', operator: 'vodafone', service: 'facebook', providerPrice: '4', providerCurrency: 'USD', available: 12 };
}

class MemorySnapshotRepository implements CatalogSnapshotRepository {
  snapshots: CatalogSnapshot[] = [];
  async findLatest(input: { provider: '5sim'; country?: string; service?: string }) {
    return this.snapshots.find((s) => s.provider === input.provider && s.country === input.country && s.service === input.service) ?? null;
  }
  async save(snapshot: Omit<CatalogSnapshot, 'id'>) {
    const saved = { ...snapshot, id: String(this.snapshots.length + 1) };
    this.snapshots.unshift(saved);
    return saved;
  }
}

describe('CatalogSnapshotService', () => {
  it('uses a fresh snapshot without calling the provider', async () => {
    const repository = new MemorySnapshotRepository();
    const now = new Date();
    repository.snapshots.push({ id: '1', provider: '5sim', products: [product()], fetchedAt: now.toISOString(), expiresAt: new Date(Date.now() + 60_000).toISOString() });
    let calls = 0;
    const provider: SmsCatalogProvider = { async getCatalog(): Promise<SmsCatalog> { calls += 1; throw new Error('should not call'); } };

    const result = await new CatalogSnapshotService(repository, provider, 60_000).get({});
    expect(result.stale).toBe(false);
    expect(result.products[0]?.providerPrice).toBe('4');
    expect(calls).toBe(0);
  });

  it('refreshes an expired snapshot and persists the new availability', async () => {
    const repository = new MemorySnapshotRepository();
    repository.snapshots.push({ id: '1', provider: '5sim', products: [{ ...product(), available: 1 }], fetchedAt: new Date(Date.now() - 120_000).toISOString(), expiresAt: new Date(Date.now() - 60_000).toISOString() });
    const provider: SmsCatalogProvider = { async getCatalog(): Promise<SmsCatalog> {
      return { provider: '5sim', fetchedAt: new Date(), products: [{ ...product(), price: '4', currency: 'USD', available: 25 }] };
    } };

    const result = await new CatalogSnapshotService(repository, provider, 60_000).get({});
    expect(result.stale).toBe(false);
    expect(result.products[0]?.available).toBe(25);
    expect(repository.snapshots[0]?.products[0]?.available).toBe(25);
  });

  it('serves stale data when the provider is unavailable rather than fabricating availability', async () => {
    const repository = new MemorySnapshotRepository();
    repository.snapshots.push({ id: '1', provider: '5sim', products: [product()], fetchedAt: new Date(Date.now() - 120_000).toISOString(), expiresAt: new Date(Date.now() - 60_000).toISOString() });
    const provider: SmsCatalogProvider = { async getCatalog(): Promise<SmsCatalog> { throw new Error('provider unavailable'); } };

    const result = await new CatalogSnapshotService(repository, provider, 60_000).get({});
    expect(result.stale).toBe(true);
    expect(result.products[0]?.available).toBe(12);
  });

  it('does not hide a provider failure when no snapshot exists', async () => {
    const repository = new MemorySnapshotRepository();
    const provider: SmsCatalogProvider = { async getCatalog(): Promise<SmsCatalog> { throw new Error('provider unavailable'); } };
    await expect(new CatalogSnapshotService(repository, provider, 60_000).get({})).rejects.toThrow('provider unavailable');
  });
});
