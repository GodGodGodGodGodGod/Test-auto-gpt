import type { ProviderSmsProduct, SmsCatalog } from '../domain/catalog.js';
import type { SmsCatalogProvider } from '../application/getCatalog.js';

interface FiveSimPriceEntry {
  readonly cost: number;
  readonly count: number;
  readonly rate: number;
}

type FiveSimPrices = Record<
  string,
  Record<string, Record<string, FiveSimPriceEntry>>
>;

export class FiveSimCatalogProvider implements SmsCatalogProvider {
  constructor(
    private readonly baseUrl: string,
    private readonly timeoutMs: number,
    private readonly currency: string,
    private readonly fetchImpl: typeof fetch = fetch,
  ) {}

  async getCatalog(input: {
    readonly country?: string;
    readonly service?: string;
  }): Promise<SmsCatalog> {
    const url = new URL(`${this.baseUrl}/guest/prices`);
    if (input.country) url.searchParams.set('country', input.country);
    if (input.service) url.searchParams.set('product', input.service);

    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), this.timeoutMs);

    try {
      const response = await this.fetchImpl(url, {
        method: 'GET',
        headers: { Accept: 'application/json' },
        signal: controller.signal,
      });

      if (!response.ok) {
        throw new Error(`5SIM catalog request failed with HTTP ${response.status}`);
      }

      const payload: unknown = await response.json();
      return {
        provider: '5sim',
        fetchedAt: new Date(),
        products: normalizePrices(payload, this.currency).map((product) => ({
          country: product.country, operator: product.operator, service: product.service,
          price: product.providerPrice, available: product.available, currency: product.providerCurrency,
        })),
      };
    } finally {
      clearTimeout(timeout);
    }
  }
}

function normalizePrices(payload: unknown, currency: string): readonly ProviderSmsProduct[] {
  if (!isPriceMap(payload)) {
    throw new Error('5SIM returned an invalid price catalog');
  }

  const products: ProviderSmsProduct[] = [];

  for (const [country, services] of Object.entries(payload)) {
    for (const [service, operators] of Object.entries(services)) {
      for (const [operator, entry] of Object.entries(operators)) {
        if (!Number.isFinite(entry.cost) || entry.cost < 0 || !Number.isInteger(entry.count) || entry.count < 0) {
          continue;
        }

        products.push({
          country, operator, service, providerPrice: String(entry.cost), available: entry.count, providerCurrency: currency,
        });
      }
    }
  }

  return products;
}

function isPriceMap(value: unknown): value is FiveSimPrices {
  if (typeof value !== 'object' || value === null || Array.isArray(value)) return false;

  for (const services of Object.values(value)) {
    if (typeof services !== 'object' || services === null || Array.isArray(services)) return false;
    for (const operators of Object.values(services)) {
      if (typeof operators !== 'object' || operators === null || Array.isArray(operators)) return false;
      for (const entry of Object.values(operators)) {
        if (
          typeof entry !== 'object' ||
          entry === null ||
          Array.isArray(entry) ||
          typeof (entry as Record<string, unknown>).cost !== 'number' ||
          typeof (entry as Record<string, unknown>).count !== 'number'
        ) {
          return false;
        }
      }
    }
  }

  return true;
}
