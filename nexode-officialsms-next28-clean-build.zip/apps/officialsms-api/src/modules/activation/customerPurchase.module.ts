import type { AuthStrategy, RouteDefinition } from '@nexode/api-gateway';
import type { OfficialSmsConfig } from '../../config/config.js';
import { createPostgresPool } from '../money/infrastructure/postgres/createPostgresPool.js';
import { PostgresMoneyRepository } from '../money/infrastructure/postgres/postgresMoneyRepository.js';
import { WalletService } from '../money/application/walletService.js';
import { createPostgresOrderModule } from '../orders/orders.module.js';
import { FiveSimProvider } from '../../providers/five-sim/fiveSimClient.js';
import { PurchaseActivationService } from './application/purchaseActivationService.js';
import { ProviderAvailabilityService } from '../provider-health/application/providerAvailabilityService.js';
import { PostgresProviderHealthRepository } from '../provider-health/infrastructure/postgres/postgresProviderHealthRepository.js';
import { CustomerPurchaseController, purchaseSchema } from './presentation/customerPurchase.controller.js';
import { CatalogSnapshotService } from '../catalog/application/catalogSnapshotService.js';
import { FiveSimCatalogProvider } from '../catalog/infrastructure/fiveSimCatalogProvider.js';
import { PostgresCatalogSnapshotRepository } from '../catalog/infrastructure/postgres/postgresCatalogSnapshotRepository.js';
import { PriceService } from '../pricing/application/priceService.js';
import { FrankfurterExchangeRateProvider } from '../pricing/infrastructure/frankfurterExchangeRateProvider.js';
import { PostgresExchangeRateProvider, PostgresMarkupRuleProvider } from '../pricing/infrastructure/postgresPricingProviders.js';

export function createCustomerPurchaseRoute(config: OfficialSmsConfig, auth: AuthStrategy): RouteDefinition {
  const pool = createPostgresPool(config.databaseUrl);
  const moneyRepository = new PostgresMoneyRepository(pool);
  const money = new WalletService(moneyRepository);
  const orders = createPostgresOrderModule(pool);
  const provider = new FiveSimProvider({ baseUrl: config.fiveSim.baseUrl, apiKey: config.fiveSim.apiKey, timeoutMs: config.fiveSim.timeoutMs });
  const availability = new ProviderAvailabilityService(new PostgresProviderHealthRepository(pool), config.worker.providerHealthMaxAgeMs);
  const rates = new PostgresExchangeRateProvider(pool, new FrankfurterExchangeRateProvider({ baseUrl: config.pricing.exchangeRateBaseUrl, timeoutMs: config.fiveSim.timeoutMs, provider: config.pricing.exchangeRateProvider }), config.pricing.exchangeRateTtlMs);
  const pricing = new PriceService(rates, new PostgresMarkupRuleProvider(pool));
  const catalog = new CatalogSnapshotService(new PostgresCatalogSnapshotRepository(pool), new FiveSimCatalogProvider(config.fiveSim.baseUrl, config.fiveSim.timeoutMs, config.fiveSim.currency), config.pricing.catalogTtlMs);
  const purchase = new PurchaseActivationService(provider, orders.orderService, money, orders.purchaseAttemptRepository, availability);
  const controller = new CustomerPurchaseController(catalog, pricing, moneyRepository, orders.orderService, purchase);

  return {
    method: 'POST',
    path: '/purchases',
    handler: controller.create.bind(controller),
    auth,
    metadata: { authentication: true, summary: 'Purchase an SMS verification number', tags: ['purchases'], operationId: 'createSmsPurchase' },
    schema: { body: purchaseSchema },
    rateLimit: { maxRequests: 10, windowMs: 60_000, keyGenerator: (request) => `purchase:${request.user?.id ?? request.ipAddress ?? 'unknown'}` },
  };
}
