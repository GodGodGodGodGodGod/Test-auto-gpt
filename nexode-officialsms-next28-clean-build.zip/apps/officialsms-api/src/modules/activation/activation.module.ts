import type { RouteDefinition } from '@nexode/api-gateway';
import type { OfficialSmsConfig } from '../../config/config.js';
import { ActivationService } from './application/activationService.js';
import { FiveSimProvider } from '../../providers/five-sim/fiveSimClient.js';
import { ActivationController } from './presentation/activation.controller.js';

export function createActivationRoutes(config: OfficialSmsConfig): readonly RouteDefinition[] {
  const provider = new FiveSimProvider({
    baseUrl: config.fiveSim.baseUrl,
    apiKey: config.fiveSim.apiKey,
    timeoutMs: config.fiveSim.timeoutMs,
  });
  const controller = new ActivationController(new ActivationService(provider));

  return [
    { method: 'GET', path: '/activations/purchase', handler: controller.purchase.bind(controller) },
    { method: 'GET', path: '/activations/:id', handler: controller.check.bind(controller) },
    { method: 'GET', path: '/activations/:id/finish', handler: controller.finish.bind(controller) },
    { method: 'GET', path: '/activations/:id/cancel', handler: controller.cancel.bind(controller) },
    { method: 'GET', path: '/activations/:id/ban', handler: controller.ban.bind(controller) },
  ];
}

export { createCustomerPurchaseRoute } from './customerPurchase.module.js';
