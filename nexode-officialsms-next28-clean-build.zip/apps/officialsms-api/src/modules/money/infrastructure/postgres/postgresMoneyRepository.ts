import { Pool } from 'pg';
import type { LedgerTransaction } from '../../domain/ledger.js';
import type { Wallet, WalletReservation } from '../../domain/wallet.js';
import type { MoneyRepository } from '../../application/moneyRepository.js';

function toBigInt(value: string | number | bigint): bigint {
  return BigInt(value);
}

function mapWallet(row: any): Wallet {
  return {
    id: row.id,
    customerId: row.customer_id,
    currency: row.currency,
    createdAt: new Date(row.created_at).toISOString(),
  };
}

function mapReservation(row: any): WalletReservation {
  return {
    id: row.id,
    walletId: row.wallet_id,
    amount: { amountMinor: toBigInt(row.amount_minor), currency: row.currency },
    idempotencyKey: row.idempotency_key,
    status: row.status,
    createdAt: new Date(row.created_at).toISOString(),
    updatedAt: new Date(row.updated_at).toISOString(),
  };
}

export class PostgresMoneyRepository implements MoneyRepository {
  constructor(private readonly pool: Pool) {}

  async getWallet(walletId: string): Promise<Wallet | undefined> {
    const result = await this.pool.query('SELECT * FROM officialsms_wallets WHERE id = $1', [walletId]);
    return result.rows[0] ? mapWallet(result.rows[0]) : undefined;
  }

  async getWalletByCustomerAndCurrency(customerId: string, currency: string): Promise<Wallet | undefined> {
    const result = await this.pool.query(
      'SELECT * FROM officialsms_wallets WHERE customer_id = $1 AND currency = $2',
      [customerId, currency],
    );
    return result.rows[0] ? mapWallet(result.rows[0]) : undefined;
  }

  async saveWallet(wallet: Wallet): Promise<void> {
    await this.pool.query(
      `INSERT INTO officialsms_wallets (id, customer_id, currency, available_minor)
       VALUES ($1, $2, $3, 0)
       ON CONFLICT (id) DO NOTHING`,
      [wallet.id, wallet.customerId, wallet.currency],
    );
  }

  async getReservationById(walletId: string, reservationId: string): Promise<WalletReservation | undefined> {
    const result = await this.pool.query(
      `SELECT * FROM officialsms_wallet_reservations WHERE wallet_id = $1 AND id = $2`,
      [walletId, reservationId],
    );
    return result.rows[0] ? mapReservation(result.rows[0]) : undefined;
  }

  async getReservationByIdempotency(walletId: string, idempotencyKey: string): Promise<WalletReservation | undefined> {
    const result = await this.pool.query(
      `SELECT * FROM officialsms_wallet_reservations WHERE wallet_id = $1 AND idempotency_key = $2`,
      [walletId, idempotencyKey],
    );
    return result.rows[0] ? mapReservation(result.rows[0]) : undefined;
  }

  async saveReservation(reservation: WalletReservation): Promise<void> {
    const client = await this.pool.connect();
    try {
      await client.query('BEGIN');
      const wallet = await client.query(
        `SELECT id, currency, available_minor FROM officialsms_wallets WHERE id = $1 FOR UPDATE`,
        [reservation.walletId],
      );
      if (!wallet.rows[0]) throw new Error('Wallet not found');
      if (wallet.rows[0].currency !== reservation.amount.currency) throw new Error('Wallet currency mismatch');

      const existing = await client.query(
        `SELECT * FROM officialsms_wallet_reservations WHERE wallet_id = $1 AND idempotency_key = $2`,
        [reservation.walletId, reservation.idempotencyKey],
      );
      if (existing.rows[0]) {
        await client.query('COMMIT');
        return;
      }

      const available = toBigInt(wallet.rows[0].available_minor);
      if (available < reservation.amount.amountMinor) throw new Error('Insufficient available wallet funds');

      await client.query(
        `UPDATE officialsms_wallets
         SET available_minor = available_minor - $1,
             reserved_minor = reserved_minor + $1,
             updated_at = NOW()
         WHERE id = $2`,
        [reservation.amount.amountMinor.toString(), reservation.walletId],
      );

      await client.query(
        `INSERT INTO officialsms_wallet_reservations
         (id, wallet_id, amount_minor, currency, idempotency_key, status, created_at, updated_at)
         VALUES ($1, $2, $3, $4, $5, $6, $7, $7)`,
        [reservation.id, reservation.walletId, reservation.amount.amountMinor.toString(), reservation.amount.currency,
          reservation.idempotencyKey, reservation.status, reservation.createdAt],
      );
      await client.query('COMMIT');
    } catch (error) {
      await client.query('ROLLBACK');
      throw error;
    } finally {
      client.release();
    }
  }

  async updateReservation(reservation: WalletReservation): Promise<void> {
    const client = await this.pool.connect();
    try {
      await client.query('BEGIN');
      const current = await client.query(
        `SELECT * FROM officialsms_wallet_reservations WHERE id = $1 FOR UPDATE`,
        [reservation.id],
      );
      if (!current.rows[0]) throw new Error('Reservation not found');
      if (current.rows[0].status === reservation.status) { await client.query('COMMIT'); return; }
      if (current.rows[0].status !== 'ACTIVE') throw new Error(`Cannot update ${current.rows[0].status} reservation`);

      const walletId = current.rows[0].wallet_id;
      const amount = current.rows[0].amount_minor;
      await client.query(`SELECT id FROM officialsms_wallets WHERE id = $1 FOR UPDATE`, [walletId]);

      if (reservation.status === 'RELEASED') {
        await client.query(
          `UPDATE officialsms_wallets SET available_minor = available_minor + $1, reserved_minor = reserved_minor - $1, updated_at = NOW() WHERE id = $2`,
          [amount, walletId],
        );
      } else if (reservation.status === 'CAPTURED') {
        await client.query(
          `UPDATE officialsms_wallets SET reserved_minor = reserved_minor - $1, updated_at = NOW() WHERE id = $2`,
          [amount, walletId],
        );
      } else {
        throw new Error(`Unsupported reservation status: ${reservation.status}`);
      }

      await client.query(
        `UPDATE officialsms_wallet_reservations SET status = $1, updated_at = $2 WHERE id = $3`,
        [reservation.status, reservation.updatedAt, reservation.id],
      );
      await client.query('COMMIT');
    } catch (error) {
      await client.query('ROLLBACK');
      throw error;
    } finally {
      client.release();
    }
  }

  async appendLedgerTransaction(transaction: LedgerTransaction): Promise<void> {
    const client = await this.pool.connect();
    try {
      await client.query('BEGIN');
      const existing = await client.query(
        `SELECT id FROM officialsms_ledger_transactions WHERE idempotency_key = $1`,
        [transaction.idempotencyKey],
      );
      if (existing.rows[0]) {
        await client.query('COMMIT');
        return;
      }
      await client.query(
        `INSERT INTO officialsms_ledger_transactions (id, idempotency_key, description, created_at)
         VALUES ($1, $2, $3, $4)`,
        [transaction.id, transaction.idempotencyKey, transaction.description, transaction.createdAt],
      );
      for (const entry of transaction.entries) {
        await client.query(
          `INSERT INTO officialsms_ledger_entries
           (id, transaction_id, account_id, side, amount_minor, currency)
           VALUES ($1, $2, $3, $4, $5, $6)`,
          [entry.id, transaction.id, entry.accountId, entry.side, entry.money.amountMinor.toString(), entry.money.currency],
        );
      }
      await client.query('COMMIT');
    } catch (error) {
      await client.query('ROLLBACK');
      throw error;
    } finally {
      client.release();
    }
  }

  async hasLedgerTransaction(idempotencyKey: string): Promise<boolean> {
    const result = await this.pool.query(
      `SELECT 1 FROM officialsms_ledger_transactions WHERE idempotency_key = $1 LIMIT 1`,
      [idempotencyKey],
    );
    return result.rowCount === 1;
  }
  async captureReservationAtomically(input: { reservation: WalletReservation; revenueAccountId: string; now: Date }): Promise<void> {
    const client = await this.pool.connect();
    try {
      await client.query('BEGIN');
      const current = await client.query('SELECT * FROM officialsms_wallet_reservations WHERE id = $1 FOR UPDATE', [input.reservation.id]);
      const row = current.rows[0];
      if (!row) throw new Error('Reservation not found');
      if (row.status === 'CAPTURED') { await client.query('COMMIT'); return; }
      if (row.status !== 'ACTIVE') throw new Error(`Cannot capture ${row.status} reservation`);
      const amount = String(row.amount_minor);
      const currency = String(row.currency);
      const walletId = String(row.wallet_id);
      await client.query('SELECT id FROM officialsms_wallets WHERE id = $1 FOR UPDATE', [walletId]);
      const ledgerKey = `sms-purchase:${input.reservation.id}`;
      const existing = await client.query('SELECT id FROM officialsms_ledger_transactions WHERE idempotency_key = $1 FOR UPDATE', [ledgerKey]);
      if (existing.rows.length === 0) {
        const transactionId = `ltx_sms_${input.reservation.id}`;
        await client.query(`INSERT INTO officialsms_ledger_transactions (id,idempotency_key,description,created_at) VALUES ($1,$2,$3,$4)`, [transactionId, ledgerKey, `SMS purchase ${input.reservation.id}`, input.now.toISOString()]);
        await client.query(`INSERT INTO officialsms_ledger_entries (id,transaction_id,account_id,side,amount_minor,currency) VALUES ($1,$2,$3,'DEBIT',$4,$5),($6,$2,$7,'CREDIT',$4,$5)`, [`le_sms_${input.reservation.id}_wallet`, transactionId, `wallet:${walletId}`, amount, currency, `le_sms_${input.reservation.id}_revenue`, input.revenueAccountId]);
      }
      await client.query(`UPDATE officialsms_wallets SET reserved_minor = reserved_minor - $1, updated_at = $2 WHERE id = $3 AND reserved_minor >= $1`, [amount, input.now.toISOString(), walletId]);
      await client.query(`UPDATE officialsms_wallet_reservations SET status='CAPTURED', updated_at=$1 WHERE id=$2`, [input.now.toISOString(), input.reservation.id]);
      await client.query('COMMIT');
    } catch (error) { await client.query('ROLLBACK'); throw error; }
    finally { client.release(); }
  }

}
