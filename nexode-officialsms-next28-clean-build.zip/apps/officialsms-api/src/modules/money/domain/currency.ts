/** ISO-4217 minor-unit scale for currencies we explicitly support. */
const ZERO_DECIMAL = new Set(['BIF', 'CLP', 'DJF', 'GNF', 'ISK', 'JPY', 'KMF', 'KRW', 'PYG', 'RWF', 'UGX', 'VND', 'VUV', 'XAF', 'XOF', 'XPF']);
const THREE_DECIMAL = new Set(['BHD', 'IQD', 'JOD', 'KWD', 'LYD', 'OMR', 'TND']);

export function currencyScale(currency: string): number {
  const code = currency.toUpperCase();
  if (!/^[A-Z]{3}$/.test(code)) throw new Error(`Invalid currency: ${currency}`);
  if (ZERO_DECIMAL.has(code)) return 0;
  if (THREE_DECIMAL.has(code)) return 3;
  return 2;
}

/** Convert a decimal customer-facing amount to exact minor units. No floating-point rounding. */
export function decimalToMinorUnits(value: string | number, currency: string): bigint {
  const text = typeof value === 'number' ? String(value) : value.trim();
  if (!/^(?:0|[1-9]\d*)(?:\.\d+)?$/.test(text)) throw new Error(`Invalid monetary amount: ${text}`);
  const scale = currencyScale(currency);
  const [whole, fraction = ''] = text.split('.');
  if (fraction.length > scale) throw new Error(`Amount ${text} has more than ${scale} decimal places for ${currency}`);
  return BigInt(whole) * (10n ** BigInt(scale)) + BigInt((fraction + '0'.repeat(scale)).slice(0, scale) || '0');
}
