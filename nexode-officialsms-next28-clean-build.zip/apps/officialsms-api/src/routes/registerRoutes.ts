import type { ApiGateway } from '@nexode/api-gateway';
import type { OfficialSmsConfig } from '../config/config.js';
import { createCatalogRoutes } from '../modules/catalog/catalog.module.js';
import { createPostgresPool } from '../modules/money/infrastructure/postgres/createPostgresPool.js';
import { PostgresUserRepository, PostgresSessionRepository } from '@nexode/identity';
import { JwtTokenService } from '@nexode/auth';
import { BearerJwtStrategy } from '@nexode/api-gateway';
import { OfficialSmsAuthUserResolver, OfficialSmsJwtVerifier } from '../modules/auth/officialSmsAuth.js';
import { CustomerAuthController, loginSchema, refreshSchema } from '../modules/auth/customerAuthController.js';
import { PostgresRefreshTokenStore } from '../modules/auth/postgresRefreshTokenStore.js';
import { createCustomerPurchaseRoute } from '../modules/activation/customerPurchase.module.js';
import { AccountLifecycleController, registerSchema, verifyEmailSchema, forgotPasswordSchema, resetPasswordSchema } from '../modules/auth/accountLifecycleController.js';
import { EmailVerificationService, PasswordResetService, SecurePasswordHasher, PostgresEmailVerificationRepository, PostgresPasswordResetRepository } from '@nexode/identity';
import { ConsoleNotificationProvider } from '@nexode/notifications';
import { AuditManager } from '@nexode/identity';
import { PostgresLoginSecurityRepository } from '../modules/auth/loginSecurity.js';
import { PostgresSecurityAuditStore } from '../modules/auth/postgresSecurityAuditStore.js';
import { SessionManagementController } from '../modules/auth/sessionManagementController.js';

/**
 * Compose public catalog/auth routes and authenticated customer operations.
 * Financial and provider dependencies remain server-side only.
 */
export function registerRoutes(gateway: ApiGateway, config: OfficialSmsConfig): void {
  const pool = createPostgresPool(config.databaseUrl);
  const users = new PostgresUserRepository(pool);
  const sessions = new PostgresSessionRepository(pool);
  const refreshTokens = new PostgresRefreshTokenStore(pool);
  const tokens = new JwtTokenService({
    issuer: config.auth.issuer,
    audience: config.auth.audience,
    accessTokenLifetime: 900,
    refreshTokenLifetime: 2592000,
    secret: config.auth.jwtSecret,
  }, refreshTokens);
  const auth = new BearerJwtStrategy(
    new OfficialSmsJwtVerifier(tokens, sessions, config.auth.sessionIdleTimeoutMs),
    new OfficialSmsAuthUserResolver(users, config.auth.requireVerifiedEmail),
  );

  const loginSecurity = new PostgresLoginSecurityRepository(pool);
  const audit = new AuditManager(new PostgresSecurityAuditStore(pool));
  const authController = new CustomerAuthController(users, sessions, tokens, loginSecurity, audit, config.auth.loginLockThreshold, config.auth.loginLockDurationMs);
  const sessionManagement = new SessionManagementController(sessions, audit);
  const emailVerificationTokens = new PostgresEmailVerificationRepository(pool);
  const passwordResetTokens = new PostgresPasswordResetRepository(pool);
  const emailVerification = new EmailVerificationService(users, emailVerificationTokens);
  const passwordReset = new PasswordResetService(users, passwordResetTokens, new SecurePasswordHasher(), sessions);
  const notifications = config.environment === 'production' ? undefined : new ConsoleNotificationProvider();
  const accountLifecycle = new AccountLifecycleController(users, emailVerification, passwordReset, notifications, config.auth.emailVerificationBaseUrl, config.auth.passwordResetBaseUrl, config.environment !== 'production');

  gateway.group('/api/v1', (api) => {
    for (const route of createCatalogRoutes(config)) {
      api.register(route);
    }
    api.register(createCustomerPurchaseRoute(config, auth));
    api.post('/auth/register', accountLifecycle.register.bind(accountLifecycle), {
      schema: { body: registerSchema },
      rateLimit: { maxRequests: 5, windowMs: 3_600_000, keyGenerator: (request) => `register:${request.ipAddress ?? 'unknown'}` },
      metadata: { authentication: false, summary: 'Create a customer account', tags: ['auth'], operationId: 'registerCustomer' },
    });
    api.post('/auth/verify-email', accountLifecycle.verifyEmail.bind(accountLifecycle), {
      schema: { body: verifyEmailSchema },
      rateLimit: { maxRequests: 10, windowMs: 60_000, keyGenerator: (request) => `verify-email:${request.ipAddress ?? 'unknown'}` },
      metadata: { authentication: false, summary: 'Verify a customer email address', tags: ['auth'], operationId: 'verifyCustomerEmail' },
    });
    api.post('/auth/forgot-password', accountLifecycle.forgotPassword.bind(accountLifecycle), {
      schema: { body: forgotPasswordSchema },
      rateLimit: { maxRequests: 5, windowMs: 3_600_000, keyGenerator: (request) => `forgot-password:${request.ipAddress ?? 'unknown'}` },
      metadata: { authentication: false, summary: 'Request password reset instructions', tags: ['auth'], operationId: 'requestCustomerPasswordReset' },
    });
    api.post('/auth/reset-password', accountLifecycle.resetPassword.bind(accountLifecycle), {
      schema: { body: resetPasswordSchema },
      rateLimit: { maxRequests: 10, windowMs: 60_000, keyGenerator: (request) => `reset-password:${request.ipAddress ?? 'unknown'}` },
      metadata: { authentication: false, summary: 'Set a new customer password', tags: ['auth'], operationId: 'resetCustomerPassword' },
    });
    api.post('/auth/login', authController.login.bind(authController), {
      schema: { body: loginSchema },
      rateLimit: { maxRequests: 5, windowMs: 60_000, keyGenerator: (request) => `login:${request.ipAddress ?? 'unknown'}` },
      metadata: { authentication: false, summary: 'Authenticate a customer', tags: ['auth'], operationId: 'customerLogin' },
    });
    api.post('/auth/refresh', authController.refresh.bind(authController), {
      schema: { body: refreshSchema },
      rateLimit: { maxRequests: 20, windowMs: 60_000, keyGenerator: (request) => `refresh:${request.ipAddress ?? 'unknown'}` },
      metadata: { authentication: false, summary: 'Rotate a customer refresh token', tags: ['auth'], operationId: 'refreshCustomerToken' },
    });
    api.post('/auth/logout', authController.logout.bind(authController), {
      auth,
      metadata: { authentication: true, summary: 'End the current customer session', tags: ['auth'], operationId: 'logoutCustomer' },
    });
    api.get('/auth/sessions', sessionManagement.list.bind(sessionManagement), {
      auth,
      metadata: { authentication: true, summary: 'List the authenticated customer sessions', tags: ['auth'], operationId: 'listCustomerSessions' },
    });
    api.delete('/auth/sessions/:sessionId', sessionManagement.revoke.bind(sessionManagement), {
      auth,
      metadata: { authentication: true, summary: 'Revoke one customer session', tags: ['auth'], operationId: 'revokeCustomerSession' },
    });
    api.post('/auth/sessions/revoke-others', sessionManagement.revokeOthers.bind(sessionManagement), {
      auth,
      metadata: { authentication: true, summary: 'Revoke all other customer sessions', tags: ['auth'], operationId: 'revokeOtherCustomerSessions' },
    });
    api.get('/auth/me', async (request, response) => {
      if (!request.user) {
        response.status(401).send({ error: 'Authentication required' });
        return;
      }
      response.send({ id: request.user.id, roles: request.user.roles, permissions: request.user.permissions, metadata: request.user.metadata });
    }, {
      auth,
      metadata: { authentication: true, summary: 'Get the authenticated customer', tags: ['auth'], operationId: 'getCurrentCustomer' },
    });
  });
}
