# NeXoDe

NeXoDe is the core platform powering all Nexode products.

## Purpose

NeXoDe provides reusable infrastructure services:

- Authentication
- User Management
- Notifications
- Analytics
- Security
- Storage
- Developer Platform
- Shared Infrastructure

## Architecture Principles

- Clean Architecture
- Domain-Driven Design
- API First
- Security by Default
- Production First

## Repository Structure

- apps - Applications
- services - Backend services
- packages - Shared libraries
- docs - Documentation

## Development

Install dependencies:

```bash
pnpm install
```
## OfficialSMS identity persistence

OfficialSMS uses the shared `@nexode/identity` domain contracts with PostgreSQL-backed user and session repositories. Apply `apps/officialsms-api/migrations/0009_identity.sql` before enabling persistent identity in the API. Identity passwords are stored only as password hashes; secrets and credentials must be supplied through the deployment secret manager or local environment files and never committed.
