export type ProviderPriority =
  number;