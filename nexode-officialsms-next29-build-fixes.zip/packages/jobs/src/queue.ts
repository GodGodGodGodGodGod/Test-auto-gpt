import type { EnqueueJobInput, Job } from './types.js';

export interface JobQueue {
  enqueue<TPayload>(input: EnqueueJobInput<TPayload>): Promise<Job<TPayload>>;
  claim(workerId: string, leaseMs: number): Promise<Job | null>;
  complete(jobId: string, workerId: string): Promise<void>;
  fail(jobId: string, workerId: string, error: string, retryAt?: string): Promise<void>;
}

export interface JobHandler<TPayload = unknown> {
  handle(payload: TPayload, job: Job<TPayload>): Promise<void>;
}
