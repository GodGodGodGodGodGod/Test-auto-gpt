import type { EnqueueJobInput, Job } from '../../types.js';
import type { JobQueue } from '../../queue.js';

export class InMemoryJobQueue implements JobQueue {
  private readonly jobs = new Map<string, Job>();

  async enqueue<TPayload>(input: EnqueueJobInput<TPayload>): Promise<Job<TPayload>> {
    if (input.dedupeKey) {
      const existing = [...this.jobs.values()].find((job) => job.dedupeKey === input.dedupeKey && ['QUEUED', 'RUNNING'].includes(job.status));
      if (existing) return existing as Job<TPayload>;
    }
    const now = new Date().toISOString();
    const job: Job<TPayload> = { id: input.id, type: input.type, payload: input.payload, ...(input.dedupeKey ? { dedupeKey: input.dedupeKey } : {}), status: 'QUEUED', attempts: 0, maxAttempts: input.maxAttempts ?? 5, availableAt: input.availableAt ?? now, createdAt: now, updatedAt: now };
    this.jobs.set(job.id, job);
    return job;
  }

  async claim(workerId: string, leaseMs: number): Promise<Job | null> {
    const now = Date.now();
    for (const job of this.jobs.values()) {
      const expired = job.status === 'RUNNING' && job.lockedUntil !== undefined && Date.parse(job.lockedUntil) <= now;
      if ((job.status === 'QUEUED' && Date.parse(job.availableAt) <= now) || expired) {
        const updated: Job = { ...job, status: 'RUNNING', attempts: job.attempts + 1, lockedBy: workerId, lockedUntil: new Date(now + leaseMs).toISOString(), updatedAt: new Date().toISOString() };
        this.jobs.set(job.id, updated);
        return updated;
      }
    }
    return null;
  }

  async complete(jobId: string, workerId: string): Promise<void> {
    const job = this.jobs.get(jobId);
    if (!job || job.lockedBy !== workerId) throw new Error(`Job is not owned by worker: ${jobId}`);
    this.jobs.set(jobId, { ...job, status: 'SUCCEEDED', lockedBy: undefined, lockedUntil: undefined, updatedAt: new Date().toISOString() });
  }

  async fail(jobId: string, workerId: string, error: string, retryAt?: string): Promise<void> {
    const job = this.jobs.get(jobId);
    if (!job || job.lockedBy !== workerId) throw new Error(`Job is not owned by worker: ${jobId}`);
    const retry = retryAt !== undefined && job.attempts < job.maxAttempts;
    this.jobs.set(jobId, { ...job, status: retry ? 'QUEUED' : 'FAILED', availableAt: retryAt ?? job.availableAt, lastError: error, lockedBy: undefined, lockedUntil: undefined, updatedAt: new Date().toISOString() });
  }
}
