import { describe, expect, it } from 'vitest';
import { InMemoryJobQueue } from '../src/index.js';

describe('InMemoryJobQueue', () => {
  it('deduplicates active jobs', async () => {
    const queue = new InMemoryJobQueue();
    const a = await queue.enqueue({ id: 'a', type: 'x', payload: { id: 1 }, dedupeKey: 'x:1' });
    const b = await queue.enqueue({ id: 'b', type: 'x', payload: { id: 1 }, dedupeKey: 'x:1' });
    expect(b.id).toBe(a.id);
  });

  it('retries a failed job with a future schedule', async () => {
    const queue = new InMemoryJobQueue();
    await queue.enqueue({ id: 'a', type: 'x', payload: {}, maxAttempts: 2 });
    const job = await queue.claim('worker', 1000);
    expect(job?.attempts).toBe(1);
    await queue.fail('a', 'worker', 'temporary', new Date(Date.now() + 1000).toISOString());
    const immediate = await queue.claim('worker2', 1000);
    expect(immediate).toBeNull();
  });
});
