export interface RefreshTokenRecord {
  readonly tokenHash: string;
  readonly userId: string;
  readonly sessionId: string;
  readonly familyId: string;
  readonly issuedAt: Date;
  readonly expiresAt: Date;
  readonly revokedAt?: Date;
  readonly replacedByHash?: string;
}

export interface RefreshTokenStore {
  findByHash(tokenHash: string): Promise<RefreshTokenRecord | undefined>;
  save(record: RefreshTokenRecord): Promise<void>;
  rotate(currentHash: string, next: RefreshTokenRecord): Promise<boolean>;
  revoke(tokenHash: string, replacedByHash?: string): Promise<void>;
  revokeFamily(familyId: string): Promise<void>;
}
