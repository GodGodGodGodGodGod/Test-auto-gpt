import { createHash, randomUUID } from 'node:crypto';
import { SignJWT, jwtVerify } from 'jose';

import type {
  TokenService,
} from '../../interfaces.js';

import type {
  UserIdentity,
} from '../../types.js';

import type {
  TokenPair,
  VerifyTokenResult,
} from '../../token.types.js';

import type { JwtOptions } from './jwt.types.js';
import type { RefreshTokenStore } from './refreshTokenStore.js';

export class JwtTokenService implements TokenService {
  constructor(
    private readonly options: JwtOptions,
    private readonly refreshTokens?: RefreshTokenStore,
  ) {}

  async issue(
    user: UserIdentity,
  ): Promise<TokenPair> {
    const accessToken = await new SignJWT({})
      .setProtectedHeader({ alg: 'HS256' })
      .setSubject(user.id)
      .setIssuer(this.options.issuer)
      .setAudience(this.options.audience)
      .setIssuedAt()
      .setExpirationTime(
        `${this.options.accessTokenLifetime}s`,
      )
      .sign(this.options.secret);

    const refreshToken = await new SignJWT({})
      .setProtectedHeader({ alg: 'HS256' })
      .setSubject(user.id)
      .setIssuer(this.options.issuer)
      .setAudience(this.options.audience)
      .setIssuedAt()
      .setExpirationTime(
        `${this.options.refreshTokenLifetime}s`,
      )
      .sign(this.options.secret);

    return {
      accessToken,
      refreshToken,
    };
  }

  async issueForSession(
    user: UserIdentity,
    sessionId: string,
  ): Promise<TokenPair> {
    const accessToken = await new SignJWT({ sid: sessionId })
      .setProtectedHeader({ alg: 'HS256' })
      .setSubject(user.id)
      .setIssuer(this.options.issuer)
      .setAudience(this.options.audience)
      .setIssuedAt()
      .setExpirationTime(`${this.options.accessTokenLifetime}s`)
      .sign(this.options.secret);

    const refreshToken = await new SignJWT({ sid: sessionId, typ: 'refresh', jti: randomUUID() })
      .setProtectedHeader({ alg: 'HS256' })
      .setSubject(user.id)
      .setIssuer(this.options.issuer)
      .setAudience(this.options.audience)
      .setIssuedAt()
      .setExpirationTime(`${this.options.refreshTokenLifetime}s`)
      .sign(this.options.secret);

    if (this.refreshTokens) {
      const now = new Date();
      await this.refreshTokens.save({
        tokenHash: hashRefreshToken(refreshToken),
        userId: user.id,
        sessionId,
        familyId: sessionId,
        issuedAt: now,
        expiresAt: new Date(now.getTime() + this.options.refreshTokenLifetime * 1000),
      });
    }

    return { accessToken, refreshToken };
  }

async verify(
  token: string,
): Promise<VerifyTokenResult> {
  const { payload } = await jwtVerify(
    token,
    this.options.secret,
    {
      issuer: this.options.issuer,
      audience: this.options.audience,
    },
  );

  const audience = Array.isArray(payload.aud)
    ? payload.aud[0]
    : payload.aud;

  if (!audience) {
    throw new Error('JWT payload is missing audience.');
  }

  if (!payload.sub) {
    throw new Error('JWT payload is missing subject.');
  }

  if (!payload.iss) {
    throw new Error('JWT payload is missing issuer.');
  }

  if (payload.iat === undefined) {
    throw new Error('JWT payload is missing issued-at time.');
  }

  if (payload.exp === undefined) {
    throw new Error('JWT payload is missing expiration time.');
  }

  return {
    subject: payload.sub,
    claims: {
      sub: payload.sub,
      iss: payload.iss,
      aud: audience,
      iat: payload.iat,
      exp: payload.exp,
      sid: typeof payload.sid === 'string' ? payload.sid : undefined,
    },
  };
}

  async refresh(refreshToken: string): Promise<TokenPair> {
    if (!this.refreshTokens) throw new Error('Refresh token storage is not configured.');

    const verified = await jwtVerify(refreshToken, this.options.secret, {
      issuer: this.options.issuer,
      audience: this.options.audience,
    });
    if (verified.payload.typ !== 'refresh') throw new Error('Refresh token required.');
    if (!verified.payload.sub || typeof verified.payload.sid !== 'string') throw new Error('Invalid refresh token.');

    const tokenHash = hashRefreshToken(refreshToken);
    const record = await this.refreshTokens.findByHash(tokenHash);
    const now = new Date();
    if (!record || record.userId !== verified.payload.sub || record.sessionId !== verified.payload.sid || record.revokedAt || record.expiresAt <= now) {
      if (record?.revokedAt) await this.refreshTokens.revokeFamily(record.familyId);
      throw new Error('Refresh token is invalid or revoked.');
    }

    const accessToken = await new SignJWT({ sid: record.sessionId })
      .setProtectedHeader({ alg: 'HS256' })
      .setSubject(record.userId)
      .setIssuer(this.options.issuer)
      .setAudience(this.options.audience)
      .setIssuedAt()
      .setExpirationTime(`${this.options.accessTokenLifetime}s`)
      .sign(this.options.secret);

    const nextRefreshToken = await new SignJWT({ sid: record.sessionId, typ: 'refresh', jti: randomUUID() })
      .setProtectedHeader({ alg: 'HS256' })
      .setSubject(record.userId)
      .setIssuer(this.options.issuer)
      .setAudience(this.options.audience)
      .setIssuedAt()
      .setExpirationTime(`${this.options.refreshTokenLifetime}s`)
      .sign(this.options.secret);

    const nextHash = hashRefreshToken(nextRefreshToken);
    const rotated = await this.refreshTokens.rotate(tokenHash, {
      tokenHash: nextHash, userId: record.userId, sessionId: record.sessionId, familyId: record.familyId,
      issuedAt: now, expiresAt: new Date(now.getTime() + this.options.refreshTokenLifetime * 1000),
    });
    if (!rotated) {
      await this.refreshTokens.revokeFamily(record.familyId);
      throw new Error('Refresh token was already rotated.');
    }
    return { accessToken, refreshToken: nextRefreshToken };
  }
}

export function hashRefreshToken(token: string): string {
  return createHash('sha256').update(token, 'utf8').digest('hex');
}